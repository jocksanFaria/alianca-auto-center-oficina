# Bugs Conhecidos - Aliança Auto Center

**Versão:** 433fdbad  
**Data da Auditoria:** 08/11/2025  
**Status:** Documentação para correção externa

---

## 📋 Resumo Executivo

Este documento lista **todos os bugs conhecidos** do sistema, organizados por severidade e módulo. O objetivo é facilitar a auditoria técnica e priorização de correções.

### Estatísticas

| Severidade | Quantidade | % do Total |
|------------|------------|------------|
| 🔴 Crítica | 2 | 28% |
| 🟠 Alta | 3 | 43% |
| 🟡 Média | 2 | 29% |
| **Total** | **7** | **100%** |

---

## 🔴 Bugs Críticos (Impedem Uso)

### BUG-001: Geração de PDF Falhando

**Severidade:** 🔴 Crítica  
**Módulo:** Orçamentos  
**Status:** Não Corrigido  
**Impacto:** Alto - Funcionalidade essencial não funciona

#### Descrição
Ao clicar no botão "Download PDF" em qualquer orçamento, o sistema retorna erro HTTP 500 e exibe mensagem "Não foi possível gerar o PDF" no frontend.

#### Reprodução
1. Acessar página de orçamentos
2. Clicar em qualquer orçamento
3. Clicar no botão "Download PDF"
4. **Resultado:** Erro 500

#### Evidências
- **Screenshot:** Disponível (IMG_5898.png)
- **Erro no Console:** "Failed to load resource: the server responded with a status of 500 ()"
- **Endpoint:** `POST /api/trpc/orcamentos.generatePDF`

#### Arquivos Envolvidos
- `server/routers.ts` (linha ~200-250, endpoint `orcamentos.generatePDF`)
- Possível problema com biblioteca PDFKit ou falta de dependência

#### Logs de Erro
```
[Erro não capturado em logs - servidor não gera log detalhado]
```

#### Solução Sugerida
1. Adicionar logging detalhado no endpoint `generatePDF`
2. Verificar se PDFKit está instalado corretamente
3. Testar geração de PDF com dados simples
4. Verificar permissões de escrita em diretório temporário
5. Adicionar tratamento de erro com mensagem específica

#### Prioridade
**P0 - Máxima** - Funcionalidade essencial para operação do sistema

---

### BUG-002: Erro de Autenticação Intermitente

**Severidade:** 🔴 Crítica  
**Módulo:** Autenticação (Todos os módulos afetados)  
**Status:** Não Corrigido  
**Impacto:** Alto - Usuário perde sessão aleatoriamente

#### Descrição
Usuários reportam que "ícones e botões dentro dos módulos estão dando erro" e o sistema trava. Investigação mostra que o servidor retorna erro UNAUTHORIZED (401) em requisições aleatórias, mesmo com usuário logado.

#### Reprodução
1. Fazer login no sistema
2. Navegar entre módulos normalmente
3. **Resultado:** Após alguns minutos, requisições começam a falhar com erro 401
4. Usuário precisa fazer logout e login novamente

#### Evidências
- **Erro no Console:** "UNAUTHORIZED" em requisições tRPC
- **Teste via cURL:**
```bash
curl http://localhost:3000/api/trpc/dashboard.stats
# Retorna: {"error":{"json":{"message":"Please login (10001)","code":-32001}}}
```

#### Arquivos Envolvidos
- `server/_core/context.ts` (linha 20-40, validação de sessão)
- `server/_core/cookies.ts` (configuração de cookies)
- `server/_core/trpc.ts` (middleware protectedProcedure)

#### Possíveis Causas
1. **Expiração de JWT muito curta** - Token expira antes do esperado
2. **Cookie não persistindo** - Configuração de SameSite/Secure incorreta
3. **Renovação de token não implementada** - Sistema não renova token automaticamente
4. **Problema de timezone** - Validação de expiração com timezone errado

#### Logs de Erro
```typescript
TRPCError: Please login (10001)
    at /home/ubuntu/alianca-auto-center/server/_core/trpc.ts:17:11
    at callRecursive (/home/ubuntu/alianca-auto-center/node_modules/.pnpm/@trpc+server@11.6.0_typescript@5.9.3/node_modules/@trpc/server/src/unstable-core-do-not-import/procedureBuilder.ts:633:26)
```

#### Solução Sugerida
1. Adicionar logging em `context.ts` para rastrear validação de sessão
2. Verificar configuração de expiração do JWT (variável `JWT_SECRET` e tempo de expiração)
3. Implementar renovação automática de token (refresh token)
4. Adicionar interceptor no frontend para detectar 401 e redirecionar para login
5. Verificar configuração de cookies (httpOnly, secure, sameSite)

#### Prioridade
**P0 - Máxima** - Afeta usabilidade de todo o sistema

---

## 🟠 Bugs de Alta Severidade

### BUG-003: Campo "Prazo de Entrega" Invisível

**Severidade:** 🟠 Alta  
**Módulo:** Orçamentos  
**Status:** Não Corrigido  
**Impacto:** Médio-Alto - Funcionalidade planejada mas inacessível

#### Descrição
O campo `prazoEntrega` existe na tabela `orcamentos` do banco de dados, mas não aparece no formulário de criação/edição de orçamentos. Isso impede que usuários definam prazo de entrega, tornando o sistema de "Entregas Próximas" inútil.

#### Reprodução
1. Acessar página de orçamentos
2. Clicar em "Novo Orçamento"
3. **Resultado:** Formulário não possui campo "Prazo de Entrega"
4. Verificar banco de dados: coluna `prazoEntrega` existe mas está sempre NULL

#### Evidências
- **Schema do Banco:** `prazoEntrega DATETIME NULL` (linha 76 de `drizzle/schema.ts`)
- **Formulário:** `client/src/pages/Orcamentos.tsx` não renderiza campo

#### Arquivos Envolvidos
- `client/src/pages/Orcamentos.tsx` (formulário de criação/edição)
- `drizzle/schema.ts` (schema do banco - campo existe)
- `server/routers.ts` (endpoint aceita o campo mas não é enviado)

#### Solução Sugerida
1. Adicionar campo `<input type="datetime-local">` no formulário de orçamentos
2. Adicionar validação Zod no schema do endpoint
3. Testar criação de orçamento com prazo de entrega
4. Verificar se sistema de "Entregas Próximas" funciona após correção

#### Prioridade
**P1 - Alta** - Funcionalidade prometida mas não acessível

---

### BUG-004: Envio de E-mail Não Testado

**Severidade:** 🟠 Alta  
**Módulo:** Orçamentos  
**Status:** Implementado mas não testado  
**Impacto:** Médio - Não sabemos se funciona

#### Descrição
O código de envio de e-mail está implementado no endpoint `orcamentos.sendEmail`, mas nunca foi testado em ambiente real. Não há confirmação se a configuração SMTP funciona ou se o template de e-mail está correto.

#### Reprodução
**Não testado** - Não há evidências de funcionamento ou falha

#### Evidências
- **Código:** `server/routers.ts` (endpoint `orcamentos.sendEmail` implementado)
- **Dependência:** `nodemailer` instalado
- **Configuração:** Variáveis de ambiente SMTP não documentadas

#### Arquivos Envolvidos
- `server/routers.ts` (endpoint `sendEmail`)
- Possível arquivo de configuração SMTP (não encontrado)

#### Possíveis Problemas
1. **Variáveis de ambiente faltando** - SMTP_HOST, SMTP_USER, SMTP_PASS não configuradas
2. **Template de e-mail** - Pode estar quebrado ou com dados incorretos
3. **Anexo PDF** - Depende de BUG-001 (geração de PDF)
4. **Rate limiting** - Sem controle de envio em massa

#### Solução Sugerida
1. Documentar variáveis de ambiente necessárias (SMTP_*)
2. Criar arquivo `.env.example` com variáveis de e-mail
3. Testar envio de e-mail com dados reais
4. Adicionar logging de sucesso/erro
5. Implementar fila de e-mails (opcional, para produção)

#### Prioridade
**P1 - Alta** - Funcionalidade crítica não validada

---

### BUG-005: Módulo Relatórios Não Implementado

**Severidade:** 🟠 Alta  
**Módulo:** Relatórios  
**Status:** Apenas placeholder  
**Impacto:** Médio - Módulo prometido mas vazio

#### Descrição
O módulo "Relatórios" aparece no menu lateral e possui uma página dedicada, mas está completamente vazio. Não há nenhuma funcionalidade implementada, apenas um placeholder "Página em construção".

#### Reprodução
1. Acessar menu lateral
2. Clicar em "Relatórios"
3. **Resultado:** Página vazia com mensagem "Em construção"

#### Evidências
- **Arquivo:** `client/src/pages/Relatorios.tsx` (apenas placeholder)
- **Endpoints:** Nenhum endpoint tRPC para relatórios

#### Arquivos Envolvidos
- `client/src/pages/Relatorios.tsx`
- `server/routers.ts` (sem rotas para relatórios)

#### Funcionalidades Esperadas (Não Implementadas)
1. Relatório de faturamento mensal
2. Relatório de serviços por período
3. Relatório de estoque
4. Relatório de colaboradores (folha de pagamento)
5. Gráficos e exportação em PDF/Excel

#### Solução Sugerida
1. Definir quais relatórios são prioritários
2. Criar endpoints tRPC para cada relatório
3. Implementar queries no `server/db.ts`
4. Criar interface com gráficos (Chart.js ou similar)
5. Adicionar exportação em PDF/Excel

#### Prioridade
**P1 - Alta** - Módulo visível mas não funcional

---

## 🟡 Bugs de Média Severidade

### BUG-006: Performance de Filtros no Financeiro

**Severidade:** 🟡 Média  
**Módulo:** Financeiro  
**Status:** Não Corrigido  
**Impacto:** Baixo-Médio - Só afeta com grande volume de dados

#### Descrição
Filtros na página de Financeiro (por tipo, status, cliente) podem ser lentos quando há muitos registros no banco. Não há paginação implementada, todas as contas são carregadas de uma vez.

#### Reprodução
1. Criar 500+ registros no financeiro
2. Acessar página de Financeiro
3. Aplicar filtros
4. **Resultado:** Lentidão perceptível (>2 segundos)

#### Evidências
- **Código:** `client/src/pages/Financeiro.tsx` (sem paginação)
- **Query:** `server/db.ts` (sem LIMIT)

#### Arquivos Envolvidos
- `client/src/pages/Financeiro.tsx`
- `server/routers.ts` (endpoint `financeiro.list`)
- `server/db.ts` (query sem paginação)

#### Solução Sugerida
1. Implementar paginação (LIMIT/OFFSET)
2. Adicionar índices no banco (já existem, verificar se estão sendo usados)
3. Implementar lazy loading ou scroll infinito
4. Adicionar cache no frontend (React Query já faz isso)

#### Prioridade
**P2 - Média** - Só afeta em produção com muitos dados

---

### BUG-007: Erro TypeScript Ignorado

**Severidade:** 🟡 Média  
**Módulo:** Orçamentos  
**Status:** Não Corrigido  
**Impacto:** Baixo - Não afeta funcionamento mas indica má prática

#### Descrição
Arquivo `Orcamentos.tsx` possui erro TypeScript ignorado com `any` type. Isso indica falta de type safety e pode causar bugs em runtime.

#### Reprodução
1. Abrir `client/src/pages/Orcamentos.tsx`
2. Verificar linha 91
3. **Resultado:** `Parameter 'orc' implicitly has an 'any' type`

#### Evidências
- **Arquivo:** `client/src/pages/Orcamentos.tsx:91`
- **Erro:** `Parameter 'orc' implicitly has an 'any' type. ts(7006)`

#### Código Problemático
```typescript
// Linha 91
.map((orc) => {  // 'orc' tem tipo 'any' implícito
  // ...
})
```

#### Solução Sugerida
```typescript
// Adicionar tipo explícito
.map((orc: Orcamento) => {
  // ...
})
```

#### Prioridade
**P3 - Baixa** - Não afeta funcionamento mas deve ser corrigido

---

## 📊 Análise de Impacto

### Por Módulo

| Módulo | Bugs Críticos | Bugs Altos | Bugs Médios | Total |
|--------|---------------|------------|-------------|-------|
| Orçamentos | 1 | 2 | 1 | 4 |
| Autenticação | 1 | 0 | 0 | 1 |
| Relatórios | 0 | 1 | 0 | 1 |
| Financeiro | 0 | 0 | 1 | 1 |
| **Total** | **2** | **3** | **2** | **7** |

### Por Tipo de Problema

| Tipo | Quantidade | % |
|------|------------|---|
| Funcionalidade não implementada | 2 | 29% |
| Erro em runtime | 2 | 29% |
| Campo/UI faltando | 1 | 14% |
| Performance | 1 | 14% |
| Code quality | 1 | 14% |

---

## 🎯 Roadmap de Correção Sugerido

### Sprint 1 (Críticos)
**Duração:** 3-5 dias  
**Objetivo:** Estabilizar funcionalidades essenciais

1. **BUG-001:** Corrigir geração de PDF (2 dias)
2. **BUG-002:** Corrigir autenticação intermitente (2 dias)
3. Testes de regressão (1 dia)

### Sprint 2 (Altos)
**Duração:** 5-7 dias  
**Objetivo:** Completar funcionalidades prometidas

1. **BUG-003:** Adicionar campo Prazo de Entrega (1 dia)
2. **BUG-004:** Testar e corrigir envio de e-mail (2 dias)
3. **BUG-005:** Implementar módulo Relatórios (3 dias)
4. Testes de integração (1 dia)

### Sprint 3 (Médios)
**Duração:** 2-3 dias  
**Objetivo:** Melhorias de qualidade

1. **BUG-006:** Implementar paginação no Financeiro (1 dia)
2. **BUG-007:** Corrigir tipos TypeScript (1 dia)
3. Code review geral (1 dia)

---

## 🧪 Checklist de Testes

### Testes Essenciais Antes de Deploy

- [ ] **BUG-001:** Gerar PDF de orçamento
- [ ] **BUG-002:** Manter sessão por 30 minutos sem erro 401
- [ ] **BUG-003:** Criar orçamento com prazo de entrega
- [ ] **BUG-004:** Enviar e-mail de orçamento
- [ ] **BUG-005:** Gerar ao menos 1 relatório
- [ ] **BUG-006:** Filtrar 500+ contas em <2 segundos
- [ ] **BUG-007:** Compilar TypeScript sem erros

### Testes de Regressão

- [ ] Criar cliente PF e PJ
- [ ] Cadastrar veículo
- [ ] Criar orçamento completo
- [ ] Aprovar orçamento e gerar OS
- [ ] Registrar pagamento de colaborador
- [ ] Adicionar produto ao estoque
- [ ] Criar agendamento
- [ ] Registrar conta a pagar/receber

---

## 📝 Notas Adicionais

### Bugs Não Documentados

Durante a auditoria, podem ser encontrados bugs adicionais não listados aqui. Recomenda-se:

1. Adicionar ao sistema de tracking (GitHub Issues, Jira, etc.)
2. Classificar por severidade
3. Atualizar este documento
4. Priorizar junto com bugs existentes

### Ambiente de Testes

Todos os testes devem ser realizados em:

1. **Ambiente Local:** Primeiro teste local
2. **Ambiente de Staging:** Teste com dados reais (anonimizados)
3. **Ambiente de Produção:** Deploy gradual (canary release)

### Contato para Dúvidas

- **Desenvolvedor Original:** Manus AI
- **Plataforma:** Manus (https://manus.im)
- **Versão Auditada:** 433fdbad

---

**Documento gerado em:** 08/11/2025  
**Última atualização:** 08/11/2025  
**Autor:** Manus AI  
**Status:** Pronto para auditoria externa
