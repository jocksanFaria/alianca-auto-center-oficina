# Schema do Banco de Dados - Aliança Auto Center

**Versão:** 433fdbad  
**Data:** 08/11/2025  
**ORM:** Drizzle ORM  
**Banco:** MySQL 8.0+ / TiDB

---

## 📋 Visão Geral

O banco de dados possui **13 tabelas principais** organizadas em módulos funcionais:

- **Autenticação:** `users`
- **Cadastros:** `clientes`, `veiculos`, `colaboradores`
- **Operacional:** `orcamentos`, `orcamento_itens`, `ordens_servico`, `os_itens`
- **Financeiro:** `financeiro`, `pagamentos_colaboradores`, `adiantamentos`
- **Estoque:** `estoque`, `movimentacoes_estoque`
- **Agendamentos:** `agendamentos`

---

## 🗂️ Tabelas Detalhadas

### 1. users - Usuários do Sistema

**Descrição:** Armazena usuários autenticados via Manus OAuth.

| Campo | Tipo | Restrições | Descrição |
|-------|------|------------|-----------|
| `id` | INT | PK, AUTO_INCREMENT | ID único do usuário |
| `openId` | VARCHAR(64) | UNIQUE, NOT NULL | Identificador OAuth da Manus |
| `name` | TEXT | NULL | Nome completo do usuário |
| `email` | VARCHAR(320) | NULL | E-mail do usuário |
| `loginMethod` | VARCHAR(64) | NULL | Método de login usado |
| `role` | ENUM | NOT NULL, DEFAULT 'user' | Papel: 'user' ou 'admin' |
| `createdAt` | TIMESTAMP | NOT NULL, DEFAULT NOW() | Data de criação |
| `updatedAt` | TIMESTAMP | NOT NULL, ON UPDATE NOW() | Data de atualização |
| `lastSignedIn` | TIMESTAMP | NOT NULL, DEFAULT NOW() | Último login |

**Índices:**
- PRIMARY KEY (`id`)
- UNIQUE KEY (`openId`)

**Observações:**
- O primeiro usuário com `openId` igual a `OWNER_OPEN_ID` (env var) recebe automaticamente `role='admin'`
- Senhas não são armazenadas (autenticação OAuth externa)

---

### 2. clientes - Clientes

**Descrição:** Cadastro de clientes pessoa física e jurídica.

| Campo | Tipo | Restrições | Descrição |
|-------|------|------------|-----------|
| `id` | INT | PK, AUTO_INCREMENT | ID único do cliente |
| `tipo` | ENUM('PF', 'PJ') | NOT NULL | Tipo de pessoa |
| `nome` | TEXT | NOT NULL | Nome ou razão social |
| `cpfCnpj` | VARCHAR(18) | NULL | CPF ou CNPJ |
| `telefone` | VARCHAR(20) | NULL | Telefone principal |
| `email` | VARCHAR(320) | NULL | E-mail |
| `endereco` | TEXT | NULL | Endereço completo |
| `cidade` | VARCHAR(100) | NULL | Cidade |
| `estado` | VARCHAR(2) | NULL | UF (sigla) |
| `cep` | VARCHAR(9) | NULL | CEP |
| `observacoes` | TEXT | NULL | Observações gerais |
| `createdAt` | TIMESTAMP | NOT NULL, DEFAULT NOW() | Data de criação |
| `updatedAt` | TIMESTAMP | NOT NULL, ON UPDATE NOW() | Data de atualização |

**Índices:**
- PRIMARY KEY (`id`)
- INDEX (`cpfCnpj`)
- INDEX (`nome`(255))

**Relacionamentos:**
- 1:N com `veiculos`
- 1:N com `orcamentos`
- 1:N com `ordens_servico`
- 1:N com `financeiro`
- 1:N com `agendamentos`

---

### 3. veiculos - Veículos

**Descrição:** Cadastro de veículos dos clientes.

| Campo | Tipo | Restrições | Descrição |
|-------|------|------------|-----------|
| `id` | INT | PK, AUTO_INCREMENT | ID único do veículo |
| `clienteId` | INT | FK, NOT NULL | ID do cliente proprietário |
| `placa` | VARCHAR(10) | NOT NULL | Placa do veículo |
| `marca` | VARCHAR(50) | NULL | Marca (ex: Fiat, VW) |
| `modelo` | VARCHAR(50) | NULL | Modelo (ex: Uno, Gol) |
| `ano` | INT | NULL | Ano de fabricação |
| `cor` | VARCHAR(30) | NULL | Cor do veículo |
| `km` | INT | NULL | Quilometragem |
| `status` | ENUM | NOT NULL, DEFAULT 'disponivel' | Status atual |
| `observacoes` | TEXT | NULL | Observações |
| `createdAt` | TIMESTAMP | NOT NULL, DEFAULT NOW() | Data de criação |
| `updatedAt` | TIMESTAMP | NOT NULL, ON UPDATE NOW() | Data de atualização |

**Status possíveis:**
- `disponivel` - Disponível para serviço
- `em_servico` - Em atendimento
- `aguardando_pecas` - Aguardando peças
- `aguardando_aprovacao` - Aguardando aprovação do cliente
- `pronto` - Pronto para retirada
- `entregue` - Entregue ao cliente

**Índices:**
- PRIMARY KEY (`id`)
- FOREIGN KEY (`clienteId`) REFERENCES `clientes`(`id`) ON DELETE CASCADE
- INDEX (`placa`)
- INDEX (`status`)

**Relacionamentos:**
- N:1 com `clientes`
- 1:N com `orcamentos`
- 1:N com `ordens_servico`
- 1:N com `agendamentos`

---

### 4. orcamentos - Orçamentos

**Descrição:** Orçamentos gerados para clientes.

| Campo | Tipo | Restrições | Descrição |
|-------|------|------------|-----------|
| `id` | INT | PK, AUTO_INCREMENT | ID único do orçamento |
| `numero` | VARCHAR(20) | UNIQUE, NOT NULL | Número sequencial (ex: ORC-2025-0001) |
| `clienteId` | INT | FK, NOT NULL | ID do cliente |
| `veiculoId` | INT | FK, NULL | ID do veículo (opcional) |
| `dataEntrada` | DATETIME | NOT NULL | Data de entrada |
| `prazoEntrega` | DATETIME | NULL | **Prazo previsto de entrega** |
| `status` | ENUM | NOT NULL, DEFAULT 'pendente' | Status do orçamento |
| `numeroOS` | VARCHAR(20) | NULL | Número da OS gerada (se aprovado) |
| `observacoes` | TEXT | NULL | Observações gerais |
| `subtotal` | DECIMAL(10,2) | NOT NULL, DEFAULT 0 | Subtotal dos itens |
| `desconto` | DECIMAL(10,2) | NOT NULL, DEFAULT 0 | Desconto aplicado |
| `total` | DECIMAL(10,2) | NOT NULL, DEFAULT 0 | Valor total |
| `createdAt` | TIMESTAMP | NOT NULL, DEFAULT NOW() | Data de criação |
| `updatedAt` | TIMESTAMP | NOT NULL, ON UPDATE NOW() | Data de atualização |

**Status possíveis:**
- `pendente` - Aguardando aprovação
- `aprovado` - Aprovado pelo cliente
- `recusado` - Recusado pelo cliente
- `concluido` - Concluído

**Índices:**
- PRIMARY KEY (`id`)
- UNIQUE KEY (`numero`)
- FOREIGN KEY (`clienteId`) REFERENCES `clientes`(`id`) ON DELETE CASCADE
- FOREIGN KEY (`veiculoId`) REFERENCES `veiculos`(`id`) ON DELETE SET NULL
- INDEX (`status`)
- INDEX (`dataEntrada`)
- INDEX (`prazoEntrega`)

**Relacionamentos:**
- N:1 com `clientes`
- N:1 com `veiculos`
- 1:N com `orcamento_itens`
- 1:1 com `ordens_servico` (quando aprovado)

**⚠️ Observação Importante:**
O campo `prazoEntrega` existe no banco mas **não aparece no formulário** de criação/edição de orçamentos. Isso é um bug conhecido.

---

### 5. orcamento_itens - Itens do Orçamento

**Descrição:** Itens (peças, serviços, mão de obra) de cada orçamento.

| Campo | Tipo | Restrições | Descrição |
|-------|------|------------|-----------|
| `id` | INT | PK, AUTO_INCREMENT | ID único do item |
| `orcamentoId` | INT | FK, NOT NULL | ID do orçamento |
| `categoria` | ENUM | NOT NULL | Categoria do item |
| `descricao` | TEXT | NOT NULL | Descrição do item |
| `quantidade` | INT | NOT NULL, DEFAULT 1 | Quantidade |
| `valorUnitario` | DECIMAL(10,2) | NOT NULL | Valor unitário |
| `valorTotal` | DECIMAL(10,2) | NOT NULL | Valor total (qtd * unit) |

**Categorias possíveis:**
- `peca` - Peça/produto
- `servico` - Serviço
- `mao_de_obra` - Mão de obra

**Índices:**
- PRIMARY KEY (`id`)
- FOREIGN KEY (`orcamentoId`) REFERENCES `orcamentos`(`id`) ON DELETE CASCADE
- INDEX (`categoria`)

**Relacionamentos:**
- N:1 com `orcamentos`

---

### 6. ordens_servico - Ordens de Serviço

**Descrição:** Ordens de serviço geradas a partir de orçamentos aprovados.

| Campo | Tipo | Restrições | Descrição |
|-------|------|------------|-----------|
| `id` | INT | PK, AUTO_INCREMENT | ID único da OS |
| `numero` | VARCHAR(20) | UNIQUE, NOT NULL | Número sequencial (ex: OS-2025-0001) |
| `orcamentoId` | INT | FK, NULL | ID do orçamento origem |
| `clienteId` | INT | FK, NOT NULL | ID do cliente |
| `veiculoId` | INT | FK, NOT NULL | ID do veículo |
| `dataInicio` | DATETIME | NOT NULL | Data de início |
| `dataPrevista` | DATETIME | NULL | **Data prevista de conclusão** |
| `dataConclusao` | DATETIME | NULL | Data real de conclusão |
| `status` | ENUM | NOT NULL, DEFAULT 'aguardando' | Status da OS |
| `observacoes` | TEXT | NULL | Observações |
| `createdAt` | TIMESTAMP | NOT NULL, DEFAULT NOW() | Data de criação |
| `updatedAt` | TIMESTAMP | NOT NULL, ON UPDATE NOW() | Data de atualização |

**Status possíveis:**
- `aguardando` - Aguardando início
- `em_execucao` - Em execução
- `concluida` - Concluída
- `cancelada` - Cancelada

**Índices:**
- PRIMARY KEY (`id`)
- UNIQUE KEY (`numero`)
- FOREIGN KEY (`orcamentoId`) REFERENCES `orcamentos`(`id`) ON DELETE SET NULL
- FOREIGN KEY (`clienteId`) REFERENCES `clientes`(`id`) ON DELETE CASCADE
- FOREIGN KEY (`veiculoId`) REFERENCES `veiculos`(`id`) ON DELETE CASCADE
- INDEX (`status`)
- INDEX (`dataInicio`)
- INDEX (`dataPrevista`)

**Relacionamentos:**
- N:1 com `orcamentos`
- N:1 com `clientes`
- N:1 com `veiculos`
- 1:N com `os_itens`

---

### 7. os_itens - Itens da Ordem de Serviço

**Descrição:** Itens executados em cada OS.

| Campo | Tipo | Restrições | Descrição |
|-------|------|------------|-----------|
| `id` | INT | PK, AUTO_INCREMENT | ID único do item |
| `osId` | INT | FK, NOT NULL | ID da OS |
| `categoria` | ENUM | NOT NULL | Categoria do item |
| `descricao` | TEXT | NOT NULL | Descrição |
| `quantidade` | INT | NOT NULL, DEFAULT 1 | Quantidade |
| `valorUnitario` | DECIMAL(10,2) | NOT NULL | Valor unitário |
| `valorTotal` | DECIMAL(10,2) | NOT NULL | Valor total |

**Categorias:** Mesmas de `orcamento_itens`

**Índices:**
- PRIMARY KEY (`id`)
- FOREIGN KEY (`osId`) REFERENCES `ordens_servico`(`id`) ON DELETE CASCADE

**Relacionamentos:**
- N:1 com `ordens_servico`

---

### 8. colaboradores - Colaboradores

**Descrição:** Funcionários da oficina.

| Campo | Tipo | Restrições | Descrição |
|-------|------|------------|-----------|
| `id` | INT | PK, AUTO_INCREMENT | ID único |
| `nome` | VARCHAR(255) | NOT NULL | Nome completo |
| `cargo` | VARCHAR(100) | NULL | Cargo/função |
| `salario` | DECIMAL(10,2) | NOT NULL | Salário base |
| `tipoPagamento` | ENUM | NOT NULL | Periodicidade |
| `diaSemana` | ENUM | NULL | Dia da semana (se semanal) |
| `diaQuinzena` | INT | NULL | Dia da quinzena (1-15 ou 16-31) |
| `diaMes` | INT | NULL | Dia do mês (1-31) |
| `dataAdmissao` | DATE | NOT NULL | Data de admissão |
| `status` | ENUM | NOT NULL, DEFAULT 'ativo' | Status |
| `observacoes` | TEXT | NULL | Observações |
| `createdAt` | TIMESTAMP | NOT NULL, DEFAULT NOW() | Data de criação |
| `updatedAt` | TIMESTAMP | NOT NULL, ON UPDATE NOW() | Data de atualização |

**Tipos de Pagamento:**
- `semanal` - Pagamento semanal (usa `diaSemana`)
- `quinzenal` - Pagamento quinzenal (usa `diaQuinzena`)
- `mensal` - Pagamento mensal (usa `diaMes`)

**Dias da Semana:**
- `domingo`, `segunda`, `terca`, `quarta`, `quinta`, `sexta`, `sabado`

**Status:**
- `ativo` - Ativo
- `inativo` - Inativo

**Índices:**
- PRIMARY KEY (`id`)
- INDEX (`status`)
- INDEX (`tipoPagamento`)

**Relacionamentos:**
- 1:N com `pagamentos_colaboradores`
- 1:N com `adiantamentos`

---

### 9. pagamentos_colaboradores - Pagamentos de Colaboradores

**Descrição:** Histórico de pagamentos realizados.

| Campo | Tipo | Restrições | Descrição |
|-------|------|------------|-----------|
| `id` | INT | PK, AUTO_INCREMENT | ID único |
| `colaboradorId` | INT | FK, NOT NULL | ID do colaborador |
| `dataPagamento` | DATE | NOT NULL | Data do pagamento |
| `valorBruto` | DECIMAL(10,2) | NOT NULL | Valor bruto |
| `descontos` | DECIMAL(10,2) | NOT NULL, DEFAULT 0 | Descontos aplicados |
| `valorLiquido` | DECIMAL(10,2) | NOT NULL | Valor líquido pago |
| `observacoes` | TEXT | NULL | Observações |
| `createdAt` | TIMESTAMP | NOT NULL, DEFAULT NOW() | Data de registro |

**Índices:**
- PRIMARY KEY (`id`)
- FOREIGN KEY (`colaboradorId`) REFERENCES `colaboradores`(`id`) ON DELETE CASCADE
- INDEX (`dataPagamento`)

**Relacionamentos:**
- N:1 com `colaboradores`

---

### 10. adiantamentos - Adiantamentos de Colaboradores

**Descrição:** Adiantamentos salariais concedidos.

| Campo | Tipo | Restrições | Descrição |
|-------|------|------------|-----------|
| `id` | INT | PK, AUTO_INCREMENT | ID único |
| `colaboradorId` | INT | FK, NOT NULL | ID do colaborador |
| `dataAdiantamento` | DATE | NOT NULL | Data do adiantamento |
| `valor` | DECIMAL(10,2) | NOT NULL | Valor adiantado |
| `observacoes` | TEXT | NULL | Observações |
| `createdAt` | TIMESTAMP | NOT NULL, DEFAULT NOW() | Data de registro |

**Índices:**
- PRIMARY KEY (`id`)
- FOREIGN KEY (`colaboradorId`) REFERENCES `colaboradores`(`id`) ON DELETE CASCADE
- INDEX (`dataAdiantamento`)

**Relacionamentos:**
- N:1 com `colaboradores`

---

### 11. financeiro - Contas a Pagar e Receber

**Descrição:** Controle financeiro de contas.

| Campo | Tipo | Restrições | Descrição |
|-------|------|------------|-----------|
| `id` | INT | PK, AUTO_INCREMENT | ID único |
| `tipo` | ENUM('pagar', 'receber') | NOT NULL | Tipo de conta |
| `descricao` | TEXT | NOT NULL | Descrição |
| `valor` | DECIMAL(10,2) | NOT NULL | Valor |
| `dataVencimento` | DATE | NOT NULL | Data de vencimento |
| `dataPagamento` | DATE | NULL | Data de pagamento real |
| `status` | ENUM | NOT NULL, DEFAULT 'pendente' | Status |
| `clienteId` | INT | FK, NULL | Cliente relacionado (se receber) |
| `categoria` | VARCHAR(100) | NULL | Categoria (ex: Aluguel, Fornecedor) |
| `observacoes` | TEXT | NULL | Observações |
| `createdAt` | TIMESTAMP | NOT NULL, DEFAULT NOW() | Data de criação |
| `updatedAt` | TIMESTAMP | NOT NULL, ON UPDATE NOW() | Data de atualização |

**Status possíveis:**
- `pendente` - Pendente
- `paga` - Paga
- `atrasada` - Atrasada (calculado automaticamente)

**Índices:**
- PRIMARY KEY (`id`)
- FOREIGN KEY (`clienteId`) REFERENCES `clientes`(`id`) ON DELETE SET NULL
- INDEX (`tipo`)
- INDEX (`status`)
- INDEX (`dataVencimento`)

**Relacionamentos:**
- N:1 com `clientes` (opcional)

---

### 12. estoque - Produtos em Estoque

**Descrição:** Controle de estoque de peças e produtos.

| Campo | Tipo | Restrições | Descrição |
|-------|------|------------|-----------|
| `id` | INT | PK, AUTO_INCREMENT | ID único |
| `nome` | VARCHAR(255) | NOT NULL | Nome do produto |
| `descricao` | TEXT | NULL | Descrição detalhada |
| `categoria` | VARCHAR(100) | NULL | Categoria |
| `quantidade` | INT | NOT NULL, DEFAULT 0 | Quantidade atual |
| `quantidadeMinima` | INT | NOT NULL, DEFAULT 0 | Estoque mínimo |
| `valorUnitario` | DECIMAL(10,2) | NOT NULL | Valor unitário |
| `fornecedor` | VARCHAR(255) | NULL | Fornecedor |
| `localizacao` | VARCHAR(100) | NULL | Localização física |
| `createdAt` | TIMESTAMP | NOT NULL, DEFAULT NOW() | Data de criação |
| `updatedAt` | TIMESTAMP | NOT NULL, ON UPDATE NOW() | Data de atualização |

**Índices:**
- PRIMARY KEY (`id`)
- INDEX (`nome`)
- INDEX (`categoria`)
- INDEX (`quantidade`)

**Relacionamentos:**
- 1:N com `movimentacoes_estoque`

**Alertas:**
- Sistema gera alerta quando `quantidade < quantidadeMinima`

---

### 13. movimentacoes_estoque - Movimentações de Estoque

**Descrição:** Histórico de entradas e saídas de estoque.

| Campo | Tipo | Restrições | Descrição |
|-------|------|------------|-----------|
| `id` | INT | PK, AUTO_INCREMENT | ID único |
| `produtoId` | INT | FK, NOT NULL | ID do produto |
| `tipo` | ENUM('entrada', 'saida') | NOT NULL | Tipo de movimentação |
| `quantidade` | INT | NOT NULL | Quantidade movimentada |
| `motivo` | TEXT | NULL | Motivo/descrição |
| `dataMovimentacao` | DATETIME | NOT NULL | Data da movimentação |
| `createdAt` | TIMESTAMP | NOT NULL, DEFAULT NOW() | Data de registro |

**Índices:**
- PRIMARY KEY (`id`)
- FOREIGN KEY (`produtoId`) REFERENCES `estoque`(`id`) ON DELETE CASCADE
- INDEX (`tipo`)
- INDEX (`dataMovimentacao`)

**Relacionamentos:**
- N:1 com `estoque`

---

### 14. agendamentos - Agendamentos

**Descrição:** Agenda de serviços.

| Campo | Tipo | Restrições | Descrição |
|-------|------|------------|-----------|
| `id` | INT | PK, AUTO_INCREMENT | ID único |
| `clienteId` | INT | FK, NOT NULL | ID do cliente |
| `veiculoId` | INT | FK, NULL | ID do veículo |
| `dataHora` | DATETIME | NOT NULL | Data e hora do agendamento |
| `tipo` | VARCHAR(100) | NULL | Tipo de serviço |
| `descricao` | TEXT | NULL | Descrição |
| `status` | ENUM | NOT NULL, DEFAULT 'agendado' | Status |
| `observacoes` | TEXT | NULL | Observações |
| `createdAt` | TIMESTAMP | NOT NULL, DEFAULT NOW() | Data de criação |
| `updatedAt` | TIMESTAMP | NOT NULL, ON UPDATE NOW() | Data de atualização |

**Status possíveis:**
- `agendado` - Agendado
- `confirmado` - Confirmado
- `em_andamento` - Em andamento
- `concluido` - Concluído
- `cancelado` - Cancelado

**Índices:**
- PRIMARY KEY (`id`)
- FOREIGN KEY (`clienteId`) REFERENCES `clientes`(`id`) ON DELETE CASCADE
- FOREIGN KEY (`veiculoId`) REFERENCES `veiculos`(`id`) ON DELETE SET NULL
- INDEX (`status`)
- INDEX (`dataHora`)

**Relacionamentos:**
- N:1 com `clientes`
- N:1 com `veiculos` (opcional)

---

## 🔗 Diagrama de Relacionamentos

```
users (autenticação)

clientes ──┬── veiculos
           ├── orcamentos ──── orcamento_itens
           ├── ordens_servico ──── os_itens
           ├── financeiro
           └── agendamentos

colaboradores ──┬── pagamentos_colaboradores
                └── adiantamentos

estoque ──── movimentacoes_estoque
```

---

## 📊 Estatísticas do Schema

| Métrica | Valor |
|---------|-------|
| Total de Tabelas | 13 |
| Total de Relacionamentos (FK) | 18 |
| Tabelas com Soft Delete | 0 (usa hard delete) |
| Campos ENUM | 15 |
| Campos TIMESTAMP | 26 |
| Campos DECIMAL | 28 |

---

## 🔧 Comandos Úteis

### Gerar Schema SQL
```bash
cd /home/ubuntu/alianca-auto-center
pnpm drizzle-kit generate
```

### Aplicar Migrations
```bash
pnpm db:push
```

### Resetar Banco (CUIDADO!)
```bash
mysql -u root -p -e "DROP DATABASE alianca_auto_center; CREATE DATABASE alianca_auto_center;"
pnpm db:push
```

---

## ⚠️ Observações Importantes

1. **Cascata de Deleção:**
   - Deletar cliente → deleta veículos, orçamentos, OS, financeiro, agendamentos
   - Deletar veículo → atualiza orçamentos/OS para NULL
   - Deletar colaborador → deleta pagamentos e adiantamentos

2. **Campos Calculados:**
   - `orcamentos.total` = `subtotal - desconto`
   - `orcamento_itens.valorTotal` = `quantidade * valorUnitario`
   - `financeiro.status` = 'atrasada' se `dataVencimento < hoje` e `status = 'pendente'`

3. **Campos Não Utilizados:**
   - `orcamentos.prazoEntrega` - Existe mas não aparece no formulário (BUG)
   - `ordens_servico.dataPrevista` - Existe mas pouco utilizado

4. **Integridade Referencial:**
   - Todas as FKs possuem `ON DELETE CASCADE` ou `ON DELETE SET NULL`
   - Não há constraints CHECK (validação feita no backend)

---

**Documento gerado em:** 08/11/2025  
**Versão:** 433fdbad  
**Autor:** Manus AI
