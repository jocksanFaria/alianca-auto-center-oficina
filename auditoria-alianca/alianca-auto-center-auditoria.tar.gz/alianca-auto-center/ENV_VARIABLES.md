# Variáveis de Ambiente - Aliança Auto Center

**Versão:** 433fdbad  
**Data:** 08/11/2025  
**Plataforma:** Manus (ambiente gerenciado)

---

## ⚠️ Importante: Sistema Manus

Este projeto foi desenvolvido na plataforma **Manus**, que gerencia automaticamente as variáveis de ambiente através de uma interface web. As variáveis são injetadas automaticamente no runtime e **não precisam** de arquivo `.env` local.

Para auditoria externa ou deploy fora da Manus, as variáveis precisam ser configuradas manualmente.

---

## 📋 Variáveis Configuradas (Manus)

As seguintes variáveis já estão configuradas no ambiente Manus:

| Variável | Tipo | Descrição |
|----------|------|-----------|
| `DATABASE_URL` | Secret | String de conexão MySQL/TiDB |
| `JWT_SECRET` | Secret | Chave secreta para JWT |
| `OAUTH_SERVER_URL` | Config | URL do servidor OAuth |
| `VITE_OAUTH_PORTAL_URL` | Config | URL do portal de login |
| `VITE_APP_ID` | Config | ID da aplicação OAuth |
| `OWNER_OPEN_ID` | Config | OpenID do proprietário |
| `OWNER_NAME` | Config | Nome do proprietário |
| `VITE_APP_TITLE` | Config | Título da aplicação |
| `VITE_APP_LOGO` | Config | Logo da aplicação |
| `BUILT_IN_FORGE_API_URL` | Config | URL das APIs Manus (backend) |
| `BUILT_IN_FORGE_API_KEY` | Secret | Chave API Manus (backend) |
| `VITE_FRONTEND_FORGE_API_URL` | Config | URL das APIs Manus (frontend) |
| `VITE_FRONTEND_FORGE_API_KEY` | Secret | Chave API Manus (frontend) |
| `VITE_ANALYTICS_WEBSITE_ID` | Config | ID do analytics (opcional) |
| `VITE_ANALYTICS_ENDPOINT` | Config | Endpoint analytics (opcional) |

---

## 🔐 Variáveis Obrigatórias

### Para Deploy Externo (Fora da Manus)

Se você for fazer deploy fora da plataforma Manus, precisará configurar manualmente:

#### 1. Banco de Dados

```bash
DATABASE_URL="mysql://usuario:senha@host:porta/database?charset=utf8mb4"
```

**Formato:**
- `mysql://` - Protocolo
- `usuario:senha` - Credenciais do banco
- `host:porta` - Endereço do servidor (ex: localhost:3306)
- `/database` - Nome do banco de dados
- `?charset=utf8mb4` - Charset (recomendado)

**Exemplo:**
```bash
DATABASE_URL="mysql://root:mypassword@localhost:3306/alianca_auto_center?charset=utf8mb4"
```

#### 2. Autenticação JWT

```bash
JWT_SECRET="sua-chave-secreta-minimo-32-caracteres"
```

**Requisitos:**
- Mínimo 32 caracteres
- Caracteres aleatórios
- Nunca compartilhar ou commitar

**Gerar chave segura:**
```bash
# Linux/Mac
openssl rand -base64 32

# Node.js
node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"
```

#### 3. OAuth (Se usar Manus Auth)

```bash
OAUTH_SERVER_URL="https://api.manus.im"
VITE_OAUTH_PORTAL_URL="https://portal.manus.im"
VITE_APP_ID="seu-app-id"
```

**Nota:** Se for implementar autenticação própria, essas variáveis não são necessárias, mas será preciso modificar `server/_core/context.ts` e `server/_core/trpc.ts`.

#### 4. Proprietário (Primeiro Admin)

```bash
OWNER_OPEN_ID="openid-do-proprietario"
OWNER_NAME="Nome do Proprietário"
```

**Nota:** O usuário com este `OWNER_OPEN_ID` receberá automaticamente `role='admin'` na primeira vez que fizer login.

#### 5. Aplicação

```bash
VITE_APP_TITLE="Aliança Auto Center - Sistema Completo"
VITE_APP_LOGO="/logo.png"
```

---

## 📧 Variáveis Opcionais (E-mail)

Para funcionalidade de envio de e-mail, configure:

```bash
# Servidor SMTP
SMTP_HOST="smtp.gmail.com"
SMTP_PORT="587"
SMTP_SECURE="false"  # true para SSL (porta 465)

# Credenciais
SMTP_USER="seu-email@gmail.com"
SMTP_PASS="sua-senha-ou-app-password"

# Remetente
SMTP_FROM="seu-email@gmail.com"
SMTP_FROM_NAME="Aliança Auto Center"
```

### Configuração Gmail

1. Ativar "Verificação em duas etapas"
2. Gerar "Senha de app" em https://myaccount.google.com/apppasswords
3. Usar senha de app no `SMTP_PASS`

### Outros Provedores

| Provedor | Host | Porta | Secure |
|----------|------|-------|--------|
| Gmail | smtp.gmail.com | 587 | false |
| Outlook | smtp.office365.com | 587 | false |
| SendGrid | smtp.sendgrid.net | 587 | false |
| Mailgun | smtp.mailgun.org | 587 | false |

---

## 🔧 Variáveis de Ambiente (Desenvolvimento)

```bash
NODE_ENV="development"
PORT="3000"
```

---

## 📝 Como Configurar

### Método 1: Arquivo .env (Desenvolvimento Local)

1. Criar arquivo `.env` na raiz do projeto:
```bash
cd alianca-auto-center
touch .env
```

2. Copiar variáveis necessárias e preencher:
```bash
DATABASE_URL="mysql://..."
JWT_SECRET="..."
# ... outras variáveis
```

3. **NUNCA** commitar arquivo `.env`:
```bash
# Já está no .gitignore, mas verifique:
echo ".env" >> .gitignore
```

### Método 2: Variáveis de Sistema (Produção)

```bash
# Linux/Mac
export DATABASE_URL="mysql://..."
export JWT_SECRET="..."

# Ou adicionar em ~/.bashrc ou ~/.zshrc
echo 'export DATABASE_URL="mysql://..."' >> ~/.bashrc
```

### Método 3: Docker (Produção)

```yaml
# docker-compose.yml
version: '3.8'
services:
  app:
    image: alianca-auto-center
    environment:
      - DATABASE_URL=mysql://...
      - JWT_SECRET=...
      # ... outras variáveis
```

### Método 4: Plataforma Cloud

- **Heroku:** Settings → Config Vars
- **Vercel:** Settings → Environment Variables
- **AWS:** Systems Manager → Parameter Store
- **Azure:** App Service → Configuration → Application settings

---

## 🔍 Validação de Variáveis

O sistema valida variáveis de ambiente no arquivo `server/_core/env.ts`.

### Variáveis Validadas

```typescript
// server/_core/env.ts
export const ENV = {
  // Obrigatórias
  databaseUrl: process.env.DATABASE_URL!,
  jwtSecret: process.env.JWT_SECRET!,
  oauthServerUrl: process.env.OAUTH_SERVER_URL!,
  
  // Opcionais
  smtpHost: process.env.SMTP_HOST,
  smtpPort: process.env.SMTP_PORT,
  // ...
};
```

### Verificar Variáveis

```bash
# Verificar se variáveis estão definidas
cd alianca-auto-center
node -e "require('dotenv').config(); console.log(process.env.DATABASE_URL ? 'OK' : 'FALTA')"
```

---

## ⚠️ Segurança

### Variáveis Sensíveis (NUNCA Expor)

- `DATABASE_URL` - Contém senha do banco
- `JWT_SECRET` - Compromete autenticação
- `SMTP_PASS` - Senha de e-mail
- `*_API_KEY` (backend) - Chaves de API

### Variáveis Públicas (Podem Expor)

- `VITE_*` - Todas as variáveis com prefixo `VITE_` são incluídas no bundle do frontend
- `VITE_APP_TITLE` - Título público
- `VITE_APP_LOGO` - Logo público
- `VITE_FRONTEND_FORGE_API_KEY` - Chave de API pública (frontend)

### Boas Práticas

1. **Nunca commitar** arquivo `.env`
2. **Usar secrets** em CI/CD (GitHub Secrets, GitLab CI Variables)
3. **Rotacionar chaves** periodicamente
4. **Diferentes valores** para dev/staging/prod
5. **Backup seguro** de variáveis de produção

---

## 🐛 Troubleshooting

### Erro: "Please login (10001)"

**Causa:** JWT_SECRET incorreto ou ausente

**Solução:**
1. Verificar se `JWT_SECRET` está definido
2. Verificar se tem mínimo 32 caracteres
3. Limpar cookies do navegador
4. Fazer logout e login novamente

### Erro: "Cannot connect to database"

**Causa:** DATABASE_URL incorreto

**Solução:**
1. Verificar formato: `mysql://user:pass@host:port/db`
2. Testar conexão manual:
```bash
mysql -h host -u user -p database
```
3. Verificar firewall/porta
4. Verificar se banco existe

### Erro: "SMTP connection failed"

**Causa:** Variáveis SMTP incorretas

**Solução:**
1. Verificar `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS`
2. Testar conexão:
```bash
telnet smtp.gmail.com 587
```
3. Verificar se 2FA está ativo (Gmail requer App Password)
4. Verificar logs do servidor

### Variável não carrega

**Causa:** Prefixo errado ou não reiniciou servidor

**Solução:**
1. Variáveis de frontend DEVEM ter prefixo `VITE_`
2. Reiniciar servidor após alterar `.env`:
```bash
pnpm dev  # Ctrl+C e rodar novamente
```
3. Limpar cache do Vite:
```bash
rm -rf node_modules/.vite
pnpm dev
```

---

## 📚 Referências

### Arquivos Relacionados

- `server/_core/env.ts` - Validação de variáveis
- `server/_core/context.ts` - Uso de variáveis de autenticação
- `vite.config.ts` - Configuração de variáveis VITE_*

### Documentação Externa

- [Vite Environment Variables](https://vitejs.dev/guide/env-and-mode.html)
- [Node.js process.env](https://nodejs.org/api/process.html#processenv)
- [dotenv Package](https://www.npmjs.com/package/dotenv)

---

## 📞 Suporte

Para dúvidas sobre variáveis de ambiente:

1. Verificar este documento
2. Verificar `server/_core/env.ts`
3. Consultar logs do servidor
4. Contatar desenvolvedor original (Manus AI)

---

**Documento gerado em:** 08/11/2025  
**Versão:** 433fdbad  
**Autor:** Manus AI
