# Aliança Auto Center - Sistema Completo

## Documentação para Auditoria Técnica

**Versão:** 433fdbad  
**Data:** 08/11/2025  
**Stack:** React 19 + TypeScript + Node.js + Express + tRPC + MySQL/TiDB

---

## 📋 Índice

1. [Visão Geral do Sistema](#visão-geral-do-sistema)
2. [Arquitetura](#arquitetura)
3. [Requisitos e Dependências](#requisitos-e-dependências)
4. [Instalação e Configuração](#instalação-e-configuração)
5. [Estrutura do Projeto](#estrutura-do-projeto)
6. [Módulos Implementados](#módulos-implementados)
7. [Problemas Conhecidos](#problemas-conhecidos)
8. [Variáveis de Ambiente](#variáveis-de-ambiente)
9. [Banco de Dados](#banco-de-dados)
10. [Testes](#testes)

---

## 🎯 Visão Geral do Sistema

O **Aliança Auto Center** é um sistema completo de gestão para oficinas mecânicas, desenvolvido para gerenciar orçamentos, ordens de serviço, clientes, veículos, estoque, financeiro, colaboradores e agendamentos.

### Funcionalidades Principais

O sistema possui **11 módulos principais** totalmente integrados:

- **Dashboard**: Visão geral com cards de métricas e gráficos
- **Orçamentos**: CRUD completo com geração de PDF, envio por e-mail e busca
- **Orçamentos Externos**: Upload de PDF e extração de dados via IA
- **Ordens de Serviço**: Gestão de OS com múltiplos status
- **Clientes**: Cadastro de clientes PF/PJ com histórico
- **Veículos**: Gestão de veículos com 6 status diferentes
- **Financeiro**: Contas a pagar/receber com filtros e gráficos
- **Estoque**: Controle de produtos e movimentações
- **Agendamentos**: Calendário de agendamentos
- **Colaboradores**: Folha de pagamento e adiantamentos
- **Relatórios**: Relatórios gerenciais

---

## 🏗️ Arquitetura

### Frontend
- **Framework**: React 19 com TypeScript
- **Roteamento**: Wouter (alternativa leve ao React Router)
- **Estilização**: Tailwind CSS 4 + shadcn/ui
- **Comunicação**: tRPC 11 (type-safe RPC)
- **Gerenciamento de Estado**: React Query (via tRPC)
- **Build Tool**: Vite 6

### Backend
- **Runtime**: Node.js 22.13.0
- **Framework**: Express 4
- **API**: tRPC 11 (end-to-end type-safe)
- **ORM**: Drizzle ORM
- **Banco de Dados**: MySQL/TiDB (compatível)
- **Autenticação**: Manus OAuth + JWT

### Características Técnicas
- **Type Safety**: TypeScript end-to-end (frontend + backend)
- **Serialização**: Superjson (suporta Date, Map, Set nativamente)
- **Hot Reload**: TSX watch mode no backend
- **Validação**: Zod schemas
- **Geração de PDF**: PDFKit
- **E-mail**: Nodemailer

---

## 📦 Requisitos e Dependências

### Requisitos de Sistema
- Node.js >= 22.13.0
- pnpm >= 10.4.1
- MySQL 8.0+ ou TiDB Cloud
- 2GB RAM mínimo
- 500MB espaço em disco

### Dependências Principais (package.json)

#### Frontend
```json
{
  "react": "^19.0.0",
  "wouter": "^3.5.3",
  "@trpc/client": "^11.6.0",
  "@trpc/react-query": "^11.6.0",
  "@tanstack/react-query": "^5.62.11",
  "tailwindcss": "^4.1.7",
  "lucide-react": "^0.468.0"
}
```

#### Backend
```json
{
  "express": "^4.21.2",
  "@trpc/server": "^11.6.0",
  "drizzle-orm": "^0.40.0",
  "mysql2": "^3.12.0",
  "jsonwebtoken": "^9.0.2",
  "pdfkit": "^0.16.0",
  "nodemailer": "^6.9.17"
}
```

---

## 🚀 Instalação e Configuração

### 1. Clonar o Repositório
```bash
# Se receber via ZIP
unzip alianca-auto-center.zip
cd alianca-auto-center

# Se receber via Git
git clone <repository-url>
cd alianca-auto-center
```

### 2. Instalar Dependências
```bash
# Instalar pnpm se não tiver
npm install -g pnpm@10.4.1

# Instalar dependências do projeto
pnpm install
```

### 3. Configurar Variáveis de Ambiente

Copie o arquivo `.env.example` para `.env` e preencha as variáveis:

```bash
cp .env.example .env
```

**Variáveis obrigatórias:**
- `DATABASE_URL`: String de conexão MySQL
- `JWT_SECRET`: Chave secreta para JWT (mínimo 32 caracteres)
- `VITE_APP_ID`: ID da aplicação OAuth
- `OAUTH_SERVER_URL`: URL do servidor OAuth
- `VITE_OAUTH_PORTAL_URL`: URL do portal de login

Veja seção [Variáveis de Ambiente](#variáveis-de-ambiente) para detalhes completos.

### 4. Configurar Banco de Dados

```bash
# Criar banco de dados
mysql -u root -p -e "CREATE DATABASE alianca_auto_center CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"

# Executar migrations
pnpm db:push
```

### 5. Iniciar Servidor de Desenvolvimento

```bash
# Modo desenvolvimento (hot reload)
pnpm dev

# O servidor iniciará em http://localhost:3000
```

### 6. Build para Produção

```bash
# Build otimizado
pnpm build

# Iniciar em produção
pnpm start
```

---

## 📁 Estrutura do Projeto

```
alianca-auto-center/
├── client/                      # Frontend React
│   ├── public/                  # Assets estáticos
│   ├── src/
│   │   ├── pages/              # Páginas/rotas
│   │   │   ├── Dashboard.tsx
│   │   │   ├── Orcamentos.tsx
│   │   │   ├── Clientes.tsx
│   │   │   └── ...
│   │   ├── components/         # Componentes reutilizáveis
│   │   │   ├── ui/            # shadcn/ui components
│   │   │   ├── Layout.tsx
│   │   │   └── ...
│   │   ├── lib/               # Utilitários
│   │   │   ├── trpc.ts        # Cliente tRPC
│   │   │   └── currency.ts
│   │   ├── App.tsx            # Rotas principais
│   │   ├── main.tsx           # Entry point
│   │   └── index.css          # Estilos globais
│   └── index.html
│
├── server/                      # Backend Node.js
│   ├── _core/                  # Infraestrutura
│   │   ├── index.ts           # Express server
│   │   ├── trpc.ts            # Setup tRPC
│   │   ├── context.ts         # Request context
│   │   ├── cookies.ts         # Gestão de cookies
│   │   ├── env.ts             # Validação de env vars
│   │   └── systemRouter.ts    # Rotas do sistema
│   ├── db.ts                   # Queries do banco
│   └── routers.ts              # Rotas da API (tRPC)
│
├── drizzle/                     # ORM e Migrations
│   ├── schema.ts               # Schema do banco
│   └── migrations/             # Migrations SQL
│
├── shared/                      # Código compartilhado
│   └── const.ts                # Constantes
│
├── storage/                     # Helpers S3
│   └── index.ts
│
├── package.json
├── tsconfig.json
├── vite.config.ts
├── tailwind.config.ts
└── drizzle.config.ts
```

### Arquivos Chave para Auditoria

#### Frontend
- `client/src/pages/*.tsx` - Todas as páginas do sistema
- `client/src/components/Layout.tsx` - Layout principal
- `client/src/lib/trpc.ts` - Configuração do cliente tRPC

#### Backend
- `server/routers.ts` - **ARQUIVO PRINCIPAL** - Todas as rotas da API
- `server/db.ts` - Todas as queries do banco de dados
- `server/_core/trpc.ts` - Middlewares e procedures

#### Banco de Dados
- `drizzle/schema.ts` - Schema completo das tabelas

---

## 🔧 Módulos Implementados

### 1. Dashboard
**Status:** ✅ Funcional  
**Arquivo:** `client/src/pages/Dashboard.tsx`  
**Endpoints:**
- `dashboard.stats` - Retorna métricas gerais

**Funcionalidades:**
- 6 cards de métricas (orçamentos, OS, contas, estoque, folha)
- Gráficos de pizza e barras
- Lista de atividades recentes
- Próximos agendamentos

**Problemas Conhecidos:**
- Nenhum

---

### 2. Orçamentos
**Status:** ⚠️ Parcialmente Funcional  
**Arquivo:** `client/src/pages/Orcamentos.tsx`  
**Endpoints:**
- `orcamentos.list` - Lista orçamentos
- `orcamentos.getById` - Busca por ID
- `orcamentos.create` - Cria orçamento
- `orcamentos.update` - Atualiza orçamento
- `orcamentos.delete` - Remove orçamento
- `orcamentos.generatePDF` - Gera PDF
- `orcamentos.sendEmail` - Envia por e-mail

**Funcionalidades:**
- CRUD completo
- Busca por placa
- Geração de PDF
- Envio por e-mail
- Impressão
- Múltiplos status (pendente, aprovado, recusado, concluído)

**Problemas Conhecidos:**
- ❌ **Geração de PDF falhando** (erro 500)
- ❌ **Envio de e-mail não testado**
- ⚠️ Campo "Prazo de Entrega" existe no banco mas não aparece no formulário

---

### 3. Orçamentos Externos
**Status:** ✅ Funcional  
**Arquivo:** `client/src/pages/OrcamentosExternos.tsx`  
**Endpoints:**
- `orcamentosExternos.upload` - Upload de PDF
- `orcamentosExternos.list` - Lista uploads

**Funcionalidades:**
- Upload de PDF de orçamentos externos
- Extração automática de dados via IA
- Conversão para orçamento interno

**Problemas Conhecidos:**
- Nenhum

---

### 4. Ordens de Serviço
**Status:** ✅ Funcional  
**Arquivo:** `client/src/pages/OrdensServico.tsx`  
**Endpoints:**
- `ordensServico.list`
- `ordensServico.create`
- `ordensServico.update`
- `ordensServico.delete`

**Funcionalidades:**
- CRUD completo
- Status: aguardando, em execução, concluída, cancelada
- Vinculação com orçamentos
- Gestão de peças e serviços

**Problemas Conhecidos:**
- Nenhum

---

### 5. Clientes
**Status:** ✅ Funcional (Testado)  
**Arquivo:** `client/src/pages/Clientes.tsx`  
**Endpoints:**
- `clientes.list`
- `clientes.create`
- `clientes.update`
- `clientes.delete`

**Funcionalidades:**
- Cadastro PF/PJ
- Busca por nome/CPF/CNPJ
- Histórico de orçamentos e OS

**Problemas Conhecidos:**
- Nenhum

---

### 6. Veículos
**Status:** ✅ Funcional  
**Arquivo:** `client/src/pages/Veiculos.tsx`  
**Endpoints:**
- `veiculos.list`
- `veiculos.create`
- `veiculos.update`
- `veiculos.delete`

**Funcionalidades:**
- Cadastro completo de veículos
- 6 status: disponível, em serviço, aguardando peças, aguardando aprovação, pronto, entregue
- Busca por placa
- Histórico de serviços

**Problemas Conhecidos:**
- Nenhum

---

### 7. Financeiro
**Status:** ✅ Funcional  
**Arquivo:** `client/src/pages/Financeiro.tsx`  
**Endpoints:**
- `financeiro.list`
- `financeiro.create`
- `financeiro.update`
- `financeiro.delete`
- `financeiro.marcarPaga`

**Funcionalidades:**
- Contas a pagar e receber
- Filtros por tipo, status, cliente
- Gráficos de receitas/despesas
- Marcação de pagamento

**Problemas Conhecidos:**
- ⚠️ Filtros podem estar com problema de performance em grandes volumes

---

### 8. Estoque
**Status:** ✅ Funcional  
**Arquivo:** `client/src/pages/Estoque.tsx`  
**Endpoints:**
- `estoque.list`
- `estoque.create`
- `estoque.update`
- `estoque.delete`
- `estoque.movimentar`

**Funcionalidades:**
- Cadastro de produtos
- Controle de estoque mínimo
- Movimentações (entrada/saída)
- Alertas de estoque baixo

**Problemas Conhecidos:**
- Nenhum

---

### 9. Agendamentos
**Status:** ✅ Funcional  
**Arquivo:** `client/src/pages/Agendamentos.tsx`  
**Endpoints:**
- `agendamentos.list`
- `agendamentos.create`
- `agendamentos.update`
- `agendamentos.delete`

**Funcionalidades:**
- Calendário de agendamentos
- Múltiplos status
- Vinculação com clientes e veículos

**Problemas Conhecidos:**
- Nenhum

---

### 10. Colaboradores
**Status:** ✅ Funcional (Corrigido)  
**Arquivo:** `client/src/pages/Colaboradores.tsx`  
**Endpoints:**
- `colaboradores.list`
- `colaboradores.create`
- `colaboradores.update`
- `colaboradores.delete`
- `colaboradores.gerarPagamento`
- `colaboradores.registrarAdiantamento`
- `colaboradores.proximosPagamentos`

**Funcionalidades:**
- Cadastro de colaboradores
- Folha de pagamento (semanal, quinzenal, mensal)
- Adiantamentos
- Histórico de pagamentos
- Alertas de pagamentos próximos

**Problemas Conhecidos:**
- ✅ **CORRIGIDO**: Erro ao abrir dropdown dentro de Dialog (fix: container={dialogRef.current})

---

### 11. Relatórios
**Status:** ⚠️ Não Implementado  
**Arquivo:** `client/src/pages/Relatorios.tsx`  
**Endpoints:** Nenhum

**Funcionalidades:**
- Página placeholder

**Problemas Conhecidos:**
- ❌ Módulo não implementado

---

## 🐛 Problemas Conhecidos

### Críticos (Impedem Uso)

1. **Geração de PDF falhando**
   - **Módulo:** Orçamentos
   - **Erro:** HTTP 500 ao clicar em "Download PDF"
   - **Arquivo:** Provavelmente `server/routers.ts` (endpoint `orcamentos.generatePDF`)
   - **Impacto:** Alto - Funcionalidade essencial não funciona

2. **Erro de autenticação intermitente**
   - **Módulo:** Todos
   - **Erro:** "UNAUTHORIZED" em requisições aleatórias
   - **Arquivo:** `server/_core/context.ts`
   - **Impacto:** Alto - Usuário perde sessão sem motivo aparente

### Médios (Funcionalidade Limitada)

3. **Envio de e-mail não testado**
   - **Módulo:** Orçamentos
   - **Status:** Código implementado mas não testado
   - **Arquivo:** `server/routers.ts` (endpoint `orcamentos.sendEmail`)
   - **Impacto:** Médio - Não sabemos se funciona

4. **Campo "Prazo de Entrega" invisível**
   - **Módulo:** Orçamentos
   - **Problema:** Campo existe no banco (`prazoEntrega`) mas não aparece no formulário
   - **Arquivo:** `client/src/pages/OrcamentoNovo.tsx`
   - **Impacto:** Médio - Funcionalidade planejada mas não acessível

5. **Relatórios não implementado**
   - **Módulo:** Relatórios
   - **Status:** Apenas placeholder
   - **Impacto:** Médio - Módulo prometido mas vazio

### Baixos (Melhorias)

6. **Performance de filtros no Financeiro**
   - **Módulo:** Financeiro
   - **Problema:** Filtros podem ser lentos com muitos registros
   - **Arquivo:** `client/src/pages/Financeiro.tsx`
   - **Impacto:** Baixo - Só afeta com grande volume de dados

7. **Erro TypeScript ignorado**
   - **Arquivo:** `client/src/pages/Orcamentos.tsx:91`
   - **Erro:** `Parameter 'orc' implicitly has an 'any' type`
   - **Impacto:** Baixo - Não afeta funcionamento mas indica má prática

---

## 🔐 Variáveis de Ambiente

### Arquivo: `.env.example`

```bash
# ============================================
# BANCO DE DADOS
# ============================================
DATABASE_URL="mysql://user:password@host:port/database"

# ============================================
# AUTENTICAÇÃO
# ============================================
JWT_SECRET="sua-chave-secreta-minimo-32-caracteres"
OAUTH_SERVER_URL="https://api.manus.im"
VITE_OAUTH_PORTAL_URL="https://portal.manus.im"
VITE_APP_ID="seu-app-id"

# ============================================
# PROPRIETÁRIO (Primeiro Admin)
# ============================================
OWNER_OPEN_ID="openid-do-proprietario"
OWNER_NAME="Nome do Proprietário"

# ============================================
# APLICAÇÃO
# ============================================
VITE_APP_TITLE="Aliança Auto Center - Sistema Completo"
VITE_APP_LOGO="/logo.png"

# ============================================
# ANALYTICS (Opcional)
# ============================================
VITE_ANALYTICS_WEBSITE_ID=""
VITE_ANALYTICS_ENDPOINT=""

# ============================================
# APIs EXTERNAS (Manus Built-in)
# ============================================
BUILT_IN_FORGE_API_URL="https://forge.manus.im"
BUILT_IN_FORGE_API_KEY="sua-chave-api"
VITE_FRONTEND_FORGE_API_URL="https://forge.manus.im"
VITE_FRONTEND_FORGE_API_KEY="sua-chave-api-frontend"
```

### Descrição das Variáveis

| Variável | Obrigatória | Descrição |
|----------|-------------|-----------|
| `DATABASE_URL` | ✅ Sim | String de conexão MySQL/TiDB |
| `JWT_SECRET` | ✅ Sim | Chave secreta para assinar tokens JWT (mínimo 32 caracteres) |
| `OAUTH_SERVER_URL` | ✅ Sim | URL do servidor OAuth da Manus |
| `VITE_OAUTH_PORTAL_URL` | ✅ Sim | URL do portal de login |
| `VITE_APP_ID` | ✅ Sim | ID da aplicação OAuth |
| `OWNER_OPEN_ID` | ✅ Sim | OpenID do primeiro usuário admin |
| `OWNER_NAME` | ⚠️ Recomendado | Nome do proprietário |
| `VITE_APP_TITLE` | ⚠️ Recomendado | Título da aplicação |
| `VITE_APP_LOGO` | ⚠️ Recomendado | Caminho do logo |
| `BUILT_IN_FORGE_API_KEY` | ⚠️ Condicional | Necessário para upload de PDFs e IA |
| `VITE_ANALYTICS_*` | ❌ Opcional | Para analytics |

---

## 🗄️ Banco de Dados

### Schema Principal

O schema completo está em `drizzle/schema.ts`. Principais tabelas:

#### 1. `users` - Usuários do Sistema
```typescript
{
  id: int (PK, auto-increment)
  openId: varchar(64) UNIQUE
  name: text
  email: varchar(320)
  loginMethod: varchar(64)
  role: enum('user', 'admin')
  createdAt: timestamp
  updatedAt: timestamp
  lastSignedIn: timestamp
}
```

#### 2. `clientes` - Clientes
```typescript
{
  id: int (PK)
  tipo: enum('PF', 'PJ')
  nome: text
  cpfCnpj: varchar(18)
  telefone: varchar(20)
  email: varchar(320)
  endereco: text
  cidade: varchar(100)
  estado: varchar(2)
  cep: varchar(9)
  observacoes: text
  createdAt: timestamp
  updatedAt: timestamp
}
```

#### 3. `veiculos` - Veículos
```typescript
{
  id: int (PK)
  clienteId: int (FK -> clientes)
  placa: varchar(10)
  marca: varchar(50)
  modelo: varchar(50)
  ano: int
  cor: varchar(30)
  km: int
  status: enum('disponivel', 'em_servico', 'aguardando_pecas', 'aguardando_aprovacao', 'pronto', 'entregue')
  observacoes: text
  createdAt: timestamp
  updatedAt: timestamp
}
```

#### 4. `orcamentos` - Orçamentos
```typescript
{
  id: int (PK)
  numero: varchar(20) UNIQUE
  clienteId: int (FK -> clientes)
  veiculoId: int (FK -> veiculos)
  dataEntrada: datetime
  prazoEntrega: datetime
  status: enum('pendente', 'aprovado', 'recusado', 'concluido')
  numeroOS: varchar(20)
  observacoes: text
  subtotal: decimal(10,2)
  desconto: decimal(10,2)
  total: decimal(10,2)
  createdAt: timestamp
  updatedAt: timestamp
}
```

#### 5. `orcamento_itens` - Itens do Orçamento
```typescript
{
  id: int (PK)
  orcamentoId: int (FK -> orcamentos)
  categoria: enum('peca', 'servico', 'mao_de_obra')
  descricao: text
  quantidade: int
  valorUnitario: decimal(10,2)
  valorTotal: decimal(10,2)
}
```

#### 6. `ordens_servico` - Ordens de Serviço
```typescript
{
  id: int (PK)
  numero: varchar(20) UNIQUE
  orcamentoId: int (FK -> orcamentos)
  clienteId: int (FK -> clientes)
  veiculoId: int (FK -> veiculos)
  dataInicio: datetime
  dataPrevista: datetime
  dataConclusao: datetime
  status: enum('aguardando', 'em_execucao', 'concluida', 'cancelada')
  observacoes: text
  createdAt: timestamp
  updatedAt: timestamp
}
```

#### 7. `colaboradores` - Colaboradores
```typescript
{
  id: int (PK)
  nome: varchar(255)
  cargo: varchar(100)
  salario: decimal(10,2)
  tipoPagamento: enum('semanal', 'quinzenal', 'mensal')
  diaSemana: enum('domingo', 'segunda', 'terca', 'quarta', 'quinta', 'sexta', 'sabado')
  diaQuinzena: int
  diaMes: int
  dataAdmissao: date
  status: enum('ativo', 'inativo')
  observacoes: text
  createdAt: timestamp
  updatedAt: timestamp
}
```

#### 8. `financeiro` - Contas a Pagar/Receber
```typescript
{
  id: int (PK)
  tipo: enum('pagar', 'receber')
  descricao: text
  valor: decimal(10,2)
  dataVencimento: date
  dataPagamento: date
  status: enum('pendente', 'paga', 'atrasada')
  clienteId: int (FK -> clientes)
  categoria: varchar(100)
  observacoes: text
  createdAt: timestamp
  updatedAt: timestamp
}
```

#### 9. `estoque` - Produtos em Estoque
```typescript
{
  id: int (PK)
  nome: varchar(255)
  descricao: text
  categoria: varchar(100)
  quantidade: int
  quantidadeMinima: int
  valorUnitario: decimal(10,2)
  fornecedor: varchar(255)
  localizacao: varchar(100)
  createdAt: timestamp
  updatedAt: timestamp
}
```

#### 10. `agendamentos` - Agendamentos
```typescript
{
  id: int (PK)
  clienteId: int (FK -> clientes)
  veiculoId: int (FK -> veiculos)
  dataHora: datetime
  tipo: varchar(100)
  descricao: text
  status: enum('agendado', 'confirmado', 'em_andamento', 'concluido', 'cancelado')
  observacoes: text
  createdAt: timestamp
  updatedAt: timestamp
}
```

### Exportar Dump do Banco

```bash
# Dump completo (estrutura + dados)
mysqldump -u root -p alianca_auto_center > dump_completo.sql

# Apenas estrutura (schema)
mysqldump -u root -p --no-data alianca_auto_center > schema.sql

# Apenas dados de teste (sem tabela users)
mysqldump -u root -p alianca_auto_center \
  --ignore-table=alianca_auto_center.users \
  > dados_teste.sql
```

---

## 🧪 Testes

### Executar Testes

```bash
# Testes unitários (se implementados)
pnpm test

# Verificação de tipos
pnpm type-check

# Lint
pnpm lint
```

### Status dos Testes
⚠️ **Nenhum teste automatizado implementado ainda**

Recomendações para auditoria:
- Implementar testes unitários para `server/db.ts`
- Implementar testes de integração para endpoints tRPC
- Implementar testes E2E para fluxos críticos (criar orçamento, gerar PDF)

---

## 📊 Logs do Sistema

### Localização dos Logs

```bash
# Logs do servidor (stdout)
# Não há arquivo de log persistente, apenas console output

# Para capturar logs em produção, redirecionar stdout:
pnpm start > logs/app.log 2>&1

# Logs do TypeScript compiler
# Exibidos no terminal durante `pnpm dev`
```

### Logs Recentes

Veja arquivo `LOGS.txt` anexo para últimas 300 linhas de log.

---

## 🔒 Segurança

### Práticas Implementadas
- ✅ Autenticação via OAuth + JWT
- ✅ Senhas não armazenadas (OAuth externo)
- ✅ CORS configurado
- ✅ Cookies HTTP-only
- ✅ Validação de entrada com Zod

### Pontos de Atenção
- ⚠️ JWT_SECRET deve ser forte (mínimo 32 caracteres)
- ⚠️ DATABASE_URL não deve estar em código
- ⚠️ Rate limiting não implementado
- ⚠️ HTTPS obrigatório em produção

---

## 📞 Suporte

### Contato para Dúvidas Técnicas
- **Desenvolvedor Original:** Manus AI
- **Plataforma:** Manus (https://manus.im)
- **Versão do Checkpoint:** 433fdbad

### Recursos Adicionais
- Documentação tRPC: https://trpc.io
- Documentação Drizzle ORM: https://orm.drizzle.team
- Documentação React 19: https://react.dev

---

## 📝 Notas para Auditoria

### Prioridades Sugeridas

1. **Crítico - Corrigir geração de PDF**
   - Investigar endpoint `orcamentos.generatePDF`
   - Verificar logs de erro detalhados
   - Testar com dados reais

2. **Crítico - Estabilizar autenticação**
   - Investigar expiração de sessão
   - Verificar renovação de tokens
   - Adicionar logs de debug

3. **Alto - Testar envio de e-mail**
   - Configurar SMTP
   - Testar com diferentes provedores
   - Adicionar tratamento de erro

4. **Médio - Implementar Relatórios**
   - Definir relatórios necessários
   - Implementar queries
   - Criar interface

5. **Baixo - Melhorias de Performance**
   - Adicionar índices no banco
   - Implementar paginação
   - Otimizar queries

### Arquivos Mais Importantes

1. `server/routers.ts` - **TODAS AS ROTAS DA API**
2. `server/db.ts` - **TODAS AS QUERIES**
3. `drizzle/schema.ts` - **SCHEMA DO BANCO**
4. `client/src/pages/Orcamentos.tsx` - **MÓDULO COM MAIS PROBLEMAS**
5. `server/_core/context.ts` - **AUTENTICAÇÃO**

---

**Documento gerado em:** 08/11/2025  
**Versão do Sistema:** 433fdbad  
**Autor:** Manus AI
