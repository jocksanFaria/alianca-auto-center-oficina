import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Dashboard from "./pages/Dashboard";
import Orcamentos from "./pages/Orcamentos";
import NovoOrcamento from "./pages/OrcamentoNovo";
import VisualizarOrcamento from "./pages/OrcamentoView";
import EditarOrcamento from "./pages/OrcamentoEditar";
import OrdensServico from "./pages/OrdensServico";
import Clientes from "./pages/Clientes";
import Veiculos from "./pages/Veiculos";
import Financeiro from "./pages/Financeiro";
import Estoque from "./pages/Estoque";
import Agendamentos from "./pages/Agendamentos";
import Colaboradores from "./pages/Colaboradores";
import OrcamentosExternos from "./pages/OrcamentosExternos";
import Relatorios from "./pages/Relatorios";
import Administracao from "./pages/Administracao";
// import GestaoUsuarios from "./pages/GestaoUsuarios"; // Desabilitado

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/orcamentos" component={Orcamentos} />
      <Route path="/orcamentos/novo" component={NovoOrcamento} />
      <Route path="/orcamentos/:id" component={VisualizarOrcamento} />
      <Route path="/orcamentos/:id/editar" component={EditarOrcamento} />
      <Route path="/orcamentos-externos" component={OrcamentosExternos} />
      <Route path="/ordens-servico" component={OrdensServico} />
      <Route path="/clientes" component={Clientes} />
      <Route path="/veiculos" component={Veiculos} />
      <Route path="/financeiro" component={Financeiro} />
      <Route path="/estoque" component={Estoque} />
      <Route path="/agendamentos" component={Agendamentos} />
      <Route path="/colaboradores" component={Colaboradores} />
      <Route path="/relatorios" component={Relatorios} />
      <Route path="/administracao" component={Administracao} />
      {/* <Route path="/gestao-usuarios" component={GestaoUsuarios} /> */}
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
