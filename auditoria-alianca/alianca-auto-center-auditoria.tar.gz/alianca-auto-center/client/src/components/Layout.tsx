import { useAuth } from "@/_core/hooks/useAuth";
import { APP_TITLE } from "@/const";
import { Button } from "@/components/ui/button";
import { 
  LayoutDashboard, 
  FileText, 
  ClipboardList, 
  Users, 
  Car, 
  DollarSign, 
  Package, 
  Calendar,
  Settings,
  Menu,
  X,
  LogOut,
  BarChart3,
  UserCircle
} from "lucide-react";
import { Link, useLocation } from "wouter";
import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";


interface LayoutProps {
  children: React.ReactNode;
}

const menuItems = [
  { path: "/", icon: LayoutDashboard, label: "Dashboard", color: "text-blue-400" },
  { path: "/orcamentos", icon: FileText, label: "Orçamentos", color: "text-purple-400" },
  { path: "/orcamentos-externos", icon: FileText, label: "Orçamentos Externos", color: "text-purple-300" },
  { path: "/ordens-servico", icon: ClipboardList, label: "Ordens de Serviço", color: "text-orange-400" },
  { path: "/clientes", icon: Users, label: "Clientes", color: "text-green-400" },
  { path: "/veiculos", icon: Car, label: "Veículos", color: "text-cyan-400" },
  { path: "/financeiro", icon: DollarSign, label: "Financeiro", color: "text-yellow-400" },
  { path: "/relatorios", icon: BarChart3, label: "Relatórios", color: "text-pink-400" },
  { path: "/colaboradores", icon: UserCircle, label: "Colaboradores", color: "text-blue-300" },
  { path: "/estoque", icon: Package, label: "Estoque", color: "text-indigo-400" },
  { path: "/agendamentos", icon: Calendar, label: "Agendamentos", color: "text-teal-400" },
];

export default function Layout({ children }: LayoutProps) {
  const { user } = useAuth();
  const [location] = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const logoutMutation = trpc.auth.logout.useMutation();

  const handleLogout = async () => {
    try {
      await logoutMutation.mutateAsync();
      window.location.href = "/";
    } catch (error) {
      toast.error("Erro ao sair");
    }
  };

  // Todos os usuários autenticados têm acesso a todos os módulos
  const filteredMenuItems = menuItems;

  return (
    <div className="flex h-screen bg-background">
      {/* Sidebar - Desktop */}
      <aside className="hidden lg:flex lg:flex-col lg:w-64 lg:fixed lg:inset-y-0 bg-sidebar border-r border-sidebar-border shadow-xl">
        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className="flex items-center h-16 px-6 border-b border-sidebar-border">
            <h1 className="text-xl font-bold text-sidebar-foreground">{APP_TITLE}</h1>
          </div>

          {/* Navigation */}
          <nav className="flex-1 overflow-y-auto py-4">
            {filteredMenuItems.map((item) => {
              const Icon = item.icon;
              const isActive = location === item.path || location.startsWith(item.path + '/');
              
              return (
                <Link key={item.path} href={item.path}>
                  <a
                    className={`
                      flex items-center gap-3 px-6 py-3 text-sm font-medium transition-all duration-200
                      ${isActive 
                        ? 'bg-sidebar-accent text-sidebar-accent-foreground border-r-4 border-primary' 
                        : 'text-sidebar-foreground hover:bg-sidebar-accent/50 hover:translate-x-1'
                      }
                    `}
                  >
                    <Icon className={`h-5 w-5 ${isActive ? 'text-sidebar-accent-foreground' : item.color}`} />
                    {item.label}
                  </a>
                </Link>
              );
            })}
          </nav>

          {/* User Info */}
          <div className="border-t border-sidebar-border p-4 bg-sidebar/50">
            <div className="flex items-center gap-3 mb-3">
              <div className="h-10 w-10 rounded-full bg-gradient-to-br from-blue-500 to-blue-700 flex items-center justify-center text-white font-semibold shadow-lg">
                {user?.name?.charAt(0).toUpperCase() || 'U'}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-sidebar-foreground truncate">
                  {user?.name || 'Usuário'}
                </p>
                <p className="text-xs text-muted-foreground truncate">
                  {user?.email || ''}
                </p>
              </div>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="w-full bg-sidebar-accent hover:bg-sidebar-accent/80 text-sidebar-foreground border-sidebar-border"
              onClick={handleLogout}
            >
              <LogOut className="h-4 w-4 mr-2" />
              Sair
            </Button>
          </div>
        </div>
      </aside>

      {/* Mobile Sidebar */}
      <aside
        className={`
          fixed top-0 left-0 z-50 h-full w-64 bg-sidebar border-r border-sidebar-border shadow-xl transform transition-transform duration-200 ease-in-out lg:hidden
          ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}
        `}
      >
        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className="flex items-center h-16 px-6 border-b border-sidebar-border">
            <h1 className="text-xl font-bold text-sidebar-foreground">{APP_TITLE}</h1>
          </div>

          {/* Navigation */}
          <nav className="flex-1 overflow-y-auto py-4">
            {filteredMenuItems.map((item) => {
              const Icon = item.icon;
              const isActive = location === item.path || location.startsWith(item.path + '/');
              
              return (
                <Link key={item.path} href={item.path}>
                  <a
                    className={`
                      flex items-center gap-3 px-6 py-3 text-sm font-medium transition-all duration-200
                      ${isActive 
                        ? 'bg-sidebar-accent text-sidebar-accent-foreground border-r-4 border-primary' 
                        : 'text-sidebar-foreground hover:bg-sidebar-accent/50 hover:translate-x-1'
                      }
                    `}
                    onClick={() => setSidebarOpen(false)}
                  >
                    <Icon className={`h-5 w-5 ${isActive ? 'text-sidebar-accent-foreground' : item.color}`} />
                    {item.label}
                  </a>
                </Link>
              );
            })}
          </nav>

          {/* User Info */}
          <div className="border-t border-sidebar-border p-4 bg-sidebar/50">
            <div className="flex items-center gap-3 mb-3">
              <div className="h-10 w-10 rounded-full bg-gradient-to-br from-blue-500 to-blue-700 flex items-center justify-center text-white font-semibold shadow-lg">
                {user?.name?.charAt(0).toUpperCase() || 'U'}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-sidebar-foreground truncate">
                  {user?.name || 'Usuário'}
                </p>
                <p className="text-xs text-muted-foreground truncate">
                  {user?.email || ''}
                </p>
              </div>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="w-full bg-sidebar-accent hover:bg-sidebar-accent/80 text-sidebar-foreground border-sidebar-border"
              onClick={handleLogout}
            >
              <LogOut className="h-4 w-4 mr-2" />
              Sair
            </Button>
          </div>
        </div>
      </aside>

      {/* Overlay for mobile */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Main Content Area */}
      <div className="flex flex-col flex-1 lg:ml-64">
        {/* Mobile Header */}
        <div className="lg:hidden bg-gradient-to-r from-blue-600 to-blue-700 border-b border-sidebar-border px-4 py-3 flex items-center justify-between sticky top-0 z-30 shadow-lg">
          <h1 className="text-lg font-bold text-white">{APP_TITLE}</h1>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setSidebarOpen(!sidebarOpen)}
          >
            {sidebarOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </Button>
        </div>

        {/* Main Content */}
        <main className="flex-1 overflow-auto">
          <div className="p-4 lg:p-8">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
