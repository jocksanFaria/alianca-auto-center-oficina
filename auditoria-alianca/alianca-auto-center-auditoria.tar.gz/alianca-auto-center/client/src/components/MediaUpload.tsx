import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Camera, Upload, X, FileVideo, Image as ImageIcon } from "lucide-react";
import { toast } from "sonner";

interface MediaFile {
  id: string;
  file: File;
  preview: string;
  type: 'image' | 'video';
}

interface MediaUploadProps {
  onMediaChange: (files: File[]) => void;
  maxVideoSize?: number; // em MB
  maxImageSize?: number; // em MB
}

export function MediaUpload({ 
  onMediaChange, 
  maxVideoSize = 50,
  maxImageSize = 10 
}: MediaUploadProps) {
  const [mediaFiles, setMediaFiles] = useState<MediaFile[]>([]);

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    processFiles(files);
  };

  const processFiles = (files: File[]) => {
    const newMedia: MediaFile[] = [];

    files.forEach(file => {
      const isVideo = file.type.startsWith('video/');
      const isImage = file.type.startsWith('image/');

      if (!isVideo && !isImage) {
        toast.error(`Arquivo ${file.name} não é uma imagem ou vídeo válido`);
        return;
      }

      const maxSize = isVideo ? maxVideoSize : maxImageSize;
      const fileSizeMB = file.size / (1024 * 1024);

      if (fileSizeMB > maxSize) {
        toast.error(`${file.name} excede o tamanho máximo de ${maxSize}MB`);
        return;
      }

      const preview = URL.createObjectURL(file);
      newMedia.push({
        id: Math.random().toString(36).substr(2, 9),
        file,
        preview,
        type: isVideo ? 'video' : 'image'
      });
    });

    const updated = [...mediaFiles, ...newMedia];
    setMediaFiles(updated);
    onMediaChange(updated.map(m => m.file));
  };

  const removeMedia = (id: string) => {
    const updated = mediaFiles.filter(m => m.id !== id);
    setMediaFiles(updated);
    onMediaChange(updated.map(m => m.file));
  };

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <Button
          type="button"
          variant="outline"
          onClick={() => document.getElementById('camera-input')?.click()}
          className="flex-1"
        >
          <Camera className="w-4 h-4 mr-2" />
          Tirar Foto
        </Button>
        <Button
          type="button"
          variant="outline"
          onClick={() => document.getElementById('file-input')?.click()}
          className="flex-1"
        >
          <Upload className="w-4 h-4 mr-2" />
          Upload
        </Button>
      </div>

      <input
        id="camera-input"
        type="file"
        accept="image/*"
        capture="environment"
        multiple
        onChange={handleFileSelect}
        className="hidden"
      />
      <input
        id="file-input"
        type="file"
        accept="image/*,video/*"
        multiple
        onChange={handleFileSelect}
        className="hidden"
      />

      {mediaFiles.length > 0 && (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {mediaFiles.map(media => (
            <Card key={media.id} className="relative p-2">
              <button
                type="button"
                onClick={() => removeMedia(media.id)}
                className="absolute -top-2 -right-2 bg-destructive text-destructive-foreground rounded-full p-1 hover:bg-destructive/90 z-10"
              >
                <X className="w-4 h-4" />
              </button>
              
              {media.type === 'image' ? (
                <div className="aspect-video relative bg-muted rounded overflow-hidden">
                  <img
                    src={media.preview}
                    alt="Preview"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute bottom-1 left-1 bg-black/60 text-white px-2 py-0.5 rounded text-xs flex items-center gap-1">
                    <ImageIcon className="w-3 h-3" />
                    Foto
                  </div>
                </div>
              ) : (
                <div className="aspect-video relative bg-muted rounded overflow-hidden">
                  <video
                    src={media.preview}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute bottom-1 left-1 bg-black/60 text-white px-2 py-0.5 rounded text-xs flex items-center gap-1">
                    <FileVideo className="w-3 h-3" />
                    Vídeo
                  </div>
                </div>
              )}
              
              <p className="text-xs text-muted-foreground mt-1 truncate">
                {media.file.name}
              </p>
              <p className="text-xs text-muted-foreground">
                {(media.file.size / (1024 * 1024)).toFixed(2)} MB
              </p>
            </Card>
          ))}
        </div>
      )}

      <p className="text-xs text-muted-foreground">
        Fotos: até {maxImageSize}MB | Vídeos: até {maxVideoSize}MB
      </p>
    </div>
  );
}
