import { BarChart, Bar, ResponsiveContainer, XAxis } from "recharts";

interface MiniBarChartProps {
  data: Array<{ name: string; value: number }>;
  color: string;
}

export function MiniBarChart({ data, color }: MiniBarChartProps) {
  return (
    <ResponsiveContainer width="100%" height={60}>
      <BarChart data={data}>
        <XAxis dataKey="name" hide />
        <Bar dataKey="value" fill={color} radius={[4, 4, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
}
