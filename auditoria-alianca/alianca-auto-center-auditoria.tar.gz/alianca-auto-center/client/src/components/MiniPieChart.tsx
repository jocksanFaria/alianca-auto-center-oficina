import { PieChart, Pie, Cell, ResponsiveContainer } from "recharts";

interface MiniPieChartProps {
  value: number;
  total: number;
  colors: string[];
}

export function MiniPieChart({ value, total, colors }: MiniPieChartProps) {
  const data = [
    { name: "Atual", value: value },
    { name: "Restante", value: Math.max(0, total - value) },
  ];

  return (
    <ResponsiveContainer width="100%" height={80}>
      <PieChart>
        <Pie
          data={data}
          cx="50%"
          cy="50%"
          innerRadius={20}
          outerRadius={35}
          paddingAngle={2}
          dataKey="value"
        >
          {data.map((_, index) => (
            <Cell key={`cell-${index}`} fill={colors[index]} />
          ))}
        </Pie>
      </PieChart>
    </ResponsiveContainer>
  );
}
