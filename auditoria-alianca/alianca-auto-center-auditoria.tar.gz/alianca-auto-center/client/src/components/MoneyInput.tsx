import { Input } from "@/components/ui/input";
import { formatarInputMoeda, reaisParaCentavos } from "@/lib/currency";
import { useState, useEffect } from "react";

interface MoneyInputProps {
  value: number; // valor em centavos
  onChange: (centavos: number) => void;
  placeholder?: string;
  disabled?: boolean;
  className?: string;
}

export function MoneyInput({ value, onChange, placeholder = "0,00", disabled, className }: MoneyInputProps) {
  const [displayValue, setDisplayValue] = useState("");

  useEffect(() => {
    // Atualiza o display quando o valor externo muda
    if (value === 0 && displayValue === "") return;
    const formatted = formatarInputMoeda(String(value));
    if (formatted !== displayValue) {
      setDisplayValue(formatted);
    }
  }, [value]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputValue = e.target.value;
    
    // Remove tudo exceto números
    const numeros = inputValue.replace(/\D/g, '');
    
    if (!numeros) {
      setDisplayValue("");
      onChange(0);
      return;
    }
    
    // Formata o valor
    const formatted = formatarInputMoeda(numeros);
    setDisplayValue(formatted);
    
    // Converte para centavos e notifica
    const centavos = parseInt(numeros);
    onChange(centavos);
  };

  return (
    <div className="relative">
      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
        R$
      </span>
      <Input
        type="text"
        value={displayValue}
        onChange={handleChange}
        placeholder={placeholder}
        disabled={disabled}
        className={`pl-10 ${className}`}
      />
    </div>
  );
}
