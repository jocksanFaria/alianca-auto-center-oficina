export { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";

export const APP_TITLE = import.meta.env.VITE_APP_TITLE || "Aliança Auto Center";

export const APP_LOGO =
  import.meta.env.VITE_APP_LOGO ||
  "https://placehold.co/128x128/E1E7EF/1F2937?text=App";

// Generate login URL at runtime so redirect URI reflects the current origin.
export const getLoginUrl = () => {
  const oauthPortalUrl = import.meta.env.VITE_OAUTH_PORTAL_URL;
  const appId = import.meta.env.VITE_APP_ID;
  const redirectUri = `${window.location.origin}/api/oauth/callback`;
  const state = btoa(redirectUri);

  const url = new URL(`${oauthPortalUrl}/app-auth`);
  url.searchParams.set("appId", appId);
  url.searchParams.set("redirectUri", redirectUri);
  url.searchParams.set("state", state);
  url.searchParams.set("type", "signIn");

  return url.toString();
};

// Limites de upload
export const MAX_FILE_SIZE = {
  FOTO: 10 * 1024 * 1024, // 10 MB
  VIDEO: 50 * 1024 * 1024, // 50 MB
  PDF: 20 * 1024 * 1024, // 20 MB
};

// Status de orçamentos
export const STATUS_ORCAMENTO = {
  pendente: { label: "Pendente", color: "yellow" },
  aprovado: { label: "Aprovado", color: "green" },
  rejeitado: { label: "Rejeitado", color: "red" },
  em_execucao: { label: "Em Execução", color: "blue" },
  concluido: { label: "Concluído", color: "gray" },
};

// Status de OS
export const STATUS_OS = {
  aguardando: { label: "Aguardando", color: "yellow" },
  em_execucao: { label: "Em Execução", color: "blue" },
  concluido: { label: "Concluído", color: "green" },
};

// Níveis de acesso
export const NIVEIS_ACESSO = {
  admin: { label: "Administrador", descricao: "Acesso total ao sistema" },
  gerente: { label: "Gerente", descricao: "Acesso a relatórios e aprovações" },
  atendente: { label: "Atendente", descricao: "Criar orçamentos e OS" },
  mecanico: { label: "Mecânico", descricao: "Visualizar OS e atualizar status" },
  financeiro: { label: "Financeiro", descricao: "Acesso ao módulo financeiro" },
  personalizado: { label: "Personalizado", descricao: "Permissões customizadas" },
};

// Permissões disponíveis
export const PERMISSOES = {
  dashboard: "Dashboard",
  orcamentos_criar: "Criar Orçamentos",
  orcamentos_editar: "Editar Orçamentos",
  orcamentos_visualizar: "Visualizar Orçamentos",
  orcamentos_excluir: "Excluir Orçamentos",
  orcamentos_enviar_email: "Enviar Orçamentos por E-mail",
  os_criar: "Criar Ordens de Serviço",
  os_editar: "Editar Ordens de Serviço",
  os_visualizar: "Visualizar Ordens de Serviço",
  clientes_gerenciar: "Gerenciar Clientes",
  veiculos_gerenciar: "Gerenciar Veículos",
  financeiro_visualizar: "Visualizar Financeiro",
  financeiro_gerenciar: "Gerenciar Financeiro",
  estoque_visualizar: "Visualizar Estoque",
  estoque_gerenciar: "Gerenciar Estoque",
  agendamentos_gerenciar: "Gerenciar Agendamentos",
  relatorios: "Acessar Relatórios",
  admin_usuarios: "Administrar Usuários",
};