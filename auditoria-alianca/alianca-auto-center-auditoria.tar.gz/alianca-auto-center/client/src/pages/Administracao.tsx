import Layout from "@/components/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Shield, Users, Settings } from "lucide-react";

export default function Administracao() {
  return (
    <Layout>
      <div className="space-y-6">
        <div><h1 className="text-3xl font-bold">Administração</h1><p className="text-gray-600 mt-1">Configurações e controle de acesso</p></div>

        <Tabs defaultValue="usuarios">
          <TabsList>
            <TabsTrigger value="usuarios"><Users className="h-4 w-4 mr-2" />Usuários</TabsTrigger>
            <TabsTrigger value="permissoes"><Shield className="h-4 w-4 mr-2" />Permissões</TabsTrigger>
            <TabsTrigger value="configuracoes"><Settings className="h-4 w-4 mr-2" />Configurações</TabsTrigger>
          </TabsList>

          <TabsContent value="usuarios">
            <Card>
              <CardHeader><CardTitle>Gerenciamento de Usuários</CardTitle></CardHeader>
              <CardContent className="min-h-[300px] flex items-center justify-center">
                <div className="text-center">
                  <Users className="h-16 w-16 mx-auto text-gray-400 mb-4" />
                  <p className="text-gray-500">Funcionalidade em desenvolvimento</p>
                  <p className="text-sm text-gray-400 mt-2">Em breve você poderá criar e gerenciar usuários do sistema</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="permissoes">
            <Card>
              <CardHeader><CardTitle>Controle de Permissões</CardTitle></CardHeader>
              <CardContent className="min-h-[300px] flex items-center justify-center">
                <div className="text-center">
                  <Shield className="h-16 w-16 mx-auto text-gray-400 mb-4" />
                  <p className="text-gray-500">Funcionalidade em desenvolvimento</p>
                  <p className="text-sm text-gray-400 mt-2">Defina quais funcionalidades cada usuário pode acessar</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="configuracoes">
            <Card>
              <CardHeader><CardTitle>Configurações do Sistema</CardTitle></CardHeader>
              <CardContent className="min-h-[300px] flex items-center justify-center">
                <div className="text-center">
                  <Settings className="h-16 w-16 mx-auto text-gray-400 mb-4" />
                  <p className="text-gray-500">Funcionalidade em desenvolvimento</p>
                  <p className="text-sm text-gray-400 mt-2">Configure parâmetros gerais do sistema</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}
