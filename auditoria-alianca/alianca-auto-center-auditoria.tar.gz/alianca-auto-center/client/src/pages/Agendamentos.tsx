import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { Calendar, Plus, Clock, User } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function Agendamentos() {
  const { data: agendamentos, refetch } = trpc.agendamentos.list.useQuery();
  const { data: clientes } = trpc.clientes.list.useQuery();
  const { data: veiculos } = trpc.veiculos.list.useQuery();
  
  const [openNovo, setOpenNovo] = useState(false);

  const getStatusBadge = (status: string) => {
    const config: Record<string, { variant: "default" | "secondary" | "destructive", label: string }> = {
      agendado: { variant: "secondary", label: "Agendado" },
      confirmado: { variant: "default", label: "Confirmado" },
      em_atendimento: { variant: "default", label: "Em Atendimento" },
      concluido: { variant: "default", label: "Concluído" },
      cancelado: { variant: "destructive", label: "Cancelado" },
    };
    const { variant, label } = config[status] || { variant: "secondary" as const, label: status };
    return <Badge variant={variant}>{label}</Badge>;
  };

  // Agrupar agendamentos por data
  const agendamentosPorData = agendamentos?.reduce((acc: any, agendamento: any) => {
    const data = new Date(agendamento.dataHora).toLocaleDateString('pt-BR');
    if (!acc[data]) acc[data] = [];
    acc[data].push(agendamento);
    return acc;
  }, {}) || {};

  const datasOrdenadas = Object.keys(agendamentosPorData).sort((a, b) => {
    const [diaA, mesA, anoA] = a.split('/').map(Number);
    const [diaB, mesB, anoB] = b.split('/').map(Number);
    return new Date(anoA, mesA - 1, diaA).getTime() - new Date(anoB, mesB - 1, diaB).getTime();
  });

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Agendamentos</h1>
            <p className="text-gray-600 mt-1">Gerencie os agendamentos de serviços</p>
          </div>
          <Dialog open={openNovo} onOpenChange={setOpenNovo}>
            <DialogTrigger asChild>
              <Button><Plus className="h-4 w-4 mr-2" />Novo Agendamento</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Novo Agendamento</DialogTitle>
              </DialogHeader>
              <NovoAgendamentoForm 
                clientes={clientes || []} 
                veiculos={veiculos || []}
                onSuccess={() => { setOpenNovo(false); refetch(); }} 
              />
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Agendamentos Hoje</CardTitle>
              <Calendar className="h-5 w-5 text-blue-600" />
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-blue-600">
                {agendamentos?.filter((a: any) => {
                  const hoje = new Date().toDateString();
                  const dataAgendamento = new Date(a.dataHora).toDateString();
                  return hoje === dataAgendamento && a.status !== 'cancelado';
                }).length || 0}
              </p>
              <p className="text-sm text-gray-600 mt-1">Serviços agendados</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Próximos 7 Dias</CardTitle>
              <Clock className="h-5 w-5 text-orange-600" />
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-orange-600">
                {agendamentos?.filter((a: any) => {
                  const hoje = new Date();
                  const dataAgendamento = new Date(a.dataHora);
                  const diff = dataAgendamento.getTime() - hoje.getTime();
                  const dias = diff / (1000 * 3600 * 24);
                  return dias >= 0 && dias <= 7 && a.status !== 'cancelado';
                }).length || 0}
              </p>
              <p className="text-sm text-gray-600 mt-1">Agendamentos confirmados</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Total de Clientes</CardTitle>
              <User className="h-5 w-5 text-green-600" />
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-green-600">{clientes?.length || 0}</p>
              <p className="text-sm text-gray-600 mt-1">Cadastrados no sistema</p>
            </CardContent>
          </Card>
        </div>

        {!agendamentos?.length ? (
          <Card>
            <CardContent className="min-h-[400px] flex items-center justify-center">
              <div className="text-center">
                <Calendar className="h-16 w-16 mx-auto text-gray-400 mb-4" />
                <p className="text-gray-500">Nenhum agendamento cadastrado</p>
                <p className="text-sm text-gray-400 mt-2">Clique em "Novo Agendamento" para começar</p>
              </div>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            {datasOrdenadas.map((data) => (
              <Card key={data}>
                <CardHeader>
                  <CardTitle className="text-lg">{data}</CardTitle>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Horário</TableHead>
                        <TableHead>Cliente</TableHead>
                        <TableHead>Veículo</TableHead>
                        <TableHead>Serviço</TableHead>
                        <TableHead>Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {agendamentosPorData[data].map((agendamento: any) => (
                        <TableRow key={agendamento.id}>
                          <TableCell className="font-medium">
                            {new Date(agendamento.dataHora).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                          </TableCell>
                          <TableCell>Cliente #{agendamento.clienteId}</TableCell>
                          <TableCell>Veículo #{agendamento.veiculoId || '-'}</TableCell>
                          <TableCell>{agendamento.servico}</TableCell>
                          <TableCell>{getStatusBadge(agendamento.status)}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </Layout>
  );
}

function NovoAgendamentoForm({ clientes, veiculos, onSuccess }: { clientes: any[]; veiculos: any[]; onSuccess: () => void }) {
  const [clienteId, setClienteId] = useState("");
  const [veiculoId, setVeiculoId] = useState("");
  const [dataHora, setDataHora] = useState("");
  const [servico, setServico] = useState("");
  const [observacoes, setObservacoes] = useState("");
  
  const createMutation = trpc.agendamentos.create.useMutation();

  const veiculosFiltrados = veiculoId ? veiculos : veiculos.filter((v: any) => v.clienteId === parseInt(clienteId));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await createMutation.mutateAsync({
        clienteId: parseInt(clienteId),
        veiculoId: veiculoId ? parseInt(veiculoId) : undefined,
        dataHora: new Date(dataHora),
        servico,
        observacoes: observacoes || undefined,
      });
      toast.success("Agendamento criado com sucesso!");
      onSuccess();
    } catch {
      toast.error("Erro ao criar agendamento");
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label>Cliente *</Label>
        <Select value={clienteId} onValueChange={setClienteId} required>
          <SelectTrigger>
            <SelectValue placeholder="Selecione um cliente" />
          </SelectTrigger>
          <SelectContent>
            {clientes.map((cliente: any) => (
              <SelectItem key={cliente.id} value={cliente.id.toString()}>
                {cliente.nome}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      
      {clienteId && (
        <div>
          <Label>Veículo (opcional)</Label>
          <Select value={veiculoId} onValueChange={setVeiculoId}>
            <SelectTrigger>
              <SelectValue placeholder="Selecione um veículo" />
            </SelectTrigger>
            <SelectContent>
              {veiculosFiltrados.map((veiculo: any) => (
                <SelectItem key={veiculo.id} value={veiculo.id.toString()}>
                  {veiculo.placa} - {veiculo.modelo}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}
      
      <div>
        <Label>Data e Hora *</Label>
        <Input type="datetime-local" value={dataHora} onChange={(e) => setDataHora(e.target.value)} required />
      </div>
      
      <div>
        <Label>Descrição do Serviço *</Label>
        <Input value={servico} onChange={(e) => setServico(e.target.value)} placeholder="Ex: Revisão completa, Troca de óleo" required />
      </div>
      
      <div>
        <Label>Observações</Label>
        <Textarea value={observacoes} onChange={(e) => setObservacoes(e.target.value)} placeholder="Informações adicionais" rows={3} />
      </div>
      
      <Button type="submit" className="w-full">Criar Agendamento</Button>
    </form>
  );
}
