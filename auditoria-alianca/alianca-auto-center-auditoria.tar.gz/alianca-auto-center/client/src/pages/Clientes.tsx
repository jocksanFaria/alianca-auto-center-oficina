import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { trpc } from "@/lib/trpc";
import { Plus, Pencil, Trash2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function Clientes() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    nome: "", cpfCnpj: "", telefone: "", email: "",
    endereco: "", cidade: "", estado: "", cep: ""
  });

  const { data: clientes, isLoading, refetch } = trpc.clientes.list.useQuery();
  const createMutation = trpc.clientes.create.useMutation();
  const updateMutation = trpc.clientes.update.useMutation();
  const deleteMutation = trpc.clientes.delete.useMutation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingId) {
        await updateMutation.mutateAsync({ id: editingId, ...formData });
        toast.success("Cliente atualizado!");
      } else {
        await createMutation.mutateAsync(formData);
        toast.success("Cliente criado!");
      }
      setDialogOpen(false);
      resetForm();
      refetch();
    } catch (error) {
      toast.error("Erro ao salvar cliente");
    }
  };

  const handleEdit = (cliente: any) => {
    setEditingId(cliente.id);
    setFormData({
      nome: cliente.nome || "", cpfCnpj: cliente.cpfCnpj || "",
      telefone: cliente.telefone || "", email: cliente.email || "",
      endereco: cliente.endereco || "", cidade: cliente.cidade || "",
      estado: cliente.estado || "", cep: cliente.cep || ""
    });
    setDialogOpen(true);
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Excluir este cliente?")) return;
    try {
      await deleteMutation.mutateAsync({ id });
      toast.success("Cliente excluído!");
      refetch();
    } catch (error) {
      toast.error("Erro ao excluir");
    }
  };

  const resetForm = () => {
    setEditingId(null);
    setFormData({ nome: "", cpfCnpj: "", telefone: "", email: "", endereco: "", cidade: "", estado: "", cep: "" });
  };

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Clientes</h1>
            <p className="text-gray-600 mt-1">Gerencie seus clientes</p>
          </div>
          <Button onClick={() => { resetForm(); setDialogOpen(true); }}>
            <Plus className="h-4 w-4 mr-2" />Novo Cliente
          </Button>
        </div>

        <Card>
          <CardHeader><CardTitle>Lista de Clientes</CardTitle></CardHeader>
          <CardContent>
            {isLoading ? <p className="text-center py-8">Carregando...</p> :
             !clientes?.length ? <p className="text-center py-8">Nenhum cliente cadastrado</p> :
             <Table>
               <TableHeader>
                 <TableRow>
                   <TableHead>Nome</TableHead>
                   <TableHead className="hidden md:table-cell">CPF/CNPJ</TableHead>
                   <TableHead className="hidden lg:table-cell">Telefone</TableHead>
                   <TableHead className="text-right">Ações</TableHead>
                 </TableRow>
               </TableHeader>
               <TableBody>
                 {clientes.map((c) => (
                   <TableRow key={c.id}>
                     <TableCell className="font-medium">{c.nome}</TableCell>
                     <TableCell className="hidden md:table-cell">{c.cpfCnpj || "-"}</TableCell>
                     <TableCell className="hidden lg:table-cell">{c.telefone || "-"}</TableCell>
                     <TableCell className="text-right">
                       <Button variant="ghost" size="icon" onClick={() => handleEdit(c)}><Pencil className="h-4 w-4" /></Button>
                       <Button variant="ghost" size="icon" onClick={() => handleDelete(c.id)}><Trash2 className="h-4 w-4 text-red-600" /></Button>
                     </TableCell>
                   </TableRow>
                 ))}
               </TableBody>
             </Table>
            }
          </CardContent>
        </Card>
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingId ? "Editar" : "Novo"} Cliente</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="md:col-span-2">
                <Label>Nome *</Label>
                <Input value={formData.nome} onChange={(e) => setFormData({...formData, nome: e.target.value})} required />
              </div>
              <div><Label>CPF/CNPJ</Label><Input value={formData.cpfCnpj} onChange={(e) => setFormData({...formData, cpfCnpj: e.target.value})} /></div>
              <div><Label>Telefone</Label><Input value={formData.telefone} onChange={(e) => setFormData({...formData, telefone: e.target.value})} /></div>
              <div className="md:col-span-2"><Label>E-mail</Label><Input type="email" value={formData.email} onChange={(e) => setFormData({...formData, email: e.target.value})} /></div>
              <div className="md:col-span-2"><Label>Endereço</Label><Input value={formData.endereco} onChange={(e) => setFormData({...formData, endereco: e.target.value})} /></div>
              <div><Label>Cidade</Label><Input value={formData.cidade} onChange={(e) => setFormData({...formData, cidade: e.target.value})} /></div>
              <div className="grid grid-cols-2 gap-4">
                <div><Label>Estado</Label><Input maxLength={2} value={formData.estado} onChange={(e) => setFormData({...formData, estado: e.target.value.toUpperCase()})} /></div>
                <div><Label>CEP</Label><Input value={formData.cep} onChange={(e) => setFormData({...formData, cep: e.target.value})} /></div>
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>Cancelar</Button>
              <Button type="submit">{editingId ? "Atualizar" : "Criar"}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </Layout>
  );
}
