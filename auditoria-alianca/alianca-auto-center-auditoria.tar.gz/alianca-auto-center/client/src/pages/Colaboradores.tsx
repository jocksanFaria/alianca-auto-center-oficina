import { useState, useRef } from "react";
import Layout from "@/components/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { UserPlus, Edit, Trash2, DollarSign, Calendar, Briefcase } from "lucide-react";

export default function Colaboradores() {
  const dialogRef = useRef<HTMLDivElement>(null);
  const [modalAberto, setModalAberto] = useState(false);
  const [colaboradorEditando, setColaboradorEditando] = useState<any>(null);
  const [filtroStatus, setFiltroStatus] = useState<"todos" | "ativo" | "inativo">("todos");

  // Form states
  const [nome, setNome] = useState("");
  const [cargo, setCargo] = useState("");
  const [salario, setSalario] = useState("");
  const [tipoPagamento, setTipoPagamento] = useState<"semanal" | "quinzenal" | "mensal">("semanal");
  const [diaPagamento, setDiaPagamento] = useState("");
  const [dataAdmissao, setDataAdmissao] = useState("");
  const [status, setStatus] = useState<"ativo" | "inativo">("ativo");
  const [observacoes, setObservacoes] = useState("");

  const { data: colaboradores, refetch } = trpc.colaboradores.list.useQuery();
  const createMutation = trpc.colaboradores.create.useMutation();
  const updateMutation = trpc.colaboradores.update.useMutation();
  const deleteMutation = trpc.colaboradores.delete.useMutation();
  const gerarPagamentoMutation = trpc.colaboradores.gerarPagamento.useMutation();
  
  // Estados para modais
  const [modalAdiantamento, setModalAdiantamento] = useState(false);
  const [modalHistorico, setModalHistorico] = useState(false);
  const [colaboradorSelecionado, setColaboradorSelecionado] = useState<any>(null);
  
  // Form adiantamento
  const [valorAdiantamento, setValorAdiantamento] = useState("");
  const [descricaoAdiantamento, setDescricaoAdiantamento] = useState("");

  const colaboradoresFiltrados = colaboradores?.filter(c => 
    filtroStatus === "todos" || c.status === filtroStatus
  ) || [];

  const abrirModal = (colaborador?: any) => {
    if (colaborador) {
      setColaboradorEditando(colaborador);
      setNome(colaborador.nome);
      setCargo(colaborador.cargo || "");
      setSalario((colaborador.salario / 100).toString());
      setTipoPagamento(colaborador.tipoPagamento);
      setDiaPagamento(colaborador.diaPagamento.toString());
      setDataAdmissao(new Date(colaborador.dataAdmissao).toISOString().split('T')[0]);
      setStatus(colaborador.status);
      setObservacoes(colaborador.observacoes || "");
    } else {
      setColaboradorEditando(null);
      limparFormulario();
    }
    setModalAberto(true);
  };

  const limparFormulario = () => {
    setNome("");
    setCargo("");
    setSalario("");
    setTipoPagamento("semanal");
    setDiaPagamento("");
    setDataAdmissao("");
    setStatus("ativo");
    setObservacoes("");
  };

  const salvarColaborador = async () => {
    if (!nome || !salario || !diaPagamento || !dataAdmissao) {
      toast.error("Preencha todos os campos obrigatórios");
      return;
    }

    const salarioEmCentavos = Math.round(parseFloat(salario) * 100);
    const diaNum = parseInt(diaPagamento);

    try {
      if (colaboradorEditando) {
        await updateMutation.mutateAsync({
          id: colaboradorEditando.id,
          nome,
          cargo: cargo || undefined,
          salario: salarioEmCentavos,
          tipoPagamento,
          diaPagamento: diaNum,
          dataAdmissao: new Date(dataAdmissao),
          status,
          observacoes: observacoes || undefined,
        });
        toast.success("Colaborador atualizado com sucesso!");
      } else {
        await createMutation.mutateAsync({
          nome,
          cargo: cargo || undefined,
          salario: salarioEmCentavos,
          tipoPagamento,
          diaPagamento: diaNum,
          dataAdmissao: new Date(dataAdmissao),
          status,
          observacoes: observacoes || undefined,
        });
        toast.success("Colaborador cadastrado com sucesso!");
      }
      
      refetch();
      setModalAberto(false);
      limparFormulario();
    } catch (error) {
      toast.error("Erro ao salvar colaborador");
      console.error(error);
    }
  };

  const excluirColaborador = async (id: number) => {
    if (!confirm("Tem certeza que deseja excluir este colaborador?")) return;

    try {
      await deleteMutation.mutateAsync({ id });
      toast.success("Colaborador excluído com sucesso!");
      refetch();
    } catch (error) {
      toast.error("Erro ao excluir colaborador");
      console.error(error);
    }
  };

  const getTipoPagamentoLabel = (tipo: string, dia: number) => {
    const diasSemana = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];
    if (tipo === 'semanal') {
      return `Semanal (${diasSemana[dia]})`;
    } else if (tipo === 'quinzenal') {
      return `Quinzenal (Dia ${dia})`;
    } else {
      return `Mensal (Dia ${dia})`;
    }
  };

  const gerarPagamento = async (colaboradorId: number) => {
    if (!confirm("Confirma a geração de pagamento para este colaborador?")) return;
    
    try {
      const result = await gerarPagamentoMutation.mutateAsync({ colaboradorId });
      toast.success(`Pagamento gerado! Valor líquido: R$ ${(result.valorLiquido / 100).toFixed(2)}`);
      refetch();
    } catch (error: any) {
      toast.error(error.message || "Erro ao gerar pagamento");
      console.error(error);
    }
  };

  const abrirModalAdiantamento = (colaborador: any) => {
    setColaboradorSelecionado(colaborador);
    setModalAdiantamento(true);
  };

  const abrirModalHistorico = (colaborador: any) => {
    setColaboradorSelecionado(colaborador);
    setModalHistorico(true);
  };

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Colaboradores</h1>
            <p className="text-gray-600 mt-1">Gestão de funcionários e folha de pagamento</p>
          </div>
          <Button 
            className="bg-blue-600 hover:bg-blue-700"
            onClick={() => abrirModal()}
          >
            <UserPlus className="h-4 w-4 mr-2" />
            Novo Colaborador
          </Button>
        </div>

        {/* Cards de Resumo */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                <Briefcase className="h-5 w-5 text-blue-500" />
                Total de Colaboradores
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-blue-600">{colaboradores?.length || 0}</p>
              <p className="text-sm text-gray-500 mt-2">
                {colaboradores?.filter(c => c.status === 'ativo').length || 0} ativos
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                <DollarSign className="h-5 w-5 text-green-500" />
                Folha Mensal
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-green-600">
                R$ {(
                  (colaboradores || [])
                    .filter(c => c.status === 'ativo' && c.tipoPagamento === 'mensal')
                    .reduce((sum, c) => sum + c.salario, 0) / 100 || 0
                ).toLocaleString('pt-BR', {minimumFractionDigits: 2})}
              </p>
              <p className="text-sm text-gray-500 mt-2">
                {(colaboradores || []).filter(c => c.status === 'ativo' && c.tipoPagamento === 'mensal').length || 0} colaboradores
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                <Calendar className="h-5 w-5 text-orange-500" />
                Pagamentos Semanais
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-orange-600">
                R$ {(
                  (colaboradores || [])
                    .filter(c => c.status === 'ativo' && c.tipoPagamento === 'semanal')
                    .reduce((sum, c) => sum + c.salario, 0) / 100 || 0
                ).toLocaleString('pt-BR', {minimumFractionDigits: 2})}
              </p>
              <p className="text-sm text-gray-500 mt-2">
                {(colaboradores || []).filter(c => c.status === 'ativo' && c.tipoPagamento === 'semanal').length || 0} colaboradores
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Filtros */}
        <Card>
          <CardHeader>
            <CardTitle>Filtros</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4">
              <div className="w-48">
                <Label>Status</Label>
                <Select value={filtroStatus} onValueChange={(v: any) => setFiltroStatus(v)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent container={dialogRef.current}>
                    <SelectItem value="todos">Todos</SelectItem>
                    <SelectItem value="ativo">Ativos</SelectItem>
                    <SelectItem value="inativo">Inativos</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Tabela */}
        <Card>
          <CardHeader>
            <CardTitle>Lista de Colaboradores</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="border rounded-lg">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nome</TableHead>
                    <TableHead>Cargo</TableHead>
                    <TableHead>Salário</TableHead>
                    <TableHead>Tipo de Pagamento</TableHead>
                    <TableHead>Admissão</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {colaboradoresFiltrados.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center text-gray-500 py-8">
                        Nenhum colaborador cadastrado
                      </TableCell>
                    </TableRow>
                  ) : (
                    colaboradoresFiltrados.map((colaborador) => (
                      <TableRow key={colaborador.id}>
                        <TableCell className="font-medium">{colaborador.nome}</TableCell>
                        <TableCell>{colaborador.cargo || '-'}</TableCell>
                        <TableCell>
                          R$ {(colaborador.salario / 100).toLocaleString('pt-BR', {minimumFractionDigits: 2})}
                        </TableCell>
                        <TableCell>
                          {getTipoPagamentoLabel(colaborador.tipoPagamento, colaborador.diaPagamento)}
                        </TableCell>
                        <TableCell>
                          {new Date(colaborador.dataAdmissao).toLocaleDateString('pt-BR')}
                        </TableCell>
                        <TableCell>
                          <Badge className={colaborador.status === 'ativo' ? 'bg-green-600' : 'bg-gray-600'}>
                            {colaborador.status === 'ativo' ? 'Ativo' : 'Inativo'}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex gap-2 justify-end flex-wrap">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => gerarPagamento(colaborador.id)}
                              disabled={colaborador.status !== 'ativo'}
                              title="Gerar Pagamento"
                            >
                              <DollarSign className="h-4 w-4 text-green-600" />
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => abrirModalAdiantamento(colaborador)}
                              disabled={colaborador.status !== 'ativo'}
                              title="Registrar Adiantamento"
                            >
                              <Calendar className="h-4 w-4 text-blue-600" />
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => abrirModalHistorico(colaborador)}
                              title="Ver Histórico"
                            >
                              <Briefcase className="h-4 w-4 text-purple-600" />
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => abrirModal(colaborador)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => excluirColaborador(colaborador.id)}
                            >
                              <Trash2 className="h-4 w-4 text-red-600" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        {/* Modal de Cadastro/Edição */}
        <Dialog open={modalAberto} onOpenChange={setModalAberto}>
          <DialogContent ref={dialogRef} className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {colaboradorEditando ? 'Editar Colaborador' : 'Novo Colaborador'}
              </DialogTitle>
            </DialogHeader>

            <div className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Nome *</Label>
                  <Input
                    value={nome}
                    onChange={(e) => setNome(e.target.value)}
                    placeholder="Nome completo"
                  />
                </div>

                <div>
                  <Label>Cargo</Label>
                  <Input
                    value={cargo}
                    onChange={(e) => setCargo(e.target.value)}
                    placeholder="Ex: Mecânico, Atendente"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Salário (R$) *</Label>
                  <Input
                    type="number"
                    step="0.01"
                    value={salario}
                    onChange={(e) => setSalario(e.target.value)}
                    placeholder="0.00"
                  />
                </div>

                <div>
                  <Label>Data de Admissão *</Label>
                  <Input
                    type="date"
                    value={dataAdmissao}
                    onChange={(e) => setDataAdmissao(e.target.value)}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Tipo de Pagamento *</Label>
                  <Select value={tipoPagamento} onValueChange={(v: any) => setTipoPagamento(v)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                  <SelectContent container={dialogRef.current}>
                    <SelectItem value="semanal">Semanal</SelectItem>
                      <SelectItem value="quinzenal">Quinzenal</SelectItem>
                      <SelectItem value="mensal">Mensal</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>
                    {tipoPagamento === 'semanal' ? 'Dia da Semana *' : 'Dia do Mês *'}
                  </Label>
                  {tipoPagamento === 'semanal' ? (
                    <Select value={diaPagamento} onValueChange={setDiaPagamento}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                    <SelectContent container={dialogRef.current}>
                      <SelectItem value="0">Domingo</SelectItem>
                        <SelectItem value="1">Segunda</SelectItem>
                        <SelectItem value="2">Terça</SelectItem>
                        <SelectItem value="3">Quarta</SelectItem>
                        <SelectItem value="4">Quinta</SelectItem>
                        <SelectItem value="5">Sexta</SelectItem>
                        <SelectItem value="6">Sábado</SelectItem>
                      </SelectContent>
                    </Select>
                  ) : (
                    <Input
                      type="number"
                      min="1"
                      max="31"
                      value={diaPagamento}
                      onChange={(e) => setDiaPagamento(e.target.value)}
                      placeholder="1-31"
                    />
                  )}
                </div>
              </div>

              <div>
                <Label>Status</Label>
                <Select value={status} onValueChange={(v: any) => setStatus(v)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent container={dialogRef.current}>
                    <SelectItem value="ativo">Ativo</SelectItem>
                    <SelectItem value="inativo">Inativo</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Observações</Label>
                <Textarea
                  value={observacoes}
                  onChange={(e) => setObservacoes(e.target.value)}
                  placeholder="Informações adicionais"
                  rows={3}
                />
              </div>
            </div>

            <div className="flex gap-2 justify-end">
              <Button variant="outline" onClick={() => setModalAberto(false)}>
                Cancelar
              </Button>
              <Button 
                className="bg-blue-600 hover:bg-blue-700"
                onClick={salvarColaborador}
                disabled={createMutation.isPending || updateMutation.isPending}
              >
                {createMutation.isPending || updateMutation.isPending ? 'Salvando...' : 'Salvar'}
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        {/* Modal de Adiantamento */}
        <Dialog open={modalAdiantamento} onOpenChange={setModalAdiantamento}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Registrar Adiantamento</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Colaborador</Label>
                <Input value={colaboradorSelecionado?.nome || ''} disabled />
              </div>
              <div>
                <Label>Valor (R$)</Label>
                <Input
                  type="number"
                  step="0.01"
                  value={valorAdiantamento}
                  onChange={(e) => setValorAdiantamento(e.target.value)}
                  placeholder="0.00"
                />
              </div>
              <div>
                <Label>Descrição</Label>
                <Textarea
                  value={descricaoAdiantamento}
                  onChange={(e) => setDescricaoAdiantamento(e.target.value)}
                  placeholder="Motivo do adiantamento"
                  rows={3}
                />
              </div>
            </div>
            <div className="flex gap-2 justify-end mt-4">
              <Button variant="outline" onClick={() => setModalAdiantamento(false)}>
                Cancelar
              </Button>
              <Button 
                className="bg-blue-600 hover:bg-blue-700"
                onClick={() => {
                  toast.info("Funcionalidade de adiantamento em desenvolvimento");
                  setModalAdiantamento(false);
                }}
              >
                Registrar
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        {/* Modal de Histórico */}
        <Dialog open={modalHistorico} onOpenChange={setModalHistorico}>
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle>Histórico de Pagamentos - {colaboradorSelecionado?.nome}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <p className="text-gray-500 text-center py-8">
                Histórico de pagamentos em desenvolvimento
              </p>
            </div>
            <div className="flex gap-2 justify-end">
              <Button variant="outline" onClick={() => setModalHistorico(false)}>
                Fechar
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </Layout>
  );
}
