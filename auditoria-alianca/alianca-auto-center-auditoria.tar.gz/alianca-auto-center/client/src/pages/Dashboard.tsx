import Layout from "@/components/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { formatarMoeda } from "@/lib/currency";
import { FileText, ClipboardList, DollarSign, Package, TrendingUp, TrendingDown } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { MiniPieChart } from "@/components/MiniPieChart";
import { MiniBarChart } from "@/components/MiniBarChart";

export default function Dashboard() {
  const { data: stats, isLoading } = trpc.dashboard.stats.useQuery();
  const { data: agendamentos } = trpc.agendamentos.list.useQuery();
  const { data: proximosPagamentos } = trpc.colaboradores.proximosPagamentos.useQuery();
  
  // Calcular folha semanal (pagamentos nos próximos 7 dias)
  const folhaSemanal = proximosPagamentos?.filter(p => p.diasRestantes <= 7 && p.diasRestantes >= 0) || [];
  const totalFolhaSemanal = folhaSemanal.reduce((sum, p) => sum + p.salario, 0);
  const menorDiasRestantes = folhaSemanal.length > 0 ? Math.min(...folhaSemanal.map(p => p.diasRestantes)) : 0;

  // Próximos agendamentos (próximos 5 dias)
  const proximosAgendamentos = agendamentos?.filter((a: any) => {
    const dataAgendamento = new Date(a.dataHora);
    const hoje = new Date();
    const diff = dataAgendamento.getTime() - hoje.getTime();
    const dias = diff / (1000 * 3600 * 24);
    return dias >= 0 && dias <= 5 && a.status !== 'cancelado';
  }).slice(0, 5) || [];

  const cards = [
    {
      title: "Orçamentos Pendentes",
      value: stats?.orcamentos.pendentes || 0,
      total: stats?.orcamentos.total || 0,
      icon: FileText,
      color: "text-primary",
      bgGradient: "bg-white border border-[#E4E9F1] shadow-sm",
      iconBg: "bg-primary/10",
      link: "/orcamentos?status=pendente",
    },
    {
      title: "OS em Execução",
      value: stats?.ordensServico.emExecucao || 0,
      total: stats?.ordensServico.total || 0,
      icon: ClipboardList,
      color: "text-primary",
      bgGradient: "bg-white border border-[#E4E9F1] shadow-sm",
      iconBg: "bg-primary/10",
      link: "/ordens-servico?status=em_execucao",
    },
    {
      title: "A Receber",
      value: formatarMoeda(stats?.financeiro.aReceber.total || 0),
      subtitle: `${stats?.financeiro.aReceber.quantidade || 0} contas`,
      icon: TrendingUp,
      color: "text-primary",
      bgGradient: "bg-white border border-[#E4E9F1] shadow-sm",
      iconBg: "bg-primary/10",
      link: "/financeiro?tipo=receber",
    },
    {
      title: "A Pagar",
      value: formatarMoeda(stats?.financeiro.aPagar.total || 0),
      subtitle: `${stats?.financeiro.aPagar.quantidade || 0} contas`,
      icon: TrendingDown,
      color: "text-primary",
      bgGradient: "bg-white border border-[#E4E9F1] shadow-sm",
      iconBg: "bg-primary/10",
      link: "/financeiro?tipo=pagar",
    },
    {
      title: "Produtos em Estoque Baixo",
      value: stats?.estoque.produtosBaixos || 0,
      subtitle: "Necessitam reposição",
      icon: Package,
      color: "text-primary",
      bgGradient: "bg-white border border-[#E4E9F1] shadow-sm",
      iconBg: "bg-primary/10",
      link: "/estoque?filtro=baixo",
    },
    {
      title: "Folha Semanal",
      value: formatarMoeda(totalFolhaSemanal),
      subtitle: folhaSemanal.length > 0 
        ? `${folhaSemanal.length} colaborador${folhaSemanal.length > 1 ? 'es' : ''} - Pagar em ${menorDiasRestantes} dia${menorDiasRestantes !== 1 ? 's' : ''}`
        : "Nenhum pagamento esta semana",
      icon: DollarSign,
      color: menorDiasRestantes <= 2 ? "text-red-600" : menorDiasRestantes <= 4 ? "text-orange-600" : "text-primary",
      bgGradient: menorDiasRestantes <= 2 
        ? "bg-red-50 border border-red-200 shadow-sm" 
        : menorDiasRestantes <= 4
        ? "bg-orange-50 border border-orange-200 shadow-sm"
        : "bg-white border border-[#E4E9F1] shadow-sm",
      iconBg: menorDiasRestantes <= 2 ? "bg-red-100" : menorDiasRestantes <= 4 ? "bg-orange-100" : "bg-primary/10",
      link: "/colaboradores",
    },
  ];

  return (
    <Layout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Dashboard</h1>
          <p className="text-muted-foreground mt-1">Visão geral do sistema</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {isLoading ? (
            <>
              {[1, 2, 3, 4, 5].map((i) => (
                <Card key={i}>
                  <CardHeader>
                    <Skeleton className="h-4 w-32" />
                  </CardHeader>
                  <CardContent>
                    <Skeleton className="h-8 w-24" />
                  </CardContent>
                </Card>
              ))}
            </>
          ) : (
            cards.map((card, index) => {
              const Icon = card.icon;
              return (
                <Link key={index} href={card.link}>
                  <Card className={`hover:shadow-lg transition-all duration-300 cursor-pointer ${card.bgGradient} hover:scale-[1.02]`}>
                  <CardHeader className="flex flex-row items-center justify-between pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      {card.title}
                    </CardTitle>
                    <div className={`${card.iconBg} p-3 rounded-xl`}>
                      <Icon className={`h-6 w-6 ${card.color}`} />
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-3xl font-bold text-foreground">
                          {card.value}
                        </div>
                        {card.subtitle && (
                          <p className="text-sm text-muted-foreground mt-2">{card.subtitle}</p>
                        )}
                        {card.total !== undefined && (
                          <p className="text-sm text-muted-foreground mt-2">
                            Total: {card.total}
                          </p>
                        )}
                      </div>
                      <div className="w-24">
                        {card.total !== undefined && typeof card.value === 'number' && (
                          <MiniPieChart
                            value={card.value}
                            total={card.total}
                            colors={[
                              card.color === 'text-blue-600' ? '#2563eb' :
                              card.color === 'text-orange-600' ? '#ea580c' :
                              card.color === 'text-green-600' ? '#16a34a' :
                              card.color === 'text-red-600' ? '#dc2626' :
                              card.color === 'text-yellow-600' ? '#ca8a04' : '#6b7280',
                              '#e5e7eb'
                            ]}
                          />
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
                </Link>
              );
            })
          )}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="shadow-sm border border-[#E4E9F1]">
            <CardHeader className="border-b border-[#E4E9F1]">
              <CardTitle className="text-foreground">Atividades Recentes</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">Sistema iniciado</p>
                    <p className="text-xs text-gray-500">Todos os módulos funcionando</p>
                  </div>
                </div>
                {stats?.orcamentos?.pendentes && stats.orcamentos.pendentes > 0 && (
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-orange-600 rounded-full"></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">{stats.orcamentos.pendentes} orçamento(s) pendente(s)</p>
                      <p className="text-xs text-gray-500">Aguardando aprovação</p>
                    </div>
                  </div>
                )}
                {stats?.financeiro?.aReceber?.quantidade && stats.financeiro.aReceber.quantidade > 0 && (
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">{stats.financeiro.aReceber.quantidade} conta(s) a receber</p>
                      <p className="text-xs text-gray-500">{formatarMoeda(stats.financeiro.aReceber.total || 0)}</p>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-sm border border-[#E4E9F1]">
            <CardHeader className="border-b border-[#E4E9F1]">
              <CardTitle className="text-foreground">Próximos Agendamentos</CardTitle>
            </CardHeader>
            <CardContent>
              {proximosAgendamentos.length === 0 ? (
                <p className="text-sm text-gray-500">Nenhum agendamento próximo</p>
              ) : (
                <div className="space-y-3">
                  {proximosAgendamentos.map((agendamento: any) => (
                    <div key={agendamento.id} className="flex items-start gap-3 pb-3 border-b last:border-0">
                      <div className="flex-1">
                        <p className="text-sm font-medium">{agendamento.servico}</p>
                        <p className="text-xs text-gray-500">
                          {new Date(agendamento.dataHora).toLocaleDateString('pt-BR')} às {new Date(agendamento.dataHora).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
}
