import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { Plus, Package, AlertTriangle, TrendingUp, TrendingDown } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function Estoque() {
  const { data: stats } = trpc.dashboard.stats.useQuery();
  const { data: produtos, refetch } = trpc.produtos.list.useQuery();
  
  const [openNovo, setOpenNovo] = useState(false);
  const [openMovimentacao, setOpenMovimentacao] = useState(false);
  const [produtoSelecionado, setProdutoSelecionado] = useState<number | null>(null);

  const handleMovimentacao = (produtoId: number) => {
    setProdutoSelecionado(produtoId);
    setOpenMovimentacao(true);
  };

  const getEstoqueBadge = (atual: number, minimo: number) => {
    if (atual === 0) return <Badge variant="destructive">Sem Estoque</Badge>;
    if (atual <= minimo) return <Badge variant="destructive">Baixo</Badge>;
    if (atual <= minimo * 2) return <Badge variant="secondary">Atenção</Badge>;
    return <Badge variant="default">OK</Badge>;
  };

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Estoque</h1>
            <p className="text-gray-600 mt-1">Controle de produtos e peças</p>
          </div>
          <Dialog open={openNovo} onOpenChange={setOpenNovo}>
            <DialogTrigger asChild>
              <Button><Plus className="h-4 w-4 mr-2" />Novo Produto</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Novo Produto</DialogTitle>
              </DialogHeader>
              <NovoProdutoForm onSuccess={() => { setOpenNovo(false); refetch(); }} />
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Produtos em Estoque Baixo</CardTitle>
              <AlertTriangle className="h-5 w-5 text-orange-600" />
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-orange-600">{stats?.estoque.produtosBaixos || 0}</p>
              <p className="text-sm text-gray-600 mt-1">Necessitam reposição</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Total de Produtos</CardTitle>
              <Package className="h-5 w-5 text-blue-600" />
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-blue-600">{produtos?.length || 0}</p>
              <p className="text-sm text-gray-600 mt-1">Cadastrados no sistema</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Valor Total em Estoque</CardTitle>
              <TrendingUp className="h-5 w-5 text-green-600" />
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-green-600">
                R$ {((produtos?.reduce((acc: number, p: any) => acc + (p.estoqueAtual * p.valorCusto), 0) || 0) / 100).toLocaleString('pt-BR', {minimumFractionDigits: 2})}
              </p>
              <p className="text-sm text-gray-600 mt-1">Valor de custo</p>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Lista de Produtos</CardTitle>
          </CardHeader>
          <CardContent>
            {!produtos?.length ? (
              <p className="text-center text-gray-500 py-8">Nenhum produto cadastrado</p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Código</TableHead>
                    <TableHead>Descrição</TableHead>
                    <TableHead>Categoria</TableHead>
                    <TableHead>Estoque Atual</TableHead>
                    <TableHead>Estoque Mínimo</TableHead>
                    <TableHead>Valor Venda</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {produtos.map((produto: any) => (
                    <TableRow key={produto.id}>
                      <TableCell className="font-medium">{produto.codigo}</TableCell>
                      <TableCell>{produto.descricao}</TableCell>
                      <TableCell className="capitalize">{produto.categoria}</TableCell>
                      <TableCell>{produto.estoqueAtual} {produto.unidade}</TableCell>
                      <TableCell>{produto.estoqueMinimo} {produto.unidade}</TableCell>
                      <TableCell>R$ {(produto.valorVenda / 100).toLocaleString('pt-BR', {minimumFractionDigits: 2})}</TableCell>
                      <TableCell>{getEstoqueBadge(produto.estoqueAtual, produto.estoqueMinimo)}</TableCell>
                      <TableCell className="text-right">
                        <Button size="sm" variant="outline" onClick={() => handleMovimentacao(produto.id)}>
                          Movimentar
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        <Dialog open={openMovimentacao} onOpenChange={setOpenMovimentacao}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Movimentação de Estoque</DialogTitle>
            </DialogHeader>
            <MovimentacaoForm 
              produtoId={produtoSelecionado!} 
              onSuccess={() => { setOpenMovimentacao(false); refetch(); }} 
            />
          </DialogContent>
        </Dialog>
      </div>
    </Layout>
  );
}

function NovoProdutoForm({ onSuccess }: { onSuccess: () => void }) {
  const [codigo, setCodigo] = useState("");
  const [descricao, setDescricao] = useState("");
  const [categoria, setCategoria] = useState("peca");
  const [estoqueMinimo, setEstoqueMinimo] = useState("0");
  const [valorCusto, setValorCusto] = useState("");
  const [valorVenda, setValorVenda] = useState("");
  
  const createMutation = trpc.produtos.create.useMutation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await createMutation.mutateAsync({
        codigo,
        descricao,
        categoria: categoria as any,
        estoqueMinimo: parseInt(estoqueMinimo),
        valorCusto: Math.round(parseFloat(valorCusto) * 100),
        valorVenda: Math.round(parseFloat(valorVenda) * 100),
      });
      toast.success("Produto criado com sucesso!");
      onSuccess();
    } catch {
      toast.error("Erro ao criar produto");
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label>Código</Label>
        <Input value={codigo} onChange={(e) => setCodigo(e.target.value)} required />
      </div>
      <div>
        <Label>Descrição</Label>
        <Input value={descricao} onChange={(e) => setDescricao(e.target.value)} required />
      </div>
      <div>
        <Label>Categoria</Label>
        <Select value={categoria} onValueChange={setCategoria}>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="peca">Peça</SelectItem>
            <SelectItem value="pintura">Pintura</SelectItem>
            <SelectItem value="funilaria">Funilaria</SelectItem>
            <SelectItem value="outros">Outros</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div>
        <Label>Estoque Mínimo</Label>
        <Input type="number" value={estoqueMinimo} onChange={(e) => setEstoqueMinimo(e.target.value)} required />
      </div>
      <div>
        <Label>Valor de Custo (R$)</Label>
        <Input type="number" step="0.01" value={valorCusto} onChange={(e) => setValorCusto(e.target.value)} required />
      </div>
      <div>
        <Label>Valor de Venda (R$)</Label>
        <Input type="number" step="0.01" value={valorVenda} onChange={(e) => setValorVenda(e.target.value)} required />
      </div>
      <Button type="submit" className="w-full">Criar Produto</Button>
    </form>
  );
}

function MovimentacaoForm({ produtoId, onSuccess }: { produtoId: number; onSuccess: () => void }) {
  const [tipo, setTipo] = useState("entrada");
  const [quantidade, setQuantidade] = useState("");
  const [motivo, setMotivo] = useState("");
  
  const movimentarMutation = trpc.produtos.movimentar.useMutation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await movimentarMutation.mutateAsync({
        produtoId,
        tipo: tipo as any,
        quantidade: parseInt(quantidade),
        motivo,
      });
      toast.success("Movimentação registrada!");
      onSuccess();
    } catch {
      toast.error("Erro ao registrar movimentação");
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label>Tipo de Movimentação</Label>
        <Select value={tipo} onValueChange={setTipo}>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="entrada">Entrada</SelectItem>
            <SelectItem value="saida">Saída</SelectItem>
            <SelectItem value="ajuste">Ajuste</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div>
        <Label>Quantidade</Label>
        <Input type="number" value={quantidade} onChange={(e) => setQuantidade(e.target.value)} required />
      </div>
      <div>
        <Label>Motivo</Label>
        <Input value={motivo} onChange={(e) => setMotivo(e.target.value)} placeholder="Ex: Compra, Venda, Ajuste de inventário" />
      </div>
      <Button type="submit" className="w-full">Registrar Movimentação</Button>
    </form>
  );
}
