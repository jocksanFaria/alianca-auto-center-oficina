import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { TrendingUp, TrendingDown, AlertCircle, CheckCircle, Clock, Download, X, DollarSign } from "lucide-react";
import { useState, useMemo } from "react";
import { toast } from "sonner";
import * as XLSX from 'xlsx';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line } from 'recharts';

type PeriodoFiltro = 'todos' | 'semana' | 'mes' | 'ano' | 'personalizado';
type StatusFiltro = 'todos' | 'pendente' | 'vencido' | 'recebido';
type StatusFiltroPagar = 'todos' | 'pendente' | 'vencido' | 'pago';

export default function Financeiro() {
  const [tabAtiva, setTabAtiva] = useState<'receber' | 'pagar'>('receber');
  
  const { data: contasReceber, refetch: refetchReceber } = trpc.financeiro.contasReceber.list.useQuery();
  const { data: contasPagar, refetch: refetchPagar } = trpc.financeiro.contasPagar.list.useQuery();
  
  // Lista de clientes únicos (incluindo seguradoras)
  const clientesUnicos = useMemo(() => {
    if (!contasReceber) return [];
    const nomes = new Set<string>();
    contasReceber.forEach((conta: any) => {
      if (conta.cliente?.nome) {
        nomes.add(conta.cliente.nome);
      }
    });
    return Array.from(nomes).sort();
  }, [contasReceber]);
  
  const [periodoFiltro, setPeriodoFiltro] = useState<PeriodoFiltro>('todos');
  const [statusFiltro, setStatusFiltro] = useState<StatusFiltro>('todos');
  const [dataInicio, setDataInicio] = useState('');
  const [dataFim, setDataFim] = useState('');
  const [clienteFiltro, setClienteFiltro] = useState('');
  const [valorMin, setValorMin] = useState('');
  const [valorMax, setValorMax] = useState('');
  const [contaSelecionada, setContaSelecionada] = useState<any>(null);
  const [modalAberto, setModalAberto] = useState(false);
  
  // Estados para Contas a Pagar
  const [statusFiltroPagar, setStatusFiltroPagar] = useState<StatusFiltroPagar>('todos');
  const [fornecedorFiltro, setFornecedorFiltro] = useState('');
  const [valorMinPagar, setValorMinPagar] = useState('');
  const [valorMaxPagar, setValorMaxPagar] = useState('');
  const [modalNovaContaAberto, setModalNovaContaAberto] = useState(false);
  
  // Form data para nova conta
  const [novaContaForm, setNovaContaForm] = useState({
    descricao: '',
    fornecedorId: '',
    valor: '',
    dataVencimento: '',
    categoria: '',
    formaPagamento: '',
    observacoes: ''
  });

  const marcarRecebidoMutation = trpc.financeiro.contasReceber.marcarRecebido.useMutation();
  const marcarPagoMutation = trpc.financeiro.contasPagar.pagar.useMutation();
  const criarContaPagarMutation = trpc.financeiro.contasPagar.create.useMutation();
  const { data: fornecedores } = trpc.fornecedores.list.useQuery({ ativo: true });
  const { data: orcamentoDetalhado } = trpc.orcamentos.getById.useQuery(
    { id: contaSelecionada?.orcamentoId || 0 },
    { enabled: !!contaSelecionada?.orcamentoId }
  );

  const handleMarcarRecebido = async (id: number) => {
    if (!confirm("Confirmar recebimento desta conta?")) return;
    try {
      await marcarRecebidoMutation.mutateAsync({ id });
      toast.success("Conta marcada como recebida!");
      refetchReceber();
    } catch {
      toast.error("Erro ao marcar como recebida");
    }
  };

  const handleMarcarPago = async (id: number) => {
    if (!confirm("Confirmar pagamento desta conta?")) return;
    try {
      await marcarPagoMutation.mutateAsync({ id, dataPagamento: new Date(), formaPagamento: 'Dinheiro' });
      toast.success("Conta marcada como paga!");
      refetchPagar();
    } catch {
      toast.error("Erro ao marcar como paga");
    }
  };

  const handleCriarContaPagar = async () => {
    // Validações
    if (!novaContaForm.descricao.trim()) {
      toast.error("Descrição é obrigatória");
      return;
    }
    if (!novaContaForm.fornecedorId) {
      toast.error("Selecione um fornecedor");
      return;
    }
    if (!novaContaForm.valor || parseFloat(novaContaForm.valor) <= 0) {
      toast.error("Valor deve ser maior que zero");
      return;
    }
    if (!novaContaForm.dataVencimento) {
      toast.error("Data de vencimento é obrigatória");
      return;
    }
    if (!novaContaForm.categoria) {
      toast.error("Selecione uma categoria");
      return;
    }
    if (!novaContaForm.formaPagamento) {
      toast.error("Selecione uma forma de pagamento");
      return;
    }

    try {
      await criarContaPagarMutation.mutateAsync({
        descricao: novaContaForm.descricao,
        fornecedorId: parseInt(novaContaForm.fornecedorId),
        valor: Math.round(parseFloat(novaContaForm.valor) * 100),
        dataEmissao: new Date(),
        dataVencimento: new Date(novaContaForm.dataVencimento),
        categoria: novaContaForm.categoria,
        observacoes: novaContaForm.observacoes || undefined,
      });
      
      toast.success("Conta a pagar criada com sucesso!");
      setModalNovaContaAberto(false);
      setNovaContaForm({
        descricao: '',
        fornecedorId: '',
        valor: '',
        dataVencimento: '',
        categoria: '',
        formaPagamento: '',
        observacoes: ''
      });
      refetchPagar();
    } catch (error) {
      toast.error("Erro ao criar conta a pagar");
      console.error(error);
    }
  };

  // Função para calcular intervalo de datas baseado no filtro
  const getDataRange = () => {
    const hoje = new Date();
    let inicio = new Date();
    let fim = new Date();

    switch (periodoFiltro) {
      case 'semana':
        inicio.setDate(hoje.getDate() - 7);
        break;
      case 'mes':
        inicio.setMonth(hoje.getMonth() - 1);
        break;
      case 'ano':
        inicio.setFullYear(hoje.getFullYear() - 1);
        break;
      case 'personalizado':
        if (dataInicio) inicio = new Date(dataInicio);
        if (dataFim) fim = new Date(dataFim);
        break;
      case 'todos':
      default:
        return null;
    }

    return { inicio, fim };
  };

  // Filtrar contas a receber
  const contasReceberFiltradas = useMemo(() => {
    if (!contasReceber) return [];
    
    let filtradas = [...contasReceber];
    const hoje = new Date();
    hoje.setHours(0, 0, 0, 0);

    // Filtro de status
    if (statusFiltro !== 'todos') {
      filtradas = filtradas.filter((conta: any) => {
        if (statusFiltro === 'vencido') {
          const vencimento = new Date(conta.dataVencimento);
          return conta.status === 'pendente' && vencimento < hoje;
        }
        return conta.status === statusFiltro;
      });
    }

    // Filtro de período
    const range = getDataRange();
    if (range) {
      filtradas = filtradas.filter((conta: any) => {
        const data = new Date(conta.dataEmissao);
        return data >= range.inicio && data <= range.fim;
      });
    }

    // Filtro por cliente
    if (clienteFiltro) {
      filtradas = filtradas.filter((conta: any) => 
        conta.cliente?.nome?.toLowerCase().includes(clienteFiltro.toLowerCase())
      );
    }

    // Filtro por faixa de valor
    if (valorMin) {
      const minCentavos = parseFloat(valorMin) * 100;
      filtradas = filtradas.filter((conta: any) => conta.valor >= minCentavos);
    }
    if (valorMax) {
      const maxCentavos = parseFloat(valorMax) * 100;
      filtradas = filtradas.filter((conta: any) => conta.valor <= maxCentavos);
    }

    // Ordenar por urgência: vencidas primeiro, depois por data de vencimento
    return filtradas.sort((a: any, b: any) => {
      const hoje = new Date();
      hoje.setHours(0, 0, 0, 0);
      const vencA = new Date(a.dataVencimento);
      const vencB = new Date(b.dataVencimento);
      
      // Recebidas vão para o final
      if (a.status === 'recebido' && b.status !== 'recebido') return 1;
      if (a.status !== 'recebido' && b.status === 'recebido') return -1;
      
      // Vencidas primeiro
      const aVencida = vencA < hoje && a.status === 'pendente';
      const bVencida = vencB < hoje && b.status === 'pendente';
      if (aVencida && !bVencida) return -1;
      if (!aVencida && bVencida) return 1;
      
      // Ordenar por data de vencimento
      return vencA.getTime() - vencB.getTime();
    });
  }, [contasReceber, statusFiltro, periodoFiltro, dataInicio, dataFim, clienteFiltro, valorMin, valorMax]);

  // Calcular métricas
  const metricas = useMemo(() => {
    const hoje = new Date();
    hoje.setHours(0, 0, 0, 0);
    const seteDiasDepois = new Date(hoje);
    seteDiasDepois.setDate(hoje.getDate() + 7);

    const pendentes = contasReceberFiltradas.filter((c: any) => c.status === 'pendente');
    const vencidas = pendentes.filter((c: any) => new Date(c.dataVencimento) < hoje);
    const proximas = pendentes.filter((c: any) => {
      const venc = new Date(c.dataVencimento);
      return venc >= hoje && venc <= seteDiasDepois;
    });
    
    // Recebidas no mês atual
    const inicioMes = new Date(hoje.getFullYear(), hoje.getMonth(), 1);
    const recebidas = contasReceberFiltradas.filter((c: any) => 
      c.status === 'recebido' && new Date(c.dataEmissao) >= inicioMes
    );

    return {
      totalPendente: pendentes.reduce((sum: number, c: any) => sum + c.valor, 0),
      quantidadePendente: pendentes.length,
      totalVencido: vencidas.reduce((sum: number, c: any) => sum + c.valor, 0),
      quantidadeVencida: vencidas.length,
      totalProximo: proximas.reduce((sum: number, c: any) => sum + c.valor, 0),
      quantidadeProxima: proximas.length,
      totalRecebido: recebidas.reduce((sum: number, c: any) => sum + c.valor, 0),
      quantidadeRecebida: recebidas.length,
    };
  }, [contasReceberFiltradas]);

  // Métricas de Contas a Pagar
  const metricasPagar = useMemo(() => {
    if (!contasPagar) return {
      totalPendente: 0,
      quantidadePendente: 0,
      totalVencido: 0,
      quantidadeVencida: 0,
      totalProxima: 0,
      quantidadeProxima: 0,
      totalPago: 0,
      quantidadePaga: 0,
    };

    const hoje = new Date();
    hoje.setHours(0, 0, 0, 0);
    const seteDiasDepois = new Date(hoje);
    seteDiasDepois.setDate(hoje.getDate() + 7);
    
    const mesAtual = hoje.getMonth();
    const anoAtual = hoje.getFullYear();

    let totalPendente = 0, quantidadePendente = 0;
    let totalVencido = 0, quantidadeVencida = 0;
    let totalProxima = 0, quantidadeProxima = 0;
    let totalPago = 0, quantidadePaga = 0;

    contasPagar.forEach((conta: any) => {
      const vencimento = new Date(conta.dataVencimento);
      vencimento.setHours(0, 0, 0, 0);

      if (conta.status === 'pago') {
        const dataPagamento = conta.dataPagamento ? new Date(conta.dataPagamento) : null;
        if (dataPagamento && dataPagamento.getMonth() === mesAtual && dataPagamento.getFullYear() === anoAtual) {
          totalPago += conta.valor;
          quantidadePaga++;
        }
      } else if (conta.status === 'pendente') {
        totalPendente += conta.valor;
        quantidadePendente++;

        if (vencimento < hoje) {
          totalVencido += conta.valor;
          quantidadeVencida++;
        } else if (vencimento <= seteDiasDepois) {
          totalProxima += conta.valor;
          quantidadeProxima++;
        }
      }
    });

    return {
      totalPendente,
      quantidadePendente,
      totalVencido,
      quantidadeVencida,
      totalProxima,
      quantidadeProxima,
      totalPago,
      quantidadePaga,
    };
  }, [contasPagar]);

  // Dados para gráfico de pizza
  const dadosPizza = [
    { nome: 'Pendentes', valor: metricas.quantidadePendente - metricas.quantidadeVencida - metricas.quantidadeProxima, cor: '#6b7280' },
    { nome: 'Próximas (7 dias)', valor: metricas.quantidadeProxima, cor: '#f59e0b' },
    { nome: 'Vencidas', valor: metricas.quantidadeVencida, cor: '#ef4444' },
    { nome: 'Recebidas', valor: metricas.quantidadeRecebida, cor: '#10b981' },
  ].filter(item => item.valor > 0);

  // Dados para gráfico de barras (top clientes)
  const dadosClientesMap = new Map<string, number>();
  contasReceberFiltradas.forEach((conta: any) => {
    if (conta.status === 'pendente') {
      const nome = conta.cliente?.nome || 'Sem nome';
      dadosClientesMap.set(nome, (dadosClientesMap.get(nome) || 0) + conta.valor);
    }
  });
  const dadosClientes = Array.from(dadosClientesMap.entries())
    .map(([nome, valor]) => ({ nome, valor: valor / 100 }))
    .sort((a, b) => b.valor - a.valor)
    .slice(0, 10);

  // Dados para gráfico de pizza - Contas a Pagar
  const dadosPizzaPagar = [
    { nome: 'Pendentes', valor: metricasPagar.quantidadePendente - metricasPagar.quantidadeVencida - metricasPagar.quantidadeProxima, cor: '#6b7280' },
    { nome: 'Próximas (7 dias)', valor: metricasPagar.quantidadeProxima, cor: '#f59e0b' },
    { nome: 'Vencidas', valor: metricasPagar.quantidadeVencida, cor: '#ef4444' },
    { nome: 'Pagas', valor: metricasPagar.quantidadePaga, cor: '#10b981' },
  ].filter(item => item.valor > 0);

  // Dados para gráfico de barras - Top Fornecedores
  const dadosFornecedoresMap = new Map<string, number>();
  const contasPagarFiltradas = contasPagar || [];
  contasPagarFiltradas.forEach((conta: any) => {
    if (conta.status === 'pendente') {
      const nome = conta.fornecedor?.nome || 'Sem nome';
      dadosFornecedoresMap.set(nome, (dadosFornecedoresMap.get(nome) || 0) + conta.valor);
    }
  });
  const dadosFornecedores = Array.from(dadosFornecedoresMap.entries())
    .map(([nome, valor]) => ({ nome, valor: valor / 100 }))
    .sort((a, b) => b.valor - a.valor)
    .slice(0, 10);

  const limparFiltros = () => {
    setPeriodoFiltro('todos');
    setStatusFiltro('todos');
    setDataInicio('');
    setDataFim('');
    setClienteFiltro('');
    setValorMin('');
    setValorMax('');
  };

  const filtrarPorStatus = (status: StatusFiltro) => {
    setStatusFiltro(status);
    limparFiltros();
    setStatusFiltro(status);
  };

  const abrirDetalhes = (conta: any) => {
    setContaSelecionada(conta);
    setModalAberto(true);
  };

  const exportarParaExcel = () => {
    if (!contasReceberFiltradas || contasReceberFiltradas.length === 0) {
      toast.error('Nenhum dado para exportar');
      return;
    }

    const dadosFormatados = contasReceberFiltradas.map((conta: any) => ({
      'Orçamento': conta.orcamento?.numero || 'N/A',
      'Placa': conta.veiculo?.placa || 'N/A',
      'Cliente': conta.cliente?.nome || 'N/A',
      'Valor': `R$ ${(conta.valor / 100).toLocaleString('pt-BR', {minimumFractionDigits: 2})}`,
      'Vencimento': new Date(conta.dataVencimento).toLocaleDateString('pt-BR'),
      'Status': conta.status === 'recebido' ? 'Recebido' : conta.status === 'pendente' ? 'Pendente' : 'Vencido',
    }));

    const ws = XLSX.utils.json_to_sheet(dadosFormatados);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Contas a Receber');
    XLSX.writeFile(wb, `contas_receber_${new Date().toISOString().split('T')[0]}.xlsx`);
    
    toast.success('Arquivo Excel gerado com sucesso!');
  };

  const getLinhaClasse = (conta: any) => {
    const hoje = new Date();
    hoje.setHours(0, 0, 0, 0);
    const vencimento = new Date(conta.dataVencimento);
    const diffDays = Math.ceil((vencimento.getTime() - hoje.getTime()) / (1000 * 60 * 60 * 24));

    if (conta.status === 'recebido') return '';
    if (diffDays < 0) return 'bg-red-50 border-l-4 border-red-500';
    if (diffDays <= 7) return 'bg-yellow-50 border-l-4 border-yellow-500';
    return '';
  };

  const getStatusBadge = (conta: any) => {
    const hoje = new Date();
    hoje.setHours(0, 0, 0, 0);
    const vencimento = new Date(conta.dataVencimento);
    
    if (conta.status === 'recebido') {
      return <Badge className="bg-green-600 text-white"><CheckCircle className="h-3 w-3 mr-1" />Recebido</Badge>;
    }
    
    if (conta.status === 'pendente' && vencimento < hoje) {
      return <Badge variant="destructive" className="text-white"><AlertCircle className="h-3 w-3 mr-1" />Vencido</Badge>;
    }
    
    return <Badge variant="secondary"><Clock className="h-3 w-3 mr-1" />Pendente</Badge>;
  };

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Financeiro</h1>
            <p className="text-gray-600 mt-1">Gestão completa de contas a receber e pagar</p>
          </div>
        </div>

        <Tabs value={tabAtiva} onValueChange={(v) => setTabAtiva(v as 'receber' | 'pagar')} className="w-full">
          <TabsList className="grid w-full max-w-md grid-cols-2">
            <TabsTrigger value="receber">Contas a Receber</TabsTrigger>
            <TabsTrigger value="pagar">Contas a Pagar</TabsTrigger>
          </TabsList>

          <TabsContent value="receber" className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold">Contas a Receber</h2>
                <p className="text-gray-600 mt-1">Acompanhamento completo de recebimentos</p>
              </div>
              <Button onClick={exportarParaExcel} className="bg-green-600 hover:bg-green-700">
                <Download className="h-4 w-4 mr-2" />
                Exportar Excel
              </Button>
            </div>

        {/* Cards de Resumo Grandes */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card 
            className={`border-l-4 border-blue-500 cursor-pointer hover:shadow-lg transition-shadow ${
              statusFiltro === 'pendente' ? 'ring-2 ring-blue-500' : ''
            }`}
            onClick={() => filtrarPorStatus('pendente')}
          >
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                <DollarSign className="h-5 w-5 text-blue-500" />
                Total a Receber
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-blue-600">
                R$ {(metricas.totalPendente / 100).toLocaleString('pt-BR', {minimumFractionDigits: 2})}
              </p>
              <p className="text-sm text-gray-500 mt-2">{metricas.quantidadePendente} contas pendentes</p>
            </CardContent>
          </Card>

          <Card 
            className={`border-l-4 border-red-500 cursor-pointer hover:shadow-lg transition-shadow ${
              statusFiltro === 'vencido' ? 'ring-2 ring-red-500' : ''
            }`}
            onClick={() => filtrarPorStatus('vencido')}
          >
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                <AlertCircle className="h-5 w-5 text-red-500" />
                Contas Vencidas
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-red-600">
                R$ {(metricas.totalVencido / 100).toLocaleString('pt-BR', {minimumFractionDigits: 2})}
              </p>
              <p className="text-sm text-gray-500 mt-2">{metricas.quantidadeVencida} contas atrasadas</p>
            </CardContent>
          </Card>

          <Card 
            className={`border-l-4 border-yellow-500 cursor-pointer hover:shadow-lg transition-shadow`}
            onClick={() => {
              limparFiltros();
              // Filtro customizado para próximas 7 dias será aplicado automaticamente pela tabela
            }}
          >
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                <Clock className="h-5 w-5 text-yellow-500" />
                Vence em 7 dias
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-yellow-600">
                R$ {(metricas.totalProximo / 100).toLocaleString('pt-BR', {minimumFractionDigits: 2})}
              </p>
              <p className="text-sm text-gray-500 mt-2">{metricas.quantidadeProxima} contas próximas</p>
            </CardContent>
          </Card>

          <Card 
            className={`border-l-4 border-green-500 cursor-pointer hover:shadow-lg transition-shadow ${
              statusFiltro === 'recebido' ? 'ring-2 ring-green-500' : ''
            }`}
            onClick={() => filtrarPorStatus('recebido')}
          >
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-green-500" />
                Recebidas no Mês
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-green-600">
                R$ {(metricas.totalRecebido / 100).toLocaleString('pt-BR', {minimumFractionDigits: 2})}
              </p>
              <p className="text-sm text-gray-500 mt-2">{metricas.quantidadeRecebida} contas recebidas</p>
            </CardContent>
          </Card>
        </div>

        {/* Gráficos */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Gráfico de Pizza */}
          <Card>
            <CardHeader>
              <CardTitle>Distribuição de Contas</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={dadosPizza}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={(entry) => `${entry.nome}: ${entry.valor}`}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="valor"
                    onClick={(data) => {
                      if (data.nome === 'Vencidas') filtrarPorStatus('vencido');
                      else if (data.nome === 'Recebidas') filtrarPorStatus('recebido');
                      else if (data.nome === 'Pendentes' || data.nome === 'Próximas (7 dias)') filtrarPorStatus('pendente');
                    }}
                    cursor="pointer"
                  >
                    {dadosPizza.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.cor} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Gráfico de Barras - Top Clientes */}
          <Card>
            <CardHeader>
              <CardTitle>Top 10 Clientes Pendentes</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={dadosClientes}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="nome" angle={-45} textAnchor="end" height={100} />
                  <YAxis />
                  <Tooltip formatter={(value: number) => `R$ ${value.toLocaleString('pt-BR', {minimumFractionDigits: 2})}`} />
                  <Bar dataKey="valor" fill="#3b82f6" name="Valor (R$)" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Filtros */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Filtros</span>
              <Button variant="outline" size="sm" onClick={limparFiltros}>
                <X className="h-4 w-4 mr-2" />
                Limpar
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <Label>Status</Label>
                <Select value={statusFiltro} onValueChange={(v) => setStatusFiltro(v as StatusFiltro)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todos">Todas</SelectItem>
                    <SelectItem value="vencido">Vencidas</SelectItem>
                    <SelectItem value="pendente">Pendentes</SelectItem>
                    <SelectItem value="recebido">Recebidas</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Cliente</Label>
                <Input 
                  placeholder="Buscar por cliente..."
                  value={clienteFiltro}
                  onChange={(e) => setClienteFiltro(e.target.value)}
                  list="clientes-list"
                />
                <datalist id="clientes-list">
                  {clientesUnicos.map((nome) => (
                    <option key={nome} value={nome} />
                  ))}
                </datalist>
              </div>

              <div>
                <Label>Valor Mínimo (R$)</Label>
                <Input 
                  type="number"
                  placeholder="0,00"
                  value={valorMin}
                  onChange={(e) => setValorMin(e.target.value)}
                  step="0.01"
                />
              </div>

              <div>
                <Label>Valor Máximo (R$)</Label>
                <Input 
                  type="number"
                  placeholder="0,00"
                  value={valorMax}
                  onChange={(e) => setValorMax(e.target.value)}
                  step="0.01"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Card de Resumo por Cliente */}
        {clienteFiltro && (
          <Card className="border-l-4 border-purple-500">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="h-5 w-5 text-purple-500" />
                Resumo: {clienteFiltro}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Total a Receber</p>
                  <p className="text-2xl font-bold text-purple-600">
                    R$ {(contasReceberFiltradas.reduce((sum: number, c: any) => sum + c.valor, 0) / 100).toLocaleString('pt-BR', {minimumFractionDigits: 2})}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-1">Quantidade de Veículos</p>
                  <p className="text-2xl font-bold text-purple-600">
                    {new Set(contasReceberFiltradas.map((c: any) => c.veiculo?.placa).filter(Boolean)).size}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-1">Contas Pendentes</p>
                  <p className="text-2xl font-bold text-purple-600">
                    {contasReceberFiltradas.filter((c: any) => c.status === 'pendente').length}
                  </p>
                </div>
              </div>
              
              {/* Detalhamento por Placa */}
              <div className="mt-6">
                <h4 className="font-semibold text-gray-700 mb-3">Detalhamento por Veículo:</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {Array.from(
                    contasReceberFiltradas.reduce((acc: Map<string, any>, conta: any) => {
                      if (conta.veiculo?.placa) {
                        const placa = conta.veiculo.placa;
                        if (!acc.has(placa)) {
                          acc.set(placa, { placa, modelo: conta.veiculo.modelo, valor: 0, quantidade: 0 });
                        }
                        const item = acc.get(placa);
                        item.valor += conta.valor;
                        item.quantidade += 1;
                      }
                      return acc;
                    }, new Map()).values()
                  ).map((item: any) => (
                    <div key={item.placa} className="p-3 bg-gray-50 rounded-lg border border-gray-200">
                      <p className="font-semibold text-gray-900">{item.placa}</p>
                      <p className="text-sm text-gray-600">{item.modelo || 'Modelo não informado'}</p>
                      <p className="text-lg font-bold text-purple-600 mt-1">
                        R$ {(item.valor / 100).toLocaleString('pt-BR', {minimumFractionDigits: 2})}
                      </p>
                      <p className="text-xs text-gray-500">{item.quantidade} conta(s)</p>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Tabela de Contas */}
        <Card>
          <CardHeader>
            <CardTitle>Listagem de Contas ({contasReceberFiltradas.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Orçamento</TableHead>
                    <TableHead>Placa</TableHead>
                    <TableHead>Cliente</TableHead>
                    <TableHead>Valor</TableHead>
                    <TableHead>Vencimento</TableHead>
                    <TableHead>Dias</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {contasReceberFiltradas.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={8} className="text-center text-gray-500 py-8">
                        Nenhuma conta encontrada
                      </TableCell>
                    </TableRow>
                  ) : (
                    contasReceberFiltradas.map((conta: any) => {
                      const hoje = new Date();
                      hoje.setHours(0, 0, 0, 0);
                      const vencimento = new Date(conta.dataVencimento);
                      vencimento.setHours(0, 0, 0, 0);
                      const diffTime = vencimento.getTime() - hoje.getTime();
                      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                      
                      let diasTexto = '';
                      let diasCor = '';
                      
                      if (conta.status === 'recebido') {
                        diasTexto = 'Recebido';
                        diasCor = 'text-green-600 font-semibold';
                      } else if (diffDays < 0) {
                        diasTexto = `Vencido há ${Math.abs(diffDays)} dias`;
                        diasCor = 'text-red-600 font-bold';
                      } else if (diffDays === 0) {
                        diasTexto = 'Vence hoje';
                        diasCor = 'text-orange-600 font-bold';
                      } else if (diffDays <= 7) {
                        diasTexto = `Vence em ${diffDays} dias`;
                        diasCor = 'text-yellow-600 font-semibold';
                      } else {
                        diasTexto = `Vence em ${diffDays} dias`;
                        diasCor = 'text-gray-600';
                      }
                      
                      return (
                        <TableRow 
                          key={conta.id} 
                          className={`${getLinhaClasse(conta)} cursor-pointer hover:bg-gray-100`}
                          onClick={() => abrirDetalhes(conta)}
                        >
                          <TableCell className="font-medium">
                            {conta.orcamento?.numero || 'N/A'}
                          </TableCell>
                          <TableCell className="font-medium">
                            {conta.veiculo?.placa || 'N/A'}
                          </TableCell>
                          <TableCell>{conta.cliente?.nome || 'N/A'}</TableCell>
                          <TableCell className="font-bold">
                            R$ {(conta.valor / 100).toLocaleString('pt-BR', {minimumFractionDigits: 2})}
                          </TableCell>
                          <TableCell>{vencimento.toLocaleDateString('pt-BR')}</TableCell>
                          <TableCell className={diasCor}>{diasTexto}</TableCell>
                          <TableCell>{getStatusBadge(conta)}</TableCell>
                          <TableCell>
                            {conta.status === 'pendente' && (
                              <Button 
                                size="sm" 
                                onClick={() => handleMarcarRecebido(conta.id)}
                                className="bg-green-600 hover:bg-green-700"
                              >
                                <CheckCircle className="h-4 w-4 mr-1" />
                                Receber
                              </Button>
                            )}
                          </TableCell>
                        </TableRow>
                      );
                    })
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
          </TabsContent>

          <TabsContent value="pagar" className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold">Contas a Pagar</h2>
                <p className="text-gray-600 mt-1">Gestão de pagamentos e fornecedores</p>
              </div>
              <div className="flex gap-3">
                <Button variant="outline" className="bg-green-600 hover:bg-green-700 text-white">
                  <Download className="h-4 w-4 mr-2" />
                  Exportar Excel
                </Button>
                <Button 
                  className="bg-blue-600 hover:bg-blue-700"
                  onClick={() => setModalNovaContaAberto(true)}
                >
                  <DollarSign className="h-4 w-4 mr-2" />
                  Nova Conta a Pagar
                </Button>
              </div>
            </div>

            {/* Cards de Resumo */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="border-l-4 border-blue-500">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                    <DollarSign className="h-5 w-5 text-blue-500" />
                    Total a Pagar
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold text-blue-600">
                    R$ {(metricasPagar.totalPendente / 100).toLocaleString('pt-BR', {minimumFractionDigits: 2})}
                  </p>
                  <p className="text-sm text-gray-500 mt-2">{metricasPagar.quantidadePendente} contas pendentes</p>
                </CardContent>
              </Card>

              <Card className="border-l-4 border-red-500">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                    <AlertCircle className="h-5 w-5 text-red-500" />
                    Contas Vencidas
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold text-red-600">
                    R$ {(metricasPagar.totalVencido / 100).toLocaleString('pt-BR', {minimumFractionDigits: 2})}
                  </p>
                  <p className="text-sm text-gray-500 mt-2">{metricasPagar.quantidadeVencida} contas atrasadas</p>
                </CardContent>
              </Card>

              <Card className="border-l-4 border-yellow-500">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                    <Clock className="h-5 w-5 text-yellow-500" />
                    Vence em 7 dias
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold text-yellow-600">
                    R$ {(metricasPagar.totalProxima / 100).toLocaleString('pt-BR', {minimumFractionDigits: 2})}
                  </p>
                  <p className="text-sm text-gray-500 mt-2">{metricasPagar.quantidadeProxima} contas próximas</p>
                </CardContent>
              </Card>

              <Card className="border-l-4 border-green-500">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                    <CheckCircle className="h-5 w-5 text-green-500" />
                    Pagas no Mês
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold text-green-600">
                    R$ {(metricasPagar.totalPago / 100).toLocaleString('pt-BR', {minimumFractionDigits: 2})}
                  </p>
                  <p className="text-sm text-gray-500 mt-2">{metricasPagar.quantidadePaga} contas pagas</p>
                </CardContent>
              </Card>
            </div>

            {/* Gráficos */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Gráfico de Pizza */}
              <Card>
                <CardHeader>
                  <CardTitle>Distribuição de Contas</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={dadosPizzaPagar}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={(entry) => `${entry.nome}: ${entry.valor}`}
                        outerRadius={100}
                        fill="#8884d8"
                        dataKey="valor"
                        onClick={(data) => {
                          if (data.nome === 'Vencidas') setStatusFiltroPagar('vencido');
                          else if (data.nome === 'Pagas') setStatusFiltroPagar('pago');
                          else if (data.nome === 'Pendentes' || data.nome === 'Próximas (7 dias)') setStatusFiltroPagar('pendente');
                        }}
                        cursor="pointer"
                      >
                        {dadosPizzaPagar.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.cor} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Gráfico de Barras - Top Fornecedores */}
              <Card>
                <CardHeader>
                  <CardTitle>Top 10 Fornecedores Pendentes</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={dadosFornecedores}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="nome" angle={-45} textAnchor="end" height={100} />
                      <YAxis />
                      <Tooltip formatter={(value: number) => `R$ ${value.toLocaleString('pt-BR', {minimumFractionDigits: 2})}`} />
                      <Bar dataKey="valor" fill="#3b82f6" name="Valor (R$)" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            {/* Tabela */}
            <Card>
              <CardHeader>
                <CardTitle>Lista de Contas a Pagar</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="border rounded-lg">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Descrição</TableHead>
                        <TableHead>Fornecedor</TableHead>
                        <TableHead>Valor</TableHead>
                        <TableHead>Vencimento</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Ações</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {!contasPagar || contasPagar.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={6} className="text-center text-gray-500 py-8">
                            Nenhuma conta a pagar cadastrada
                          </TableCell>
                        </TableRow>
                      ) : (
                        contasPagar.map((conta: any) => {
                          const hoje = new Date();
                          hoje.setHours(0, 0, 0, 0);
                          const vencimento = new Date(conta.dataVencimento);
                          vencimento.setHours(0, 0, 0, 0);
                          const diffDays = Math.ceil((vencimento.getTime() - hoje.getTime()) / (1000 * 60 * 60 * 24));
                          
                          let linhaClasse = '';
                          if (conta.status !== 'pago') {
                            if (diffDays < 0) linhaClasse = 'bg-red-50';
                            else if (diffDays <= 7) linhaClasse = 'bg-yellow-50';
                          }
                          
                          return (
                            <TableRow key={conta.id} className={linhaClasse}>
                              <TableCell className="font-medium">{conta.descricao}</TableCell>
                              <TableCell>{conta.fornecedor?.nome || 'N/A'}</TableCell>
                              <TableCell className="font-bold">
                                R$ {(conta.valor / 100).toLocaleString('pt-BR', {minimumFractionDigits: 2})}
                              </TableCell>
                              <TableCell>{new Date(conta.dataVencimento).toLocaleDateString('pt-BR')}</TableCell>
                              <TableCell>
                                {conta.status === 'pago' ? (
                                  <Badge variant="default" className="bg-green-600 text-white">
                                    <CheckCircle className="h-3 w-3 mr-1" />Pago
                                  </Badge>
                                ) : diffDays < 0 ? (
                                  <Badge variant="destructive" className="text-white">
                                    <AlertCircle className="h-3 w-3 mr-1" />Vencido
                                  </Badge>
                                ) : (
                                  <Badge variant="secondary">
                                    <Clock className="h-3 w-3 mr-1" />Pendente
                                  </Badge>
                                )}
                              </TableCell>
                              <TableCell>
                                {conta.status === 'pendente' && (
                                  <Button 
                                    size="sm" 
                                    className="bg-green-600 hover:bg-green-700"
                                    onClick={() => handleMarcarPago(conta.id)}
                                  >
                                    Pagar
                                  </Button>
                                )}
                              </TableCell>
                            </TableRow>
                          );
                        })
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Modal de Detalhes */}
        <Dialog open={modalAberto} onOpenChange={setModalAberto}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-2xl">Detalhes da Conta a Receber</DialogTitle>
            </DialogHeader>
            
            {contaSelecionada && (
              <div className="space-y-6">
                {/* Informações do Veículo e Cliente */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-gray-50 rounded-lg">
                  <div>
                    <p className="text-sm text-gray-600">Placa</p>
                    <p className="text-lg font-bold">{contaSelecionada.veiculo?.placa || 'N/A'}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Modelo</p>
                    <p className="text-lg font-semibold">{contaSelecionada.veiculo?.modelo || 'N/A'}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Cliente</p>
                    <p className="text-lg font-semibold">{contaSelecionada.cliente?.nome || 'N/A'}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Orçamento</p>
                    <p className="text-lg font-semibold">{contaSelecionada.orcamento?.numero || 'N/A'}</p>
                  </div>
                </div>

                {/* Orçamento Detalhado */}
                {orcamentoDetalhado && (
                  <div className="space-y-4">
                    {/* Peças */}
                    <div>
                      <h3 className="text-lg font-bold mb-3 flex items-center gap-2">
                        <span className="w-2 h-2 bg-blue-600 rounded-full"></span>
                        Peças
                      </h3>
                      <div className="border rounded-lg overflow-hidden">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Descrição</TableHead>
                              <TableHead className="text-right">Qtd</TableHead>
                              <TableHead className="text-right">Valor Unitário</TableHead>
                              <TableHead className="text-right">Total</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {orcamentoDetalhado.itens?.filter((item: any) => item.categoria === 'pecas').map((item: any) => (
                              <TableRow key={item.id}>
                                <TableCell>{item.descricao}</TableCell>
                                <TableCell className="text-right">{item.quantidade}</TableCell>
                                <TableCell className="text-right">
                                  R$ {(item.valorUnitario / 100).toLocaleString('pt-BR', {minimumFractionDigits: 2})}
                                </TableCell>
                                <TableCell className="text-right font-semibold">
                                  R$ {(item.valorTotal / 100).toLocaleString('pt-BR', {minimumFractionDigits: 2})}
                                </TableCell>
                              </TableRow>
                            ))}
                            <TableRow className="bg-blue-50">
                              <TableCell colSpan={3} className="text-right font-bold">Subtotal Peças:</TableCell>
                              <TableCell className="text-right font-bold text-blue-600">
                                R$ {(orcamentoDetalhado.orcamento.subtotalItens / 100).toLocaleString('pt-BR', {minimumFractionDigits: 2})}
                              </TableCell>
                            </TableRow>
                          </TableBody>
                        </Table>
                      </div>
                    </div>

                    {/* Serviços */}
                    <div>
                      <h3 className="text-lg font-bold mb-3 flex items-center gap-2">
                        <span className="w-2 h-2 bg-green-600 rounded-full"></span>
                        Serviços
                      </h3>
                      <div className="border rounded-lg overflow-hidden">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Descrição</TableHead>
                              <TableHead className="text-right">Qtd</TableHead>
                              <TableHead className="text-right">Valor Unitário</TableHead>
                              <TableHead className="text-right">Total</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {orcamentoDetalhado.itens?.filter((item: any) => item.categoria !== 'pecas').map((item: any) => (
                              <TableRow key={item.id}>
                                <TableCell>{item.descricao}</TableCell>
                                <TableCell className="text-right">{item.quantidade}</TableCell>
                                <TableCell className="text-right">
                                  R$ {(item.valorUnitario / 100).toLocaleString('pt-BR', {minimumFractionDigits: 2})}
                                </TableCell>
                                <TableCell className="text-right font-semibold">
                                  R$ {(item.valorTotal / 100).toLocaleString('pt-BR', {minimumFractionDigits: 2})}
                                </TableCell>
                              </TableRow>
                            ))}
                            <TableRow className="bg-green-50">
                              <TableCell colSpan={3} className="text-right font-bold">Subtotal Serviços:</TableCell>
                              <TableCell className="text-right font-bold text-green-600">
                                R$ {((orcamentoDetalhado.orcamento.total - orcamentoDetalhado.orcamento.subtotalItens) / 100).toLocaleString('pt-BR', {minimumFractionDigits: 2})}
                              </TableCell>
                            </TableRow>
                          </TableBody>
                        </Table>
                      </div>
                    </div>

                    {/* Total Geral */}
                    <div className="p-4 bg-gray-900 text-white rounded-lg">
                      <div className="flex items-center justify-between">
                        <span className="text-xl font-bold">TOTAL GERAL</span>
                        <span className="text-3xl font-bold">
                          R$ {(orcamentoDetalhado.orcamento.total / 100).toLocaleString('pt-BR', {minimumFractionDigits: 2})}
                        </span>
                      </div>
                    </div>

                    {/* Botões de Ação */}
                    <div className="flex gap-3 pt-4">
                      <Button 
                        className="flex-1 bg-blue-600 hover:bg-blue-700"
                        onClick={() => {
                          window.location.href = `/orcamentos/${orcamentoDetalhado.orcamento.id}`;
                        }}
                      >
                        Ver Orçamento Completo
                      </Button>
                      {contaSelecionada.status === 'pendente' && (
                        <Button 
                          className="flex-1 bg-green-600 hover:bg-green-700"
                          onClick={() => {
                            handleMarcarRecebido(contaSelecionada.id);
                            setModalAberto(false);
                          }}
                        >
                          <CheckCircle className="h-4 w-4 mr-2" />
                          Marcar como Recebido
                        </Button>
                      )}
                    </div>
                  </div>
                )}

                {!orcamentoDetalhado && (
                  <div className="text-center py-8 text-gray-500">
                    Carregando detalhes do orçamento...
                  </div>
                )}
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Modal Nova Conta a Pagar */}
        <Dialog open={modalNovaContaAberto} onOpenChange={setModalNovaContaAberto}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Nova Conta a Pagar</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="fornecedor">Fornecedor *</Label>
                  <Select 
                    value={novaContaForm.fornecedorId} 
                    onValueChange={(value) => setNovaContaForm({...novaContaForm, fornecedorId: value})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o fornecedor" />
                    </SelectTrigger>
                    <SelectContent>
                      {fornecedores?.map((f: any) => (
                        <SelectItem key={f.id} value={f.id.toString()}>
                          {f.nome}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="valor">Valor (R$) *</Label>
                  <Input
                    id="valor"
                    type="number"
                    step="0.01"
                    placeholder="0.00"
                    value={novaContaForm.valor}
                    onChange={(e) => setNovaContaForm({...novaContaForm, valor: e.target.value})}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="descricao">Descrição *</Label>
                <Input
                  id="descricao"
                  placeholder="Descrição da conta a pagar"
                  value={novaContaForm.descricao}
                  onChange={(e) => setNovaContaForm({...novaContaForm, descricao: e.target.value})}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="dataVencimento">Data de Vencimento *</Label>
                  <Input
                    id="dataVencimento"
                    type="date"
                    value={novaContaForm.dataVencimento}
                    onChange={(e) => setNovaContaForm({...novaContaForm, dataVencimento: e.target.value})}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="categoria">Categoria *</Label>
                  <Select 
                    value={novaContaForm.categoria} 
                    onValueChange={(value) => setNovaContaForm({...novaContaForm, categoria: value})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione a categoria" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Fornecedores">Fornecedores</SelectItem>
                      <SelectItem value="Impostos">Impostos</SelectItem>
                      <SelectItem value="Salários">Salários</SelectItem>
                      <SelectItem value="Aluguel">Aluguel</SelectItem>
                      <SelectItem value="Energia">Energia</SelectItem>
                      <SelectItem value="Água">Água</SelectItem>
                      <SelectItem value="Internet">Internet</SelectItem>
                      <SelectItem value="Telefone">Telefone</SelectItem>
                      <SelectItem value="Outros">Outros</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="formaPagamento">Forma de Pagamento *</Label>
                <Select 
                  value={novaContaForm.formaPagamento} 
                  onValueChange={(value) => setNovaContaForm({...novaContaForm, formaPagamento: value})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione a forma de pagamento" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Dinheiro">Dinheiro</SelectItem>
                    <SelectItem value="PIX">PIX</SelectItem>
                    <SelectItem value="Cartão de Crédito">Cartão de Crédito</SelectItem>
                    <SelectItem value="Cartão de Débito">Cartão de Débito</SelectItem>
                    <SelectItem value="Boleto">Boleto</SelectItem>
                    <SelectItem value="Transferência">Transferência</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="observacoes">Observações</Label>
                <Input
                  id="observacoes"
                  placeholder="Observações adicionais (opcional)"
                  value={novaContaForm.observacoes}
                  onChange={(e) => setNovaContaForm({...novaContaForm, observacoes: e.target.value})}
                />
              </div>

              <div className="flex justify-end gap-3 pt-4">
                <Button 
                  variant="outline" 
                  onClick={() => setModalNovaContaAberto(false)}
                >
                  Cancelar
                </Button>
                <Button 
                  onClick={handleCriarContaPagar}
                  disabled={criarContaPagarMutation.isPending}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  {criarContaPagarMutation.isPending ? 'Salvando...' : 'Salvar Conta'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </Layout>
  );
}
