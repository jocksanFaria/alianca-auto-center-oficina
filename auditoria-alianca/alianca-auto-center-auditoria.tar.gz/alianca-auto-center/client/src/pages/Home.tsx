import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { APP_LOGO, APP_TITLE, getLoginUrl } from "@/const";
import { Loader2, Wrench } from "lucide-react";
import { useEffect } from "react";
import { useLocation } from "wouter";

export default function Home() {
  const { user, loading } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!loading && user) {
      setLocation("/dashboard");
    }
  }, [loading, user, setLocation]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (user) {
    return null;
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-blue-50 to-gray-100 p-4">
      <div className="max-w-md w-full bg-white rounded-lg shadow-xl p-8 text-center">
        <div className="mb-6 flex justify-center">
          {APP_LOGO ? (
            <img src={APP_LOGO} alt={APP_TITLE} className="h-24 w-24 object-contain" />
          ) : (
            <div className="h-24 w-24 bg-primary rounded-full flex items-center justify-center">
              <Wrench className="h-12 w-12 text-white" />
            </div>
          )}
        </div>
        
        <h1 className="text-3xl font-bold text-gray-900 mb-2">{APP_TITLE}</h1>
        <p className="text-gray-600 mb-8">Sistema Completo de Gerenciamento de Oficina</p>
        
        <div className="space-y-4">
          <Button 
            onClick={() => window.location.href = getLoginUrl()} 
            className="w-full"
            size="lg"
          >
            Entrar no Sistema
          </Button>
          
          <div className="text-sm text-gray-500">
            <p>✓ Orçamentos e Ordens de Serviço</p>
            <p>✓ Controle Financeiro</p>
            <p>✓ Gestão de Estoque</p>
            <p>✓ Acesso de qualquer dispositivo</p>
          </div>
        </div>
      </div>
    </div>
  );
}
