import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { formatCurrency, parseCurrency } from "@/lib/currency";
import { useState, useEffect } from "react";
import { toast } from "sonner";
import { useLocation, useRoute } from "wouter";
import { Trash2, Plus, ArrowLeft } from "lucide-react";

type ItemOrcamento = {
  id?: number;
  descricao: string;
  quantidade: number;
  valorUnitario: number;
  categoria: "pecas" | "pintura" | "funilaria" | "outros";
};

type Complemento = {
  id?: number;
  descricao: string;
  valor: number;
  data: string;
  responsavel: string;
};

export default function OrcamentoEditar() {
  const [, params] = useRoute("/orcamentos/:id/editar");
  const [, setLocation] = useLocation();
  const id = params?.id ? parseInt(params.id) : 0;

  // Buscar dados do orçamento
  const { data, isLoading } = trpc.orcamentos.getById.useQuery({ id });
  const updateMutation = trpc.orcamentos.update.useMutation();

  // Estados
  const [itens, setItens] = useState<ItemOrcamento[]>([]);
  const [complementos, setComplementos] = useState<Complemento[]>([]);
  const [observacoes, setObservacoes] = useState("");
  const [desconto, setDesconto] = useState("0");
  const [acrescimo, setAcrescimo] = useState("0");
  const [status, setStatus] = useState<'pendente' | 'aprovado' | 'rejeitado' | 'em_execucao' | 'concluido'>('pendente');

  // Formulários para adicionar novos itens
  const [novoItemCategoria, setNovoItemCategoria] = useState<"pecas" | "pintura" | "funilaria" | "outros">("pecas");
  const [novoItemForm, setNovoItemForm] = useState({ descricao: "", quantidade: "1", valorUnitario: "0" });

  // Carregar dados quando disponíveis
  useEffect(() => {
    if (data) {
      setItens(data.itens.map(item => ({
        id: item.id,
        descricao: item.descricao,
        quantidade: item.quantidade,
        valorUnitario: item.valorUnitario,
        categoria: item.categoria as "pecas" | "pintura" | "funilaria" | "outros",
      })));
      
      setComplementos(data.complementos.map(comp => ({
        id: comp.id,
        descricao: comp.descricao,
        valor: comp.valor,
        data: new Date(comp.data).toISOString().split('T')[0],
        responsavel: comp.responsavel || "",
      })));
      
      setObservacoes(data.orcamento.observacoes || "");
      setDesconto(data.orcamento.desconto.toString());
      setAcrescimo(data.orcamento.acrescimo.toString());
      setStatus(data.orcamento.status as any);
    }
  }, [data]);

  if (isLoading) {
    return (
      <div className="container mx-auto p-6">
        <div className="text-center">Carregando...</div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="container mx-auto p-6">
        <div className="text-center">Orçamento não encontrado</div>
      </div>
    );
  }

  const { orcamento, cliente, veiculo } = data;

  // Adicionar novo item
  const adicionarItem = () => {
    if (!novoItemForm.descricao.trim()) {
      toast.error("Preencha a descrição do item");
      return;
    }

    const quantidade = parseFloat(novoItemForm.quantidade) || 0;
    const valorUnitario = parseCurrency(novoItemForm.valorUnitario);

    if (quantidade <= 0 || valorUnitario < 0) {
      toast.error("Quantidade e valor devem ser válidos");
      return;
    }

    setItens([...itens, {
      descricao: novoItemForm.descricao,
      quantidade,
      valorUnitario,
      categoria: novoItemCategoria,
    }]);

    setNovoItemForm({ descricao: "", quantidade: "1", valorUnitario: "0" });
    toast.success("Item adicionado");
  };

  // Remover item
  const removerItem = (index: number) => {
    setItens(itens.filter((_, i) => i !== index));
    toast.success("Item removido");
  };

  // Calcular totais
  const subtotalItens = itens.reduce((acc, item) => acc + (item.quantidade * item.valorUnitario), 0);
  const subtotalComplementos = complementos.reduce((acc, comp) => acc + comp.valor, 0);
  const descontoNum = parseCurrency(desconto);
  const acrescimoNum = parseCurrency(acrescimo);
  const total = subtotalItens + subtotalComplementos - descontoNum + acrescimoNum;

  // Salvar alterações
  const handleSalvar = async () => {
    try {
      await updateMutation.mutateAsync({
        id,
        itens: itens.map(item => ({
          categoria: item.categoria,
          descricao: item.descricao,
          quantidade: item.quantidade,
          valorUnitario: item.valorUnitario,
        })),
        complementos: complementos.map(comp => ({
          descricao: comp.descricao,
          valor: comp.valor,
          data: new Date(comp.data),
          responsavel: comp.responsavel,
        })),
        observacoes,
        desconto: descontoNum,
        acrescimo: acrescimoNum,
        status,
      });

      toast.success("Orçamento atualizado com sucesso!");
      setLocation(`/orcamentos/${id}`);
    } catch (error) {
      toast.error("Erro ao atualizar orçamento");
      console.error(error);
    }
  };

  return (
    <div className="container mx-auto p-6 max-w-6xl">
      <div className="flex items-center gap-4 mb-6">
        <Button variant="outline" size="icon" onClick={() => setLocation(`/orcamentos/${id}`)}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold">Editar Orçamento</h1>
          <p className="text-muted-foreground">Orçamento {orcamento.numero}</p>
        </div>
      </div>

      {/* Informações do Cliente e Veículo (somente leitura) */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Informações</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-2 gap-4">
          <div>
            <Label>Cliente</Label>
            <p className="text-sm font-medium">{cliente?.nome}</p>
            <p className="text-sm text-muted-foreground">{cliente?.telefone}</p>
          </div>
          <div>
            <Label>Veículo</Label>
            <p className="text-sm font-medium">{veiculo?.modelo}</p>
            <p className="text-sm text-muted-foreground">Placa: {veiculo?.placa}</p>
          </div>
        </CardContent>
      </Card>

      {/* Status */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Status do Orçamento</CardTitle>
        </CardHeader>
        <CardContent>
          <Select value={status} onValueChange={(value: any) => setStatus(value)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="pendente">Pendente</SelectItem>
              <SelectItem value="aprovado">Aprovado</SelectItem>
              <SelectItem value="rejeitado">Rejeitado</SelectItem>
              <SelectItem value="em_execucao">Em Execução</SelectItem>
              <SelectItem value="concluido">Concluído</SelectItem>
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {/* Itens do Orçamento */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Itens do Orçamento</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Lista de itens existentes */}
          {itens.map((item, index) => (
            <div key={index} className="flex items-center gap-4 p-4 border rounded-lg">
              <div className="flex-1 grid grid-cols-4 gap-4">
                <div>
                  <Label className="text-xs">Categoria</Label>
                  <p className="font-medium capitalize">{item.categoria}</p>
                </div>
                <div>
                  <Label className="text-xs">Descrição</Label>
                  <p className="font-medium">{item.descricao}</p>
                </div>
                <div>
                  <Label className="text-xs">Quantidade</Label>
                  <p className="font-medium">{item.quantidade}</p>
                </div>
                <div>
                  <Label className="text-xs">Valor Unit.</Label>
                  <p className="font-medium">{formatCurrency(item.valorUnitario)}</p>
                </div>
              </div>
              <Button variant="destructive" size="icon" onClick={() => removerItem(index)}>
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          ))}

          {/* Formulário para adicionar novo item */}
          <div className="border-t pt-4">
            <h4 className="font-semibold mb-3">Adicionar Novo Item</h4>
            <div className="grid grid-cols-5 gap-3">
              <Select value={novoItemCategoria} onValueChange={(value: any) => setNovoItemCategoria(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pecas">Peças</SelectItem>
                  <SelectItem value="pintura">Pintura</SelectItem>
                  <SelectItem value="funilaria">Funilaria</SelectItem>
                  <SelectItem value="outros">Outros</SelectItem>
                </SelectContent>
              </Select>
              
              <Input
                placeholder="Descrição"
                value={novoItemForm.descricao}
                onChange={(e) => setNovoItemForm({ ...novoItemForm, descricao: e.target.value })}
                className="col-span-2"
              />
              
              <Input
                type="number"
                placeholder="Qtd"
                value={novoItemForm.quantidade}
                onChange={(e) => setNovoItemForm({ ...novoItemForm, quantidade: e.target.value })}
              />
              
              <Input
                placeholder="Valor"
                value={novoItemForm.valorUnitario}
                onChange={(e) => setNovoItemForm({ ...novoItemForm, valorUnitario: e.target.value })}
              />
            </div>
            <Button onClick={adicionarItem} className="mt-3" variant="outline">
              <Plus className="h-4 w-4 mr-2" />
              Adicionar Item
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Observações e Totais */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Observações e Valores</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label>Observações</Label>
            <Textarea
              value={observacoes}
              onChange={(e) => setObservacoes(e.target.value)}
              placeholder="Observações adicionais..."
              rows={4}
            />
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <Label>Desconto</Label>
              <Input
                value={desconto}
                onChange={(e) => setDesconto(e.target.value)}
                placeholder="0,00"
              />
            </div>
            <div>
              <Label>Acréscimo</Label>
              <Input
                value={acrescimo}
                onChange={(e) => setAcrescimo(e.target.value)}
                placeholder="0,00"
              />
            </div>
            <div>
              <Label>Total</Label>
              <p className="text-2xl font-bold text-primary">{formatCurrency(total)}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Botões de Ação */}
      <div className="flex gap-4 justify-end">
        <Button variant="outline" onClick={() => setLocation(`/orcamentos/${id}`)}>
          Cancelar
        </Button>
        <Button onClick={handleSalvar} disabled={updateMutation.isPending}>
          {updateMutation.isPending ? "Salvando..." : "Salvar Alterações"}
        </Button>
      </div>
    </div>
  );
}
