import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { formatCurrency, parseCurrency } from "@/lib/currency";
import { useState } from "react";
import { toast } from "sonner";
import { useLocation } from "wouter";
import { MediaUpload } from "@/components/MediaUpload";

type ItemOrcamento = {
  descricao: string;
  quantidade: number;
  valorUnitario: number;
  categoria: "pecas" | "pintura" | "funilaria" | "outros";
};

type Complemento = {
  descricao: string;
  valor: number;
  data: string;
  responsavel: string;
};

export default function OrcamentoNovo() {
  const [, setLocation] = useLocation();
  
  // Dados do Veículo
  const [numeroOrcamento] = useState(`ORC-${Date.now()}`);
  const [modeloVeiculo, setModeloVeiculo] = useState("");
  const [numeroOS, setNumeroOS] = useState("");
  const [placa, setPlaca] = useState("");
  const [dataEntrada, setDataEntrada] = useState(new Date().toISOString().split('T')[0]);
  const [dataEntrega, setDataEntrega] = useState("");
  
  // Tipo de Cliente
  const [tipoCliente, setTipoCliente] = useState<'cadastrado' | 'novo'>('novo');
  const [clienteSelecionado, setClienteSelecionado] = useState<number | null>(null);
  
  // Dados do Cliente
  const [nomeCliente, setNomeCliente] = useState("");
  const [cpfCnpj, setCpfCnpj] = useState("");
  const [telefone, setTelefone] = useState("");
  const [email, setEmail] = useState("");
  
  // Mídias (fotos e vídeos)
  const [mediaFiles, setMediaFiles] = useState<File[]>([]);
  
  // Itens do Orçamento
  const [itens, setItens] = useState<ItemOrcamento[]>([]);
  
  // Formulários temporários para cada categoria
  const [pecasForm, setPecasForm] = useState({ descricao: "", quantidade: "1", valorUnitario: "0" });
  const [pinturaForm, setPinturaForm] = useState({ descricao: "", quantidade: "1", valorUnitario: "0" });
  const [funilariaForm, setFunilariaForm] = useState({ descricao: "", quantidade: "1", valorUnitario: "0" });
  const [outrosForm, setOutrosForm] = useState({ descricao: "", quantidade: "1", valorUnitario: "0" });
  
  // Complementos
  const [complementos, setComplementos] = useState<Complemento[]>([]);
  const [complementoForm, setComplementoForm] = useState({
    descricao: "",
    valor: "0",
    data: new Date().toISOString().split('T')[0],
    responsavel: ""
  });
  
  // Observações e Totais
  const [observacoes, setObservacoes] = useState("");
  const [desconto, setDesconto] = useState("0");
  const [acrescimo, setAcrescimo] = useState("0");
  
  const createMutation = trpc.orcamentos.create.useMutation();
  const uploadMediaMutation = trpc.media.uploadOrcamento.useMutation();
  const createClienteMutation = trpc.clientes.create.useMutation();
  const createVeiculoMutation = trpc.veiculos.create.useMutation();
  
  // Buscar lista de clientes
  const { data: clientes } = trpc.clientes.list.useQuery();
  
  const adicionarItem = (categoria: "pecas" | "pintura" | "funilaria" | "outros") => {
    let form;
    let setForm;
    
    switch (categoria) {
      case "pecas":
        form = pecasForm;
        setForm = setPecasForm;
        break;
      case "pintura":
        form = pinturaForm;
        setForm = setPinturaForm;
        break;
      case "funilaria":
        form = funilariaForm;
        setForm = setFunilariaForm;
        break;
      case "outros":
        form = outrosForm;
        setForm = setOutrosForm;
        break;
    }
    
    if (!form.descricao.trim()) {
      toast.error("Preencha a descrição");
      return;
    }
    
    const novoItem: ItemOrcamento = {
      descricao: form.descricao,
      quantidade: parseInt(form.quantidade) || 1,
      valorUnitario: parseCurrency(form.valorUnitario),
      categoria
    };
    
    setItens([...itens, novoItem]);
    setForm({ descricao: "", quantidade: "1", valorUnitario: "0" });
    toast.success("Item adicionado!");
  };
  
  const adicionarComplemento = () => {
    if (!complementoForm.descricao.trim()) {
      toast.error("Preencha a descrição do complemento");
      return;
    }
    
    const novoComplemento: Complemento = {
      descricao: complementoForm.descricao,
      valor: parseCurrency(complementoForm.valor),
      data: complementoForm.data,
      responsavel: complementoForm.responsavel
    };
    
    setComplementos([...complementos, novoComplemento]);
    setComplementoForm({
      descricao: "",
      valor: "0",
      data: new Date().toISOString().split('T')[0],
      responsavel: ""
    });
    toast.success("Complemento adicionado!");
  };
  
  const calcularTotal = () => {
    const subtotal = itens.reduce((acc, item) => acc + (item.quantidade * item.valorUnitario), 0);
    const totalComplementos = complementos.reduce((acc, comp) => acc + comp.valor, 0);
    const descontoVal = parseCurrency(desconto);
    const acrescimoVal = parseCurrency(acrescimo);
    
    return subtotal + totalComplementos - descontoVal + acrescimoVal;
  };
  const salvarOrcamento = async () => {
    if (!modeloVeiculo.trim()) {
      toast.error("Preencha o modelo do veículo");
      return;
    }
    
    if (itens.length === 0) {
      toast.error("Adicione pelo menos um item ao orçamento");
      return;
    }
    
    try {
      let clienteId: number;
      
      // Determinar clienteId
      if (tipoCliente === 'cadastrado') {
        if (!clienteSelecionado) {
          toast.error("Selecione um cliente");
          return;
        }
        clienteId = clienteSelecionado;
      } else {
        // Criar novo cliente
        if (!nomeCliente.trim()) {
          toast.error("Preencha o nome do cliente");
          return;
        }
        const cliente = await createClienteMutation.mutateAsync({
          nome: nomeCliente,
          cpfCnpj: cpfCnpj || undefined,
          telefone: telefone || undefined,
          email: email || undefined,
        });
        clienteId = cliente.id;
      }
      
      // Criar veículo
      const veiculo = await createVeiculoMutation.mutateAsync({
        clienteId: clienteId,
        placa: placa,
        modelo: modeloVeiculo,
      });
      
      // Criar orçamento
      const orcamento = await createMutation.mutateAsync({
        clienteId: clienteId,
        veiculoId: veiculo.id,
        dataEntrada: new Date(dataEntrada),
        prazoEntrega: dataEntrega ? new Date(dataEntrega) : undefined,
        numeroOS: numeroOS || undefined,
        status: 'pendente' as const,
        observacoes: observacoes || undefined,
        desconto: parseCurrency(desconto),
        acrescimo: parseCurrency(acrescimo),
        itens: itens,
        complementos: complementos.map(c => ({
          ...c,
          data: new Date(c.data)
        })),
      });
      
      // Upload de mídias se houver
      if (mediaFiles.length > 0) {
        toast.info("Fazendo upload de fotos e vídeos...");
        
        // Converter arquivos para base64
        const filesData = await Promise.all(
          mediaFiles.map(async (file) => {
            const buffer = await file.arrayBuffer();
            const base64 = btoa(
              new Uint8Array(buffer).reduce(
                (data, byte) => data + String.fromCharCode(byte),
                ''
              )
            );
            
            return {
              name: file.name,
              type: file.type,
              size: file.size,
              data: base64,
            };
          })
        );
        
        // Fazer upload
        await uploadMediaMutation.mutateAsync({
          orcamentoId: orcamento.id,
          files: filesData,
        });
      }
      
      toast.success("Orçamento salvo com sucesso!");
      setLocation("/orcamentos");
    } catch (error: any) {
      const errorMessage = error?.message || error?.data?.message || "Erro desconhecido";
      toast.error(`Erro ao salvar orçamento: ${errorMessage}`);
      console.error("Erro completo:", error);
    }
  };
  
  return (
    <Layout>
      <div className="max-w-5xl mx-auto space-y-6 pb-8">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold">Criar Novo Orçamento</h1>
        </div>
        
        {/* Dados do Veículo */}
        <Card>
          <CardHeader>
            <CardTitle>Dados do Veículo</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label>Número do Orçamento</Label>
                <Input value={numeroOrcamento} disabled className="bg-gray-50" />
              </div>
              <div>
                <Label>Data de Entrada</Label>
                <Input type="date" value={dataEntrada} onChange={(e) => setDataEntrada(e.target.value)} />
              </div>
              <div>
                <Label>Data de Entrega</Label>
                <Input type="date" value={dataEntrega} onChange={(e) => setDataEntrega(e.target.value)} />
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label>Modelo do Veículo *</Label>
                <Input value={modeloVeiculo} onChange={(e) => setModeloVeiculo(e.target.value)} placeholder="Ex: Fiat Uno" />
              </div>
              <div>
                <Label>Número da OS</Label>
                <Input value={numeroOS} onChange={(e) => setNumeroOS(e.target.value)} placeholder="Ex: OS-2025-001" />
              </div>
              <div>
                <Label>Placa</Label>
                <Input value={placa} onChange={(e) => setPlaca(e.target.value.toUpperCase())} placeholder="Ex: ABC-1234" maxLength={8} />
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Dados do Cliente */}
        <Card>
          <CardHeader>
            <CardTitle>Dados do Cliente</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Toggle Tipo de Cliente */}
            <div className="flex gap-2">
              <Button
                type="button"
                variant={tipoCliente === 'cadastrado' ? 'default' : 'outline'}
                onClick={() => setTipoCliente('cadastrado')}
                className="flex-1"
              >
                Cliente Cadastrado
              </Button>
              <Button
                type="button"
                variant={tipoCliente === 'novo' ? 'default' : 'outline'}
                onClick={() => setTipoCliente('novo')}
                className="flex-1"
              >
                Cliente Novo
              </Button>
            </div>
            
            {tipoCliente === 'cadastrado' ? (
              /* Seleção de Cliente Cadastrado */
              <div>
                <Label>Selecione o Cliente *</Label>
                <select
                  className="w-full border border-gray-300 rounded-md p-2"
                  value={clienteSelecionado || ''}
                  onChange={(e) => setClienteSelecionado(Number(e.target.value))}
                >
                  <option value="">Selecione um cliente...</option>
                  {clientes?.map((cliente) => (
                    <option key={cliente.id} value={cliente.id}>
                      {cliente.nome} {cliente.cpfCnpj ? `- ${cliente.cpfCnpj}` : ''}
                    </option>
                  ))}
                </select>
              </div>
            ) : (
              /* Campos para Cliente Novo */
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label>Nome Completo *</Label>
                    <Input value={nomeCliente} onChange={(e) => setNomeCliente(e.target.value)} placeholder="Nome do cliente" />
                  </div>
                  <div>
                    <Label>CPF/CNPJ</Label>
                    <Input value={cpfCnpj} onChange={(e) => setCpfCnpj(e.target.value)} placeholder="000.000.000-00" />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label>Telefone</Label>
                    <Input value={telefone} onChange={(e) => setTelefone(e.target.value)} placeholder="(00) 00000-0000" />
                  </div>
                  <div>
                    <Label>E-mail</Label>
                    <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="cliente@email.com" />
                  </div>
                </div>
              </>
            )}
          </CardContent>
        </Card>
        
        {/* Itens do Orçamento - Peças */}
        <Card>
          <CardHeader>
            <CardTitle>Peças</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-12 gap-2">
              <div className="col-span-6">
                <Label>Descrição</Label>
                <Input value={pecasForm.descricao} onChange={(e) => setPecasForm({...pecasForm, descricao: e.target.value})} placeholder="Descrição da peça" />
              </div>
              <div className="col-span-2">
                <Label>Qtd</Label>
                <Input type="number" min="1" value={pecasForm.quantidade} onChange={(e) => setPecasForm({...pecasForm, quantidade: e.target.value})} />
              </div>
              <div className="col-span-3">
                <Label>Valor Unit.</Label>
                <Input 
                  value={pecasForm.valorUnitario} 
                  onChange={(e) => setPecasForm({...pecasForm, valorUnitario: e.target.value})}
                  onBlur={(e) => {
                    const formatted = formatCurrency(parseCurrency(e.target.value));
                    setPecasForm({...pecasForm, valorUnitario: formatted});
                  }}
                  placeholder="R$ 0,00"
                />
              </div>
              <div className="col-span-1 flex items-end">
                <Button type="button" onClick={() => adicionarItem("pecas")} className="w-full">+</Button>
              </div>
            </div>
            {itens.filter(i => i.categoria === "pecas").map((item, idx) => (
              <div key={idx} className="text-sm bg-gray-50 p-2 rounded">
                {item.descricao} - Qtd: {item.quantidade} - {formatCurrency(item.valorUnitario)} = {formatCurrency(item.quantidade * item.valorUnitario)}
              </div>
            ))}
          </CardContent>
        </Card>
        
        {/* Pintura */}
        <Card>
          <CardHeader>
            <CardTitle>Pintura</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-12 gap-2">
              <div className="col-span-6">
                <Label>Descrição</Label>
                <Input value={pinturaForm.descricao} onChange={(e) => setPinturaForm({...pinturaForm, descricao: e.target.value})} placeholder="Descrição do serviço" />
              </div>
              <div className="col-span-2">
                <Label>Qtd</Label>
                <Input type="number" min="1" value={pinturaForm.quantidade} onChange={(e) => setPinturaForm({...pinturaForm, quantidade: e.target.value})} />
              </div>
              <div className="col-span-3">
                <Label>Valor Unit.</Label>
                <Input 
                  value={pinturaForm.valorUnitario} 
                  onChange={(e) => setPinturaForm({...pinturaForm, valorUnitario: e.target.value})}
                  onBlur={(e) => {
                    const formatted = formatCurrency(parseCurrency(e.target.value));
                    setPinturaForm({...pinturaForm, valorUnitario: formatted});
                  }}
                  placeholder="R$ 0,00"
                />
              </div>
              <div className="col-span-1 flex items-end">
                <Button type="button" onClick={() => adicionarItem("pintura")} className="w-full">+</Button>
              </div>
            </div>
            {itens.filter(i => i.categoria === "pintura").map((item, idx) => (
              <div key={idx} className="text-sm bg-gray-50 p-2 rounded">
                {item.descricao} - Qtd: {item.quantidade} - {formatCurrency(item.valorUnitario)} = {formatCurrency(item.quantidade * item.valorUnitario)}
              </div>
            ))}
          </CardContent>
        </Card>
        
        {/* Funilaria */}
        <Card>
          <CardHeader>
            <CardTitle>Funilaria</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-12 gap-2">
              <div className="col-span-6">
                <Label>Descrição</Label>
                <Input value={funilariaForm.descricao} onChange={(e) => setFunilariaForm({...funilariaForm, descricao: e.target.value})} placeholder="Descrição do serviço" />
              </div>
              <div className="col-span-2">
                <Label>Qtd</Label>
                <Input type="number" min="1" value={funilariaForm.quantidade} onChange={(e) => setFunilariaForm({...funilariaForm, quantidade: e.target.value})} />
              </div>
              <div className="col-span-3">
                <Label>Valor Unit.</Label>
                <Input 
                  value={funilariaForm.valorUnitario} 
                  onChange={(e) => setFunilariaForm({...funilariaForm, valorUnitario: e.target.value})}
                  onBlur={(e) => {
                    const formatted = formatCurrency(parseCurrency(e.target.value));
                    setFunilariaForm({...funilariaForm, valorUnitario: formatted});
                  }}
                  placeholder="R$ 0,00"
                />
              </div>
              <div className="col-span-1 flex items-end">
                <Button type="button" onClick={() => adicionarItem("funilaria")} className="w-full">+</Button>
              </div>
            </div>
            {itens.filter(i => i.categoria === "funilaria").map((item, idx) => (
              <div key={idx} className="text-sm bg-gray-50 p-2 rounded">
                {item.descricao} - Qtd: {item.quantidade} - {formatCurrency(item.valorUnitario)} = {formatCurrency(item.quantidade * item.valorUnitario)}
              </div>
            ))}
          </CardContent>
        </Card>
        
        {/* Outros */}
        <Card>
          <CardHeader>
            <CardTitle>Outros</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-12 gap-2">
              <div className="col-span-6">
                <Label>Descrição</Label>
                <Input value={outrosForm.descricao} onChange={(e) => setOutrosForm({...outrosForm, descricao: e.target.value})} placeholder="Descrição" />
              </div>
              <div className="col-span-2">
                <Label>Qtd</Label>
                <Input type="number" min="1" value={outrosForm.quantidade} onChange={(e) => setOutrosForm({...outrosForm, quantidade: e.target.value})} />
              </div>
              <div className="col-span-3">
                <Label>Valor Unit.</Label>
                <Input 
                  value={outrosForm.valorUnitario} 
                  onChange={(e) => setOutrosForm({...outrosForm, valorUnitario: e.target.value})}
                  onBlur={(e) => {
                    const formatted = formatCurrency(parseCurrency(e.target.value));
                    setOutrosForm({...outrosForm, valorUnitario: formatted});
                  }}
                  placeholder="R$ 0,00"
                />
              </div>
              <div className="col-span-1 flex items-end">
                <Button type="button" onClick={() => adicionarItem("outros")} className="w-full">+</Button>
              </div>
            </div>
            {itens.filter(i => i.categoria === "outros").map((item, idx) => (
              <div key={idx} className="text-sm bg-gray-50 p-2 rounded">
                {item.descricao} - Qtd: {item.quantidade} - {formatCurrency(item.valorUnitario)} = {formatCurrency(item.quantidade * item.valorUnitario)}
              </div>
            ))}
          </CardContent>
        </Card>
        
        {/* Complementos */}
        <Card>
          <CardHeader>
            <CardTitle>Complementos</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-12 gap-2">
              <div className="col-span-4">
                <Label>Descrição</Label>
                <Input value={complementoForm.descricao} onChange={(e) => setComplementoForm({...complementoForm, descricao: e.target.value})} placeholder="Descrição" />
              </div>
              <div className="col-span-2">
                <Label>Valor</Label>
                <Input 
                  value={complementoForm.valor} 
                  onChange={(e) => setComplementoForm({...complementoForm, valor: e.target.value})}
                  onBlur={(e) => {
                    const formatted = formatCurrency(parseCurrency(e.target.value));
                    setComplementoForm({...complementoForm, valor: formatted});
                  }}
                  placeholder="R$ 0,00"
                />
              </div>
              <div className="col-span-2">
                <Label>Data</Label>
                <Input type="date" value={complementoForm.data} onChange={(e) => setComplementoForm({...complementoForm, data: e.target.value})} />
              </div>
              <div className="col-span-3">
                <Label>Responsável</Label>
                <Input value={complementoForm.responsavel} onChange={(e) => setComplementoForm({...complementoForm, responsavel: e.target.value})} placeholder="Nome" />
              </div>
              <div className="col-span-1 flex items-end">
                <Button type="button" onClick={adicionarComplemento} className="w-full">+</Button>
              </div>
            </div>
            {complementos.map((comp, idx) => (
              <div key={idx} className="text-sm bg-gray-50 p-2 rounded">
                {comp.descricao} - {formatCurrency(comp.valor)} - {new Date(comp.data).toLocaleDateString('pt-BR')} - {comp.responsavel}
              </div>
            ))}
          </CardContent>
        </Card>
        
        {/* Observações */}
        <Card>
          <CardHeader>
            <CardTitle>Observações</CardTitle>
          </CardHeader>
          <CardContent>
            <Textarea value={observacoes} onChange={(e) => setObservacoes(e.target.value)} placeholder="Observações adicionais..." rows={4} />
          </CardContent>
        </Card>
        
        {/* Fotos e Vídeos */}
        <Card>
          <CardHeader>
            <CardTitle>Fotos e Vídeos</CardTitle>
          </CardHeader>
          <CardContent>
            <MediaUpload 
              onMediaChange={setMediaFiles}
              maxVideoSize={50}
              maxImageSize={10}
            />
          </CardContent>
        </Card>
        
        {/* Totais e Ações */}
        <Card>
          <CardContent className="pt-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div>
                <Label>Desconto (R$)</Label>
                <Input 
                  value={desconto} 
                  onChange={(e) => setDesconto(e.target.value)}
                  onBlur={(e) => setDesconto(formatCurrency(parseCurrency(e.target.value)))}
                  placeholder="R$ 0,00"
                />
              </div>
              <div>
                <Label>Acréscimo (R$)</Label>
                <Input 
                  value={acrescimo} 
                  onChange={(e) => setAcrescimo(e.target.value)}
                  onBlur={(e) => setAcrescimo(formatCurrency(parseCurrency(e.target.value)))}
                  placeholder="R$ 0,00"
                />
              </div>
              <div>
                <Label>Total Geral</Label>
                <div className="text-2xl font-bold text-green-600">{formatCurrency(calcularTotal())}</div>
              </div>
            </div>
            
            <div className="flex gap-4 justify-end">
              <Button variant="outline" onClick={() => setLocation("/orcamentos")}>Cancelar</Button>
              <Button onClick={salvarOrcamento} disabled={createMutation.isPending}>
                {createMutation.isPending ? "Salvando..." : "Salvar Orçamento"}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
