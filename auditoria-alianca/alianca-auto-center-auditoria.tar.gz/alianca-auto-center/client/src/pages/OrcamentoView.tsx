import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { trpc } from "@/lib/trpc";
import { useRoute, useLocation } from "wouter";
import { ArrowLeft, Mail, Printer, Download, Pencil } from "lucide-react";
import { toast } from "sonner";
import { formatCurrency } from "@/lib/utils";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useState } from "react";

export default function OrcamentoView() {
  const [, params] = useRoute("/orcamentos/:id");
  const [, setLocation] = useLocation();
  const id = Number(params?.id);

  const { data, isLoading, error, refetch } = trpc.orcamentos.getById.useQuery({ id });
  const updateStatusMutation = trpc.orcamentos.updateStatus.useMutation();
  const generatePDFMutation = trpc.orcamentos.generatePDF.useMutation();
  const utils = trpc.useUtils();
  const [isUpdatingStatus, setIsUpdatingStatus] = useState(false);

  if (isLoading) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-[400px]">
          <p className="text-gray-500">Carregando orçamento...</p>
        </div>
      </Layout>
    );
  }

  if (error) {
    return (
      <Layout>
        <div className="flex flex-col items-center justify-center min-h-[400px] space-y-4">
          <p className="text-red-600 font-semibold">Erro ao carregar orçamento</p>
          <p className="text-gray-500">{error.message}</p>
          <div className="flex gap-2">
            <Button onClick={() => refetch()}>Tentar Novamente</Button>
            <Button variant="outline" onClick={() => setLocation("/orcamentos")}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Voltar para Orçamentos
            </Button>
          </div>
        </div>
      </Layout>
    );
  }

  if (!data) {
    return (
      <Layout>
        <div className="flex flex-col items-center justify-center min-h-[400px] space-y-4">
          <p className="text-gray-500">Orçamento não encontrado</p>
          <Button onClick={() => setLocation("/orcamentos")}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Voltar para Orçamentos
          </Button>
        </div>
      </Layout>
    );
  }

  const { orcamento, cliente, veiculo, itens, complementos, midias } = data;

  const handleSendEmail = async () => {
    try {
      toast.info("Gerando PDF e abrindo e-mail...");
      const result = await generatePDFMutation.mutateAsync({ id });
      
      // Converter base64 para blob
      const pdfBlob = new Blob(
        [Uint8Array.from(atob(result.pdf), c => c.charCodeAt(0))],
        { type: 'application/pdf' }
      );
      
      // Criar mensagem de e-mail
      const emailSubject = encodeURIComponent(`Or\u00e7amento ${orcamento.numero} - Alian\u00e7a Auto Center`);
      const emailBody = encodeURIComponent(
        `Prezado(a) ${cliente?.nome},\n\n` +
        `Segue em anexo o or\u00e7amento ${orcamento.numero} conforme solicitado.\n\n` +
        `Ve\u00edculo: ${veiculo?.placa} - ${veiculo?.modelo}\n` +
        `Valor Total: ${formatCurrency(orcamento.total)}\n\n` +
        `Ficamos \u00e0 disposi\u00e7\u00e3o para esclarecer quaisquer d\u00favidas.\n\n` +
        `Atenciosamente,\n\n` +
        `---\n` +
        `Alian\u00e7a Auto Center\n` +
        `Funilaria e Pintura\n` +
        `WhatsApp: (62) 9 9662-7364\n` +
        `E-mail: funilariaalianca10@gmail.com\n` +
        `Endere\u00e7o: Ner\u00f3polis QD-01 LT-07 Residencial Jos\u00e9 Viandeli\n` +
        `Bairro Balne\u00e1rio Meia Ponte - Goi\u00e2nia/GO - CEP: 74594-300`
      );
      
      // Baixar PDF automaticamente
      const url = URL.createObjectURL(pdfBlob);
      const link = document.createElement('a');
      link.href = url;
      link.download = result.filename;
      link.click();
      URL.revokeObjectURL(url);
      
      // Abrir cliente de e-mail direto (Outlook/Gmail) com c\u00f3pia para empresa
      const mailtoLink = `mailto:${cliente?.email || ''}?cc=funilariaalianca10@gmail.com&subject=${emailSubject}&body=${emailBody}`;
      window.location.href = mailtoLink;
      
      toast.success("PDF baixado! App de e-mail aberto.");
    } catch (error) {
      toast.error("Erro ao enviar or\u00e7amento");
      console.error(error);
    }
  };

  const handlePrint = async () => {
    try {
      toast.info("Gerando PDF para impress\u00e3o...");
      const result = await generatePDFMutation.mutateAsync({ id });
      
      // Converter base64 para blob
      const pdfBlob = new Blob(
        [Uint8Array.from(atob(result.pdf), c => c.charCodeAt(0))],
        { type: 'application/pdf' }
      );
      
      // Criar URL do PDF
      const url = URL.createObjectURL(pdfBlob);
      
      // Abrir em nova aba para impress\u00e3o
      const printWindow = window.open(url, '_blank');
      
      if (printWindow) {
        printWindow.onload = () => {
          printWindow.print();
        };
        toast.success("PDF aberto para impress\u00e3o!");
      } else {
        toast.error("Bloqueador de pop-up impediu a abertura. Por favor, permita pop-ups.");
      }
      
      // Limpar URL ap\u00f3s 1 minuto
      setTimeout(() => URL.revokeObjectURL(url), 60000);
    } catch (error) {
      toast.error("Erro ao gerar PDF para impress\u00e3o");
      console.error(error);
    }
  };
  
  const handleDownloadPDF = async () => {
    try {
      toast.info("Gerando PDF...");
      const result = await generatePDFMutation.mutateAsync({ id });
      
      // Converter base64 para blob
      const pdfBlob = new Blob(
        [Uint8Array.from(atob(result.pdf), c => c.charCodeAt(0))],
        { type: 'application/pdf' }
      );
      
      // Criar link de download
      const url = URL.createObjectURL(pdfBlob);
      const link = document.createElement('a');
      link.href = url;
      link.download = result.filename;
      link.click();
      URL.revokeObjectURL(url);
      
      toast.success("PDF baixado com sucesso!");
    } catch (error) {
      toast.error("Erro ao gerar PDF");
      console.error(error);
    }
  };

  const handleEdit = () => {
    setLocation(`/orcamentos/${id}/editar`);
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, { variant: "default" | "secondary" | "destructive"; label: string }> = {
      pendente: { variant: "secondary", label: "Pendente" },
      aprovado: { variant: "default", label: "Aprovado" },
      rejeitado: { variant: "destructive", label: "Rejeitado" },
      em_execucao: { variant: "default", label: "Em Execução" },
      concluido: { variant: "default", label: "Concluído" },
    };
    const config = variants[status] || { variant: "default", label: status };
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  const getCategoriaLabel = (categoria: string) => {
    const labels: Record<string, string> = {
      pecas: "Peças",
      pintura: "Pintura",
      funilaria: "Funilaria",
      outros: "Outros",
    };
    return labels[categoria] || categoria;
  };

  return (
    <Layout>
      <div className="space-y-6 print:space-y-4">
        {/* Header com botões de ação */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 print:hidden">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => setLocation("/orcamentos")}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-3xl font-bold">Orçamento {orcamento.numero}</h1>
              <p className="text-gray-600 mt-1">
                Criado em {new Date(orcamento.dataEntrada).toLocaleDateString('pt-BR')}
              </p>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" size="sm" onClick={handleSendEmail}>
              <Mail className="h-4 w-4 mr-2" />
              Enviar E-mail
            </Button>
            <Button variant="outline" size="sm" onClick={handlePrint}>
              <Printer className="h-4 w-4 mr-2" />
              Imprimir
            </Button>
            <Button variant="outline" size="sm" onClick={handleDownloadPDF}>
              <Download className="h-4 w-4 mr-2" />
              Download PDF
            </Button>
            <Button variant="default" size="sm" onClick={handleEdit}>
              <Pencil className="h-4 w-4 mr-2" />
              Editar
            </Button>
          </div>
        </div>

        {/* Informações principais */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Cliente */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Dados do Cliente</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div>
                <p className="text-sm text-gray-600">Nome</p>
                <p className="font-medium">{cliente?.nome || "Não informado"}</p>
              </div>
              {cliente?.cpfCnpj && (
                <div>
                  <p className="text-sm text-gray-600">CPF/CNPJ</p>
                  <p className="font-medium">{cliente.cpfCnpj}</p>
                </div>
              )}
              {cliente?.telefone && (
                <div>
                  <p className="text-sm text-gray-600">Telefone</p>
                  <p className="font-medium">{cliente.telefone}</p>
                </div>
              )}
              {cliente?.email && (
                <div>
                  <p className="text-sm text-gray-600">E-mail</p>
                  <p className="font-medium">{cliente.email}</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Veículo */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Dados do Veículo</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div>
                <p className="text-sm text-gray-600">Placa</p>
                <p className="font-medium">{veiculo?.placa || "Não informado"}</p>
              </div>
              {veiculo?.marca && (
                <div>
                  <p className="text-sm text-gray-600">Marca</p>
                  <p className="font-medium">{veiculo.marca}</p>
                </div>
              )}
              {veiculo?.modelo && (
                <div>
                  <p className="text-sm text-gray-600">Modelo</p>
                  <p className="font-medium">{veiculo.modelo}</p>
                </div>
              )}
              {veiculo?.ano && (
                <div>
                  <p className="text-sm text-gray-600">Ano</p>
                  <p className="font-medium">{veiculo.ano}</p>
                </div>
              )}
              {veiculo?.cor && (
                <div>
                  <p className="text-sm text-gray-600">Cor</p>
                  <p className="font-medium">{veiculo.cor}</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Status e informações adicionais */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Informações do Orçamento</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <p className="text-sm text-gray-600 mb-2">Status</p>
              <Select
                value={orcamento.status}
                onValueChange={async (newStatus) => {
                  setIsUpdatingStatus(true);
                  try {
                    await updateStatusMutation.mutateAsync({ id, status: newStatus as any });
                    toast.success("Status atualizado!");
                    // Invalidar cache do Dashboard e lista de orçamentos
                    await utils.dashboard.stats.invalidate();
                    await utils.orcamentos.list.invalidate();
                    refetch();
                  } catch (error) {
                    toast.error("Erro ao atualizar status");
                  } finally {
                    setIsUpdatingStatus(false);
                  }
                }}
                disabled={isUpdatingStatus}
              >
                <SelectTrigger className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pendente">Pendente</SelectItem>
                  <SelectItem value="aprovado">Aprovado</SelectItem>
                  <SelectItem value="rejeitado">Rejeitado</SelectItem>
                  <SelectItem value="em_execucao">Em Execução</SelectItem>
                  <SelectItem value="concluido">Concluído</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <p className="text-sm text-gray-600">Data de Entrada</p>
              <p className="font-medium">{new Date(orcamento.dataEntrada).toLocaleDateString('pt-BR')}</p>
            </div>
            {orcamento.prazoEntrega && (
              <div>
                <p className="text-sm text-gray-600">Prazo de Entrega</p>
                <p className="font-medium">{new Date(orcamento.prazoEntrega).toLocaleDateString('pt-BR')}</p>
              </div>
            )}
            {orcamento.numeroOS && (
              <div>
                <p className="text-sm text-gray-600">Número da OS</p>
                <p className="font-medium">{orcamento.numeroOS}</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Itens do orçamento */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Itens do Orçamento</CardTitle>
          </CardHeader>
          <CardContent>
            {!itens || itens.length === 0 ? (
              <p className="text-center text-gray-500 py-4">Nenhum item cadastrado</p>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Categoria</TableHead>
                      <TableHead>Descrição</TableHead>
                      <TableHead className="text-right">Qtd</TableHead>
                      <TableHead className="text-right">Valor Unit.</TableHead>
                      <TableHead className="text-right">Total</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {itens.map((item, index) => (
                      <TableRow key={index}>
                        <TableCell>
                          <Badge variant="outline">{getCategoriaLabel(item.categoria)}</Badge>
                        </TableCell>
                        <TableCell>{item.descricao}</TableCell>
                        <TableCell className="text-right">{item.quantidade}</TableCell>
                        <TableCell className="text-right">{formatCurrency(item.valorUnitario)}</TableCell>
                        <TableCell className="text-right font-medium">{formatCurrency(item.valorTotal)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Complementos */}
        {complementos && complementos.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Complementos</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Descrição</TableHead>
                      <TableHead>Data</TableHead>
                      <TableHead>Responsável</TableHead>
                      <TableHead className="text-right">Valor</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {complementos.map((comp, index) => (
                      <TableRow key={index}>
                        <TableCell>{comp.descricao}</TableCell>
                        <TableCell>{new Date(comp.data).toLocaleDateString('pt-BR')}</TableCell>
                        <TableCell>{comp.responsavel || "-"}</TableCell>
                        <TableCell className="text-right font-medium">{formatCurrency(comp.valor)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Observações */}
        {orcamento.observacoes && (
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Observações</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="whitespace-pre-wrap">{orcamento.observacoes}</p>
            </CardContent>
          </Card>
        )}

        {/* Galeria de Fotos/Vídeos */}
        {midias && midias.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Fotos e Vídeos</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {midias.map((midia: any, index: number) => (
                  <div key={index} className="relative group">
                    {midia.tipo === 'foto' ? (
                      <img
                        src={midia.url}
                        alt={midia.fileName || `Foto ${index + 1}`}
                        className="w-full h-40 object-cover rounded-lg cursor-pointer hover:opacity-80 transition-opacity"
                        onClick={() => window.open(midia.url, '_blank')}
                      />
                    ) : (
                      <video
                        src={midia.url}
                        className="w-full h-40 object-cover rounded-lg cursor-pointer"
                        controls
                      />
                    )}
                    <div className="absolute bottom-2 left-2 bg-black/70 text-white text-xs px-2 py-1 rounded">
                      {midia.tipo === 'foto' ? '📷' : '🎥'} {(midia.fileSize / 1024 / 1024).toFixed(2)} MB
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Totais */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Resumo Financeiro</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between items-center">
              <p className="text-gray-600">Subtotal de Itens</p>
              <p className="font-medium">{formatCurrency(orcamento.subtotalItens)}</p>
            </div>
            {orcamento.subtotalComplementos > 0 && (
              <div className="flex justify-between items-center">
                <p className="text-gray-600">Subtotal de Complementos</p>
                <p className="font-medium">{formatCurrency(orcamento.subtotalComplementos)}</p>
              </div>
            )}
            {orcamento.desconto > 0 && (
              <div className="flex justify-between items-center text-red-600">
                <p>Desconto</p>
                <p className="font-medium">- {formatCurrency(orcamento.desconto)}</p>
              </div>
            )}
            {orcamento.acrescimo > 0 && (
              <div className="flex justify-between items-center text-green-600">
                <p>Acréscimo</p>
                <p className="font-medium">+ {formatCurrency(orcamento.acrescimo)}</p>
              </div>
            )}
            <div className="border-t pt-3 flex justify-between items-center">
              <p className="text-xl font-bold">Total Geral</p>
              <p className="text-2xl font-bold text-green-600">{formatCurrency(orcamento.total)}</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
