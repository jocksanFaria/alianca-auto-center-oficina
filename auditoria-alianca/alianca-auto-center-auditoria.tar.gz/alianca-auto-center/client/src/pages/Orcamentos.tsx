import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { Plus, Eye, Pencil, Trash2, Search } from "lucide-react";
import { Link, useLocation } from "wouter";
import { toast } from "sonner";
import { useMemo, useState } from "react";
import { Input } from "@/components/ui/input";

export default function Orcamentos() {
  const [location] = useLocation();
  const [searchPlaca, setSearchPlaca] = useState("");
  
  const statusFilter = useMemo(() => {
    const params = new URLSearchParams(location.split('?')[1]);
    return params.get('status') || undefined;
  }, [location]);
  
  const { data: orcamentos, isLoading, refetch } = trpc.orcamentos.list.useQuery({ 
    status: statusFilter,
    placa: searchPlaca || undefined 
  });
  const deleteMutation = trpc.orcamentos.delete.useMutation();

  const handleDelete = async (id: number) => {
    if (!confirm("Excluir este orçamento?")) return;
    try {
      await deleteMutation.mutateAsync({ id });
      toast.success("Orçamento excluído!");
      refetch();
    } catch (error) {
      toast.error("Erro ao excluir");
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, "default" | "secondary" | "destructive"> = {
      pendente: "secondary",
      aprovado: "default",
      rejeitado: "destructive",
    };
    return <Badge variant={variants[status] || "default"}>{status}</Badge>;
  };

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Orçamentos</h1>
            <p className="text-gray-600 mt-1">Gerencie seus orçamentos</p>
          </div>
          <Link href="/orcamentos/novo">
            <Button><Plus className="h-4 w-4 mr-2" />Novo Orçamento</Button>
          </Link>
        </div>

        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Lista de Orçamentos</CardTitle>
              <div className="relative w-64">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Buscar por placa..."
                  value={searchPlaca}
                  onChange={(e) => setSearchPlaca(e.target.value.toUpperCase())}
                  className="pl-10"
                />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? <p className="text-center py-8">Carregando...</p> :
             !orcamentos?.length ? <p className="text-center py-8">Nenhum orçamento cadastrado</p> :
             <Table>
               <TableHeader>
                 <TableRow>
                   <TableHead>Número</TableHead>
                   <TableHead className="hidden md:table-cell">Data</TableHead>
                   <TableHead>Veículo</TableHead>
                   <TableHead className="hidden lg:table-cell">Cliente</TableHead>
                   <TableHead>Status</TableHead>
                   <TableHead className="text-right">Ações</TableHead>
                 </TableRow>
               </TableHeader>
               <TableBody>
                   {orcamentos?.map((orc: any) => (
                   <TableRow key={orc.id}>
                     <TableCell className="font-medium">{orc.numero}</TableCell>
                     <TableCell className="hidden md:table-cell">{new Date(orc.dataEntrada).toLocaleDateString('pt-BR')}</TableCell>
                     <TableCell>
                       {orc.veiculoPlaca ? (
                         <div className="flex flex-col">
                           <span className="font-medium">{orc.veiculoPlaca}</span>
                           <span className="text-sm text-gray-500">{orc.veiculoModelo}{orc.veiculoAno ? ` (${orc.veiculoAno})` : ''}</span>
                         </div>
                       ) : (
                         <span className="text-gray-400">Não informado</span>
                       )}
                     </TableCell>
                     <TableCell className="hidden lg:table-cell">Cliente #{orc.clienteId}</TableCell>
                     <TableCell>{getStatusBadge(orc.status)}</TableCell>
                     <TableCell className="text-right">
                       <Link href={`/orcamentos/${orc.id}`}>
                         <Button variant="ghost" size="icon"><Eye className="h-4 w-4" /></Button>
                       </Link>
                       <Button variant="ghost" size="icon" onClick={() => handleDelete(orc.id)}>
                         <Trash2 className="h-4 w-4 text-red-600" />
                       </Button>
                     </TableCell>
                   </TableRow>
                 ))}
               </TableBody>
             </Table>
            }
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
