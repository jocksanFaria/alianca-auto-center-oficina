import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";
import { Upload, FileText, Loader2, Eye, Trash2, Plus } from "lucide-react";

export default function OrcamentosExternos() {
  const [pdfFile, setPdfFile] = useState<File | null>(null);
  const [pdfUrl, setPdfUrl] = useState<string>("");
  const [extracting, setExtracting] = useState(false);
  const [formData, setFormData] = useState({
    cliente: "",
    placa: "",
    modelo: "",
    valorTotal: "",
    observacoes: "",
  });
  const [showForm, setShowForm] = useState(false);

  const { data: orcamentos = [], refetch } = trpc.orcamentosExternos.getAll.useQuery();
  const uploadMutation = trpc.orcamentosExternos.uploadPDF.useMutation();
  const createMutation = trpc.orcamentosExternos.create.useMutation();

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.type !== "application/pdf") {
      toast.error("Apenas arquivos PDF são permitidos");
      return;
    }

    if (file.size > 10 * 1024 * 1024) {
      toast.error("Arquivo muito grande. Máximo: 10MB");
      return;
    }

    setPdfFile(file);
    setExtracting(true);

    try {
      // Converter para base64
      const reader = new FileReader();
      reader.onload = async (event) => {
        const base64 = event.target?.result as string;
        
        // Upload e extração
        const result = await uploadMutation.mutateAsync({
          fileName: file.name,
          fileData: base64,
        });

        setPdfUrl(result.pdfUrl);
        setFormData({
          cliente: result.extractedData.cliente,
          placa: result.extractedData.placa,
          modelo: result.extractedData.modelo,
          valorTotal: result.extractedData.valor.toFixed(2),
          observacoes: "",
        });
        setShowForm(true);
        toast.success("PDF processado com sucesso! Verifique os dados extraídos.");
      };
      reader.readAsDataURL(file);
    } catch (error) {
      console.error("Erro ao processar PDF:", error);
      toast.error("Erro ao processar PDF");
    } finally {
      setExtracting(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!pdfUrl) {
      toast.error("Faça upload de um PDF primeiro");
      return;
    }

    if (!formData.cliente || !formData.placa || !formData.modelo || !formData.valorTotal) {
      toast.error("Preencha todos os campos obrigatórios");
      return;
    }

    try {
      await createMutation.mutateAsync({
        cliente: formData.cliente,
        placa: formData.placa.toUpperCase(),
        modelo: formData.modelo,
        valor: parseFloat(formData.valorTotal.replace(",", ".")),
        pdfUrl,
        observacoes: formData.observacoes,
      });

      toast.success("Orçamento externo salvo e conta a receber criada!");
      
      // Reset
      setPdfFile(null);
      setPdfUrl("");
      setFormData({
        cliente: "",
        placa: "",
        modelo: "",
        valorTotal: "",
        observacoes: "",
      });
      setShowForm(false);
      refetch();
    } catch (error) {
      console.error("Erro ao salvar:", error);
      toast.error("Erro ao salvar orçamento");
    }
  };

  const handleCancel = () => {
    setPdfFile(null);
    setPdfUrl("");
    setFormData({
      cliente: "",
      placa: "",
      modelo: "",
      valorTotal: "",
      observacoes: "",
    });
    setShowForm(false);
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Orçamentos Externos</h1>
          <p className="text-gray-500 mt-1">Receba PDFs de seguradoras (Unida, Localiza, etc)</p>
        </div>
      </div>

      {/* Upload Section */}
      {!showForm && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Upload className="w-5 h-5" />
              Upload de PDF
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-12 text-center hover:border-blue-400 transition-colors">
              <input
                type="file"
                accept="application/pdf"
                onChange={handleFileChange}
                className="hidden"
                id="pdf-upload"
                disabled={extracting}
              />
              <label htmlFor="pdf-upload" className="cursor-pointer">
                {extracting ? (
                  <div className="flex flex-col items-center gap-3">
                    <Loader2 className="w-12 h-12 text-blue-500 animate-spin" />
                    <p className="text-lg font-medium text-gray-700">Processando PDF...</p>
                    <p className="text-sm text-gray-500">Extraindo dados automaticamente</p>
                  </div>
                ) : (
                  <div className="flex flex-col items-center gap-3">
                    <FileText className="w-12 h-12 text-gray-400" />
                    <p className="text-lg font-medium text-gray-700">
                      Clique para fazer upload do PDF
                    </p>
                    <p className="text-sm text-gray-500">
                      Máximo 10MB • A IA vai extrair os dados automaticamente
                    </p>
                  </div>
                )}
              </label>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Form Section */}
      {showForm && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Formulário */}
          <Card>
            <CardHeader>
              <CardTitle>Dados Extraídos do PDF</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="cliente">Cliente / Seguradora *</Label>
                  <Input
                    id="cliente"
                    value={formData.cliente}
                    onChange={(e) => setFormData({ ...formData, cliente: e.target.value })}
                    placeholder="Ex: Unida, Localiza"
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="placa">Placa *</Label>
                    <Input
                      id="placa"
                      value={formData.placa}
                      onChange={(e) => setFormData({ ...formData, placa: e.target.value.toUpperCase() })}
                      placeholder="ABC1234"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="modelo">Modelo *</Label>
                    <Input
                      id="modelo"
                      value={formData.modelo}
                      onChange={(e) => setFormData({ ...formData, modelo: e.target.value })}
                      placeholder="Ex: Gol 1.0"
                      required
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="valorTotal">Valor Total (R$) *</Label>
                  <Input
                    id="valorTotal"
                    type="number"
                    step="0.01"
                    value={formData.valorTotal}
                    onChange={(e) => setFormData({ ...formData, valorTotal: e.target.value })}
                    placeholder="0.00"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="observacoes">Observações</Label>
                  <Textarea
                    id="observacoes"
                    value={formData.observacoes}
                    onChange={(e) => setFormData({ ...formData, observacoes: e.target.value })}
                    placeholder="Observações adicionais..."
                    rows={3}
                  />
                </div>

                <div className="flex gap-3 pt-4">
                  <Button type="submit" className="flex-1" disabled={createMutation.isPending}>
                    {createMutation.isPending ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Salvando...
                      </>
                    ) : (
                      <>
                        <Plus className="w-4 h-4 mr-2" />
                        Salvar Orçamento
                      </>
                    )}
                  </Button>
                  <Button type="button" variant="outline" onClick={handleCancel}>
                    Cancelar
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>

          {/* Preview do PDF */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Eye className="w-5 h-5" />
                Preview do PDF
              </CardTitle>
            </CardHeader>
            <CardContent>
              {pdfUrl && (
                <iframe
                  src={pdfUrl}
                  className="w-full h-[600px] border rounded-lg"
                  title="PDF Preview"
                />
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {/* Lista de Orçamentos Externos */}
      <Card>
        <CardHeader>
          <CardTitle>Orçamentos Recebidos</CardTitle>
        </CardHeader>
        <CardContent>
          {orcamentos.length === 0 ? (
            <div className="text-center py-12 text-gray-500">
              <FileText className="w-12 h-12 mx-auto mb-3 text-gray-300" />
              <p>Nenhum orçamento externo cadastrado</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Data</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Cliente</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Placa</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Modelo</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Valor</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Status</th>
                    <th className="text-center py-3 px-4 font-semibold text-gray-700">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {orcamentos.map((orc) => (
                    <tr key={orc.id} className="border-b hover:bg-gray-50">
                      <td className="py-3 px-4">
                        {new Date(orc.dataRecebimento).toLocaleDateString("pt-BR")}
                      </td>
                      <td className="py-3 px-4 font-medium">{orc.cliente}</td>
                      <td className="py-3 px-4">{orc.placa}</td>
                      <td className="py-3 px-4">{orc.modelo}</td>
                      <td className="py-3 px-4 font-semibold text-green-600">
                        R$ {orc.valor.toFixed(2).replace(".", ",")}
                      </td>
                      <td className="py-3 px-4">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          orc.status === "pendente" 
                            ? "bg-yellow-100 text-yellow-800"
                            : orc.status === "aprovado"
                            ? "bg-green-100 text-green-800"
                            : "bg-gray-100 text-gray-800"
                        }`}>
                          {orc.status === "pendente" ? "Pendente" : orc.status === "aprovado" ? "Aprovado" : "Recusado"}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex items-center justify-center gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => orc.pdfUrl && window.open(orc.pdfUrl, "_blank")}
                          >
                            <Eye className="w-4 h-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
