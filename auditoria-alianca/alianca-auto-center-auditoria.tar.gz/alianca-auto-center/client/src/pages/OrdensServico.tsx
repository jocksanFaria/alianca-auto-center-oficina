import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { Plus, Eye, FileText, Search } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useMemo, useState } from "react";

export default function OrdensServico() {
  const [location] = useLocation();
  const [searchTerm, setSearchTerm] = useState("");
  
  const statusFilter = useMemo(() => {
    const params = new URLSearchParams(location.split('?')[1]);
    return params.get('status') || undefined;
  }, [location]);
  
  const { data: ordens, isLoading } = trpc.ordensServico.list.useQuery({ 
    status: statusFilter,
    search: searchTerm || undefined 
  });

  const getStatusBadge = (status: string) => {
    const config: Record<string, { variant: "default" | "secondary" | "destructive" | "outline", label: string }> = {
      aguardando: { variant: "secondary", label: "Aguardando" },
      em_execucao: { variant: "default", label: "Em Execução" },
      concluido: { variant: "outline", label: "Concluído" },
      entregue: { variant: "outline", label: "Entregue" },
    };
    const { variant, label } = config[status] || { variant: "default" as const, label: status };
    return <Badge variant={variant}>{label}</Badge>;
  };

  // Cards de resumo por status
  const stats = useMemo(() => {
    if (!ordens) return { aguardando: 0, em_execucao: 0, concluido: 0, entregue: 0 };
    return {
      aguardando: ordens.filter((os: any) => os.status === 'aguardando').length,
      em_execucao: ordens.filter((os: any) => os.status === 'em_execucao').length,
      concluido: ordens.filter((os: any) => os.status === 'concluido').length,
      entregue: ordens.filter((os: any) => os.status === 'entregue').length,
    };
  }, [ordens]);

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Ordens de Serviço</h1>
            <p className="text-gray-600 mt-1">Gerencie as ordens de serviço da oficina</p>
          </div>
          <Link href="/ordens-servico/nova">
            <Button><Plus className="h-4 w-4 mr-2" />Nova OS</Button>
          </Link>
        </div>

        {/* Cards de Resumo */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => window.location.href = '/ordens-servico?status=aguardando'}>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Aguardando</CardTitle>
              <FileText className="h-5 w-5 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-blue-600">{stats.aguardando}</div>
            </CardContent>
          </Card>

          <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => window.location.href = '/ordens-servico?status=em_execucao'}>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Em Execução</CardTitle>
              <FileText className="h-5 w-5 text-orange-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-orange-600">{stats.em_execucao}</div>
            </CardContent>
          </Card>

          <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => window.location.href = '/ordens-servico?status=concluido'}>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Concluído</CardTitle>
              <FileText className="h-5 w-5 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-600">{stats.concluido}</div>
            </CardContent>
          </Card>

          <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => window.location.href = '/ordens-servico?status=entregue'}>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Entregue</CardTitle>
              <FileText className="h-5 w-5 text-gray-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-gray-600">{stats.entregue}</div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Lista de Ordens de Serviço</CardTitle>
              <div className="relative w-64">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Buscar por número..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value.toUpperCase())}
                  className="pl-10"
                />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? <p className="text-center py-8">Carregando...</p> :
             !ordens?.length ? <p className="text-center py-8">Nenhuma ordem de serviço cadastrada</p> :
             <Table>
               <TableHeader>
                 <TableRow>
                   <TableHead>Número</TableHead>
                   <TableHead>Data Entrada</TableHead>
                   <TableHead>Cliente</TableHead>
                   <TableHead>Veículo</TableHead>
                   <TableHead>Status</TableHead>
                   <TableHead className="text-right">Ações</TableHead>
                 </TableRow>
               </TableHeader>
               <TableBody>
                 {ordens.map((os: any) => (
                   <TableRow key={os.id}>
                     <TableCell className="font-medium">{os.numero}</TableCell>
                     <TableCell>{new Date(os.dataEntrada).toLocaleDateString('pt-BR')}</TableCell>
                     <TableCell>Cliente #{os.clienteId}</TableCell>
                     <TableCell>Veículo #{os.veiculoId}</TableCell>
                     <TableCell>{getStatusBadge(os.status)}</TableCell>
                     <TableCell className="text-right">
                       <Link href={`/ordens-servico/${os.id}`}>
                         <Button variant="ghost" size="icon"><Eye className="h-4 w-4" /></Button>
                       </Link>
                     </TableCell>
                   </TableRow>
                 ))}
               </TableBody>
             </Table>
            }
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
