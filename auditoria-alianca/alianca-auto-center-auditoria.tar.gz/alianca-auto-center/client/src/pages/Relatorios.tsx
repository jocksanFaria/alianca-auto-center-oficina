import Layout from "@/components/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { trpc } from "@/lib/trpc";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line, Area, AreaChart } from 'recharts';
import { TrendingUp, TrendingDown, Users, DollarSign, AlertCircle, CheckCircle } from "lucide-react";

export default function Relatorios() {
  const { data: faturamento, isLoading: loadingFaturamento } = trpc.relatorios.faturamento.useQuery();
  const { data: funil, isLoading: loadingFunil } = trpc.relatorios.funil.useQuery();
  const { data: clientes, isLoading: loadingClientes } = trpc.relatorios.clientes.useQuery();
  const { data: fluxoCaixa, isLoading: loadingFluxo } = trpc.relatorios.fluxoCaixa.useQuery();

  // Cores para gráficos
  const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];

  // Formatar dados de faturamento para o gráfico
  const dadosFaturamento = faturamento?.map((item: any) => ({
    mes: new Date(item.mes + '-01').toLocaleDateString('pt-BR', { month: 'short', year: '2-digit' }),
    valor: item.total / 100,
    quantidade: item.quantidade,
  })) || [];

  // Dados do funil
  const dadosFunil = funil ? [
    { nome: 'Criados', valor: funil.total, cor: '#3b82f6' },
    { nome: 'Pendentes', valor: funil.pendentes, cor: '#f59e0b' },
    { nome: 'Aprovados', valor: funil.aprovados, cor: '#10b981' },
    { nome: 'Concluídos', valor: funil.concluidos, cor: '#8b5cf6' },
    { nome: 'Rejeitados', valor: funil.rejeitados, cor: '#ef4444' },
  ] : [];

  // Dados do fluxo de caixa
  const dadosFluxo = fluxoCaixa?.entradasPorDia?.map((entrada: any) => {
    const saida = fluxoCaixa.saidasPorDia?.find((s: any) => s.data === entrada.data);
    return {
      data: new Date(entrada.data).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' }),
      entradas: entrada.total / 100,
      saidas: saida ? saida.total / 100 : 0,
    };
  }) || [];

  return (
    <Layout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Relatórios Financeiros</h1>
          <p className="text-gray-600 mt-1">Análise completa do desempenho financeiro</p>
        </div>

        <Tabs defaultValue="faturamento">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="faturamento">Faturamento</TabsTrigger>
            <TabsTrigger value="funil">Funil de Vendas</TabsTrigger>
            <TabsTrigger value="clientes">Clientes</TabsTrigger>
            <TabsTrigger value="fluxo">Fluxo de Caixa</TabsTrigger>
          </TabsList>

          {/* TAB: FATURAMENTO */}
          <TabsContent value="faturamento" className="space-y-4">
            {loadingFaturamento ? (
              <p className="text-center py-8">Carregando...</p>
            ) : (
              <>
                {/* Cards de Resumo */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium text-gray-600">Faturamento Total</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-2xl font-bold text-blue-600">
                        R$ {dadosFaturamento.reduce((sum: number, item: any) => sum + item.valor, 0).toLocaleString('pt-BR', {minimumFractionDigits: 2})}
                      </p>
                      <p className="text-xs text-gray-500 mt-1">Últimos 12 meses</p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium text-gray-600">Ticket Médio</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-2xl font-bold text-green-600">
                        R$ {dadosFaturamento.length > 0 
                          ? (dadosFaturamento.reduce((sum: number, item: any) => sum + item.valor, 0) / dadosFaturamento.reduce((sum: number, item: any) => sum + item.quantidade, 0)).toLocaleString('pt-BR', {minimumFractionDigits: 2})
                          : '0,00'}
                      </p>
                      <p className="text-xs text-gray-500 mt-1">Por orçamento</p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium text-gray-600">Total de Orçamentos</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-2xl font-bold text-purple-600">
                        {dadosFaturamento.reduce((sum: number, item: any) => sum + item.quantidade, 0)}
                      </p>
                      <p className="text-xs text-gray-500 mt-1">Concluídos</p>
                    </CardContent>
                  </Card>
                </div>

                {/* Gráfico de Faturamento */}
                <Card>
                  <CardHeader>
                    <CardTitle>Faturamento Mensal</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={400}>
                      <BarChart data={dadosFaturamento}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="mes" />
                        <YAxis />
                        <Tooltip 
                          formatter={(value: number) => `R$ ${value.toLocaleString('pt-BR', {minimumFractionDigits: 2})}`}
                        />
                        <Legend />
                        <Bar dataKey="valor" fill="#3b82f6" name="Faturamento (R$)" />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </>
            )}
          </TabsContent>

          {/* TAB: FUNIL DE VENDAS */}
          <TabsContent value="funil" className="space-y-4">
            {loadingFunil ? (
              <p className="text-center py-8">Carregando...</p>
            ) : (
              <>
                {/* Cards de Métricas */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium text-gray-600">Taxa de Conversão</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-2xl font-bold text-green-600">
                        {funil?.taxaConversao.toFixed(1)}%
                      </p>
                      <p className="text-xs text-gray-500 mt-1">Aprovados + Concluídos</p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium text-gray-600">Orçamentos Criados</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-2xl font-bold text-blue-600">{funil?.total}</p>
                      <p className="text-xs text-gray-500 mt-1">Total</p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium text-gray-600">Valor Aprovado</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-2xl font-bold text-green-600">
                        R$ {((funil?.valorAprovado || 0) / 100).toLocaleString('pt-BR', {minimumFractionDigits: 2})}
                      </p>
                      <p className="text-xs text-gray-500 mt-1">Em orçamentos aprovados</p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium text-gray-600">Valor Concluído</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-2xl font-bold text-purple-600">
                        R$ {((funil?.valorConcluido || 0) / 100).toLocaleString('pt-BR', {minimumFractionDigits: 2})}
                      </p>
                      <p className="text-xs text-gray-500 mt-1">Faturado</p>
                    </CardContent>
                  </Card>
                </div>

                {/* Gráfico de Pizza */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card>
                    <CardHeader>
                      <CardTitle>Distribuição de Orçamentos</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ResponsiveContainer width="100%" height={300}>
                        <PieChart>
                          <Pie
                            data={dadosFunil}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            label={(entry) => `${entry.nome}: ${entry.valor}`}
                            outerRadius={80}
                            fill="#8884d8"
                            dataKey="valor"
                          >
                            {dadosFunil.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={entry.cor} />
                            ))}
                          </Pie>
                          <Tooltip />
                        </PieChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>Detalhamento</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {dadosFunil.map((item) => (
                          <div key={item.nome} className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <div className="w-4 h-4 rounded" style={{ backgroundColor: item.cor }}></div>
                              <span className="font-medium">{item.nome}</span>
                            </div>
                            <span className="text-gray-600">{item.valor} orçamentos</span>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </>
            )}
          </TabsContent>

          {/* TAB: CLIENTES */}
          <TabsContent value="clientes" className="space-y-4">
            {loadingClientes ? (
              <p className="text-center py-8">Carregando...</p>
            ) : (
              <>
                {/* Cards de Resumo */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium text-gray-600">Clientes com Pendências</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-2xl font-bold text-yellow-600">
                        {clientes?.totalClientesPendentes || 0}
                      </p>
                      <p className="text-xs text-gray-500 mt-1">Com contas a receber</p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium text-gray-600">Total Pendente</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-2xl font-bold text-red-600">
                        R$ {((clientes?.totalValorPendente || 0) / 100).toLocaleString('pt-BR', {minimumFractionDigits: 2})}
                      </p>
                      <p className="text-xs text-gray-500 mt-1">A receber</p>
                    </CardContent>
                  </Card>
                </div>

                {/* Ranking de Clientes */}
                <Card>
                  <CardHeader>
                    <CardTitle>Top 10 Clientes por Valor</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {clientes?.ranking?.map((cliente: any, index: number) => (
                        <div key={cliente.clienteId} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold">
                              {index + 1}
                            </div>
                            <div>
                              <p className="font-medium">{cliente.clienteNome}</p>
                              <p className="text-sm text-gray-500">{cliente.totalOrcamentos} orçamentos</p>
                            </div>
                          </div>
                          <p className="text-lg font-bold text-green-600">
                            R$ {((cliente.valorTotal || 0) / 100).toLocaleString('pt-BR', {minimumFractionDigits: 2})}
                          </p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Clientes Inadimplentes */}
                {clientes?.inadimplentes && clientes.inadimplentes.length > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2 text-red-600">
                        <AlertCircle className="h-5 w-5" />
                        Clientes Inadimplentes
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {clientes.inadimplentes.map((cliente: any) => (
                          <div key={cliente.clienteId} className="flex items-center justify-between p-3 bg-red-50 rounded-lg border border-red-200">
                            <div>
                              <p className="font-medium">{cliente.clienteNome}</p>
                              <p className="text-sm text-gray-500">{cliente.quantidadeContas} contas vencidas</p>
                            </div>
                            <p className="text-lg font-bold text-red-600">
                              R$ {(cliente.totalVencido / 100).toLocaleString('pt-BR', {minimumFractionDigits: 2})}
                            </p>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}
              </>
            )}
          </TabsContent>

          {/* TAB: FLUXO DE CAIXA */}
          <TabsContent value="fluxo" className="space-y-4">
            {loadingFluxo ? (
              <p className="text-center py-8">Carregando...</p>
            ) : (
              <>
                {/* Cards de Resumo */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                        <TrendingUp className="h-4 w-4" />
                        Entradas
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-2xl font-bold text-green-600">
                        R$ {((fluxoCaixa?.totalEntradas || 0) / 100).toLocaleString('pt-BR', {minimumFractionDigits: 2})}
                      </p>
                      <p className="text-xs text-gray-500 mt-1">{fluxoCaixa?.quantidadeEntradas || 0} contas recebidas</p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                        <TrendingDown className="h-4 w-4" />
                        Saídas
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-2xl font-bold text-red-600">
                        R$ {((fluxoCaixa?.totalSaidas || 0) / 100).toLocaleString('pt-BR', {minimumFractionDigits: 2})}
                      </p>
                      <p className="text-xs text-gray-500 mt-1">{fluxoCaixa?.quantidadeSaidas || 0} contas pagas</p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                        <DollarSign className="h-4 w-4" />
                        Saldo do Período
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className={`text-2xl font-bold ${(fluxoCaixa?.saldo || 0) >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        R$ {((fluxoCaixa?.saldo || 0) / 100).toLocaleString('pt-BR', {minimumFractionDigits: 2})}
                      </p>
                      <p className="text-xs text-gray-500 mt-1">Entradas - Saídas</p>
                    </CardContent>
                  </Card>
                </div>

                {/* Gráfico de Fluxo de Caixa */}
                <Card>
                  <CardHeader>
                    <CardTitle>Fluxo de Caixa Diário</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={400}>
                      <AreaChart data={dadosFluxo}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="data" />
                        <YAxis />
                        <Tooltip 
                          formatter={(value: number) => `R$ ${value.toLocaleString('pt-BR', {minimumFractionDigits: 2})}`}
                        />
                        <Legend />
                        <Area type="monotone" dataKey="entradas" stackId="1" stroke="#10b981" fill="#10b981" name="Entradas (R$)" />
                        <Area type="monotone" dataKey="saidas" stackId="2" stroke="#ef4444" fill="#ef4444" name="Saídas (R$)" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}
