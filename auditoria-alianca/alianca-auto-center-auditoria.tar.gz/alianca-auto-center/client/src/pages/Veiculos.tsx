import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { trpc } from "@/lib/trpc";
import { Plus, Pencil, Trash2, Car } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

type VeiculoStatus = "aguardando_orcamento" | "orcamento_pendente" | "aprovado" | "em_execucao" | "finalizado" | "entregue";

const statusConfig: Record<VeiculoStatus, { label: string; color: string; icon: string }> = {
  aguardando_orcamento: { label: "Aguardando Orçamento", color: "bg-blue-500", icon: "🔵" },
  orcamento_pendente: { label: "Orçamento Pendente", color: "bg-yellow-500", icon: "🟡" },
  aprovado: { label: "Aprovado", color: "bg-orange-500", icon: "🟠" },
  em_execucao: { label: "Em Execução", color: "bg-purple-500", icon: "🔧" },
  finalizado: { label: "Finalizado", color: "bg-green-500", icon: "✅" },
  entregue: { label: "Entregue", color: "bg-gray-500", icon: "🚗" },
};

export default function Veiculos() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [statusDialogOpen, setStatusDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [selectedVeiculo, setSelectedVeiculo] = useState<any>(null);
  const [newStatus, setNewStatus] = useState<VeiculoStatus>("aguardando_orcamento");
  const [formData, setFormData] = useState({
    clienteId: "", placa: "", modelo: "", ano: ""
  });
  const [activeTab, setActiveTab] = useState<VeiculoStatus | "todos">("todos");

  const { data: veiculos, isLoading, refetch } = trpc.veiculos.list.useQuery();
  const { data: clientes } = trpc.clientes.list.useQuery();
  const createMutation = trpc.veiculos.create.useMutation();
  const updateMutation = trpc.veiculos.update.useMutation();
  const deleteMutation = trpc.veiculos.delete.useMutation();
  const updateStatusMutation = trpc.veiculos.updateStatus.useMutation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const data = { 
        clienteId: parseInt(formData.clienteId),
        placa: formData.placa,
        modelo: formData.modelo,
        ano: formData.ano ? parseInt(formData.ano) : undefined,
      };
      if (editingId) {
        await updateMutation.mutateAsync({ id: editingId, ...data });
        toast.success("Veículo atualizado!");
      } else {
        await createMutation.mutateAsync(data);
        toast.success("Veículo criado!");
      }
      setDialogOpen(false);
      resetForm();
      refetch();
    } catch (error) {
      toast.error("Erro ao salvar veículo");
    }
  };

  const handleEdit = (v: any) => {
    setEditingId(v.id);
    setFormData({
      clienteId: v.clienteId.toString(), 
      placa: v.placa || "", 
      modelo: v.modelo || "",
      ano: v.ano ? v.ano.toString() : ""
    });
    setDialogOpen(true);
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Excluir este veículo?")) return;
    try {
      await deleteMutation.mutateAsync({ id });
      toast.success("Veículo excluído!");
      refetch();
    } catch (error) {
      toast.error("Erro ao excluir");
    }
  };

  const handleChangeStatus = (veiculo: any) => {
    setSelectedVeiculo(veiculo);
    setNewStatus(veiculo.status);
    setStatusDialogOpen(true);
  };

  const handleUpdateStatus = async () => {
    if (!selectedVeiculo) return;
    try {
      await updateStatusMutation.mutateAsync({ 
        id: selectedVeiculo.id, 
        status: newStatus 
      });
      toast.success("Status atualizado!");
      setStatusDialogOpen(false);
      refetch();
    } catch (error) {
      toast.error("Erro ao atualizar status");
    }
  };

  const resetForm = () => {
    setEditingId(null);
    setFormData({ clienteId: "", placa: "", modelo: "", ano: "" });
  };

  const getClienteNome = (clienteId: number) => {
    return clientes?.find(c => c.id === clienteId)?.nome || "Cliente não encontrado";
  };

  const filteredVeiculos = activeTab === "todos" 
    ? veiculos 
    : veiculos?.filter(v => v.status === activeTab);

  const countByStatus = (status: VeiculoStatus) => {
    return veiculos?.filter(v => v.status === status).length || 0;
  };

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Veículos</h1>
            <p className="text-gray-600 mt-1">Acompanhamento de veículos na oficina</p>
          </div>
          <Button onClick={() => { resetForm(); setDialogOpen(true); }}>
            <Plus className="h-4 w-4 mr-2" />Novo Veículo
          </Button>
        </div>

        {/* Cards de Status */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {Object.entries(statusConfig).map(([status, config]) => (
            <Card key={status} className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => setActiveTab(status as VeiculoStatus)}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-2xl font-bold">{countByStatus(status as VeiculoStatus)}</p>
                    <p className="text-xs text-gray-600 mt-1">{config.label}</p>
                  </div>
                  <div className={`w-12 h-12 rounded-full ${config.color} flex items-center justify-center text-2xl`}>
                    {config.icon}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Tabela de Veículos */}
        <Card>
          <CardHeader>
            <CardTitle>
              <div className="flex items-center justify-between">
                <span>Lista de Veículos</span>
                <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as any)}>
                  <TabsList>
                    <TabsTrigger value="todos">Todos ({veiculos?.length || 0})</TabsTrigger>
                    <TabsTrigger value="aguardando_orcamento">Aguardando</TabsTrigger>
                    <TabsTrigger value="em_execucao">Em Execução</TabsTrigger>
                    <TabsTrigger value="finalizado">Finalizados</TabsTrigger>
                  </TabsList>
                </Tabs>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? <p className="text-center py-8">Carregando...</p> :
             !filteredVeiculos?.length ? <p className="text-center py-8">Nenhum veículo encontrado</p> :
             <Table>
               <TableHeader>
                 <TableRow>
                   <TableHead>Placa</TableHead>
                   <TableHead>Cliente</TableHead>
                   <TableHead>Modelo</TableHead>
                   <TableHead className="hidden md:table-cell">Ano</TableHead>
                   <TableHead>Status</TableHead>
                   <TableHead className="text-right">Ações</TableHead>
                 </TableRow>
               </TableHeader>
               <TableBody>
                 {filteredVeiculos.map((v) => (
                   <TableRow key={v.id}>
                     <TableCell className="font-medium">{v.placa}</TableCell>
                     <TableCell>{getClienteNome(v.clienteId)}</TableCell>
                     <TableCell>{v.modelo}</TableCell>
                     <TableCell className="hidden md:table-cell">{v.ano || "-"}</TableCell>
                     <TableCell>
                       <Badge 
                         className={`${statusConfig[v.status as VeiculoStatus].color} text-white cursor-pointer`}
                         onClick={() => handleChangeStatus(v)}
                       >
                         {statusConfig[v.status as VeiculoStatus].icon} {statusConfig[v.status as VeiculoStatus].label}
                       </Badge>
                     </TableCell>
                     <TableCell className="text-right">
                       <Button variant="ghost" size="icon" onClick={() => handleEdit(v)}>
                         <Pencil className="h-4 w-4" />
                       </Button>
                       <Button variant="ghost" size="icon" onClick={() => handleDelete(v.id)}>
                         <Trash2 className="h-4 w-4 text-red-600" />
                       </Button>
                     </TableCell>
                   </TableRow>
                 ))}
               </TableBody>
             </Table>
            }
          </CardContent>
        </Card>
      </div>

      {/* Dialog de Criar/Editar Veículo */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{editingId ? "Editar" : "Novo"} Veículo</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="md:col-span-2">
                <Label>Cliente *</Label>
                <Select value={formData.clienteId} onValueChange={(value) => setFormData({...formData, clienteId: value})} required>
                  <SelectTrigger><SelectValue placeholder="Selecione o cliente" /></SelectTrigger>
                  <SelectContent>
                    {clientes?.map((c) => (
                      <SelectItem key={c.id} value={c.id.toString()}>{c.nome}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Placa *</Label>
                <Input 
                  value={formData.placa} 
                  onChange={(e) => setFormData({...formData, placa: e.target.value.toUpperCase()})} 
                  placeholder="ABC-1234"
                  required 
                />
              </div>
              <div>
                <Label>Ano</Label>
                <Input 
                  type="number"
                  value={formData.ano} 
                  onChange={(e) => setFormData({...formData, ano: e.target.value})} 
                  placeholder="2024"
                />
              </div>
              <div className="md:col-span-2">
                <Label>Modelo *</Label>
                <Input 
                  value={formData.modelo} 
                  onChange={(e) => setFormData({...formData, modelo: e.target.value})} 
                  placeholder="Ex: Gol 1.0"
                  required 
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>Cancelar</Button>
              <Button type="submit">{editingId ? "Atualizar" : "Criar"}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Dialog de Mudança de Status */}
      <Dialog open={statusDialogOpen} onOpenChange={setStatusDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Alterar Status do Veículo</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <p className="text-sm text-gray-600 mb-2">
                <strong>Veículo:</strong> {selectedVeiculo?.placa} - {selectedVeiculo?.modelo}
              </p>
              <p className="text-sm text-gray-600 mb-4">
                <strong>Cliente:</strong> {selectedVeiculo && getClienteNome(selectedVeiculo.clienteId)}
              </p>
            </div>
            <div>
              <Label>Novo Status</Label>
              <Select value={newStatus} onValueChange={(value) => setNewStatus(value as VeiculoStatus)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.entries(statusConfig).map(([status, config]) => (
                    <SelectItem key={status} value={status}>
                      {config.icon} {config.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setStatusDialogOpen(false)}>Cancelar</Button>
            <Button onClick={handleUpdateStatus}>Atualizar Status</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Layout>
  );
}
