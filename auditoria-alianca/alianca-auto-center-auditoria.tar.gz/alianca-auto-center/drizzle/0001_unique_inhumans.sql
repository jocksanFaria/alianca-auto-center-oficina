CREATE TABLE `clientes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`nome` varchar(255) NOT NULL,
	`cpfCnpj` varchar(18),
	`telefone` varchar(20),
	`email` varchar(320),
	`endereco` text,
	`cidade` varchar(100),
	`estado` varchar(2),
	`cep` varchar(9),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `clientes_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `complementosOrcamento` (
	`id` int AUTO_INCREMENT NOT NULL,
	`orcamentoId` int NOT NULL,
	`descricao` text NOT NULL,
	`valor` int NOT NULL DEFAULT 0,
	`data` timestamp NOT NULL,
	`responsavel` varchar(255),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `complementosOrcamento_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `itensOrcamento` (
	`id` int AUTO_INCREMENT NOT NULL,
	`orcamentoId` int NOT NULL,
	`categoria` enum('pecas','pintura','funilaria','outros') NOT NULL,
	`descricao` text NOT NULL,
	`quantidade` int NOT NULL DEFAULT 1,
	`valorUnitario` int NOT NULL DEFAULT 0,
	`valorTotal` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `itensOrcamento_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `notasFiscais` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ordemServicoId` int NOT NULL,
	`numero` varchar(50) NOT NULL,
	`valor` int NOT NULL DEFAULT 0,
	`dataEmissao` timestamp NOT NULL,
	`dataVencimento` timestamp NOT NULL,
	`dataPagamento` timestamp,
	`status` enum('a_vencer','vencido','pago') NOT NULL DEFAULT 'a_vencer',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `notasFiscais_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `orcamentos` (
	`id` int AUTO_INCREMENT NOT NULL,
	`numero` varchar(50) NOT NULL,
	`clienteId` int NOT NULL,
	`veiculoId` int NOT NULL,
	`dataEntrada` timestamp NOT NULL,
	`prazoEntrega` timestamp,
	`numeroOS` varchar(50),
	`status` enum('pendente','aprovado','rejeitado','em_execucao','concluido') NOT NULL DEFAULT 'pendente',
	`observacoes` text,
	`desconto` int NOT NULL DEFAULT 0,
	`acrescimo` int NOT NULL DEFAULT 0,
	`subtotalItens` int NOT NULL DEFAULT 0,
	`subtotalComplementos` int NOT NULL DEFAULT 0,
	`total` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `orcamentos_id` PRIMARY KEY(`id`),
	CONSTRAINT `orcamentos_numero_unique` UNIQUE(`numero`)
);
--> statement-breakpoint
CREATE TABLE `ordensServico` (
	`id` int AUTO_INCREMENT NOT NULL,
	`numero` varchar(50) NOT NULL,
	`numeroOSCliente` varchar(50),
	`clienteId` int NOT NULL,
	`veiculoId` int NOT NULL,
	`descricaoServicos` text NOT NULL,
	`valorTotal` int NOT NULL DEFAULT 0,
	`nivelCombustivel` enum('vazio','1/4','1/2','3/4','cheio') DEFAULT 'vazio',
	`quilometragem` int DEFAULT 0,
	`observacoes` text,
	`status` enum('aguardando','em_execucao','concluido') NOT NULL DEFAULT 'aguardando',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `ordensServico_id` PRIMARY KEY(`id`),
	CONSTRAINT `ordensServico_numero_unique` UNIQUE(`numero`)
);
--> statement-breakpoint
CREATE TABLE `veiculos` (
	`id` int AUTO_INCREMENT NOT NULL,
	`clienteId` int NOT NULL,
	`placa` varchar(10) NOT NULL,
	`marca` varchar(100),
	`modelo` varchar(100) NOT NULL,
	`ano` int,
	`cor` varchar(50),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `veiculos_id` PRIMARY KEY(`id`)
);
