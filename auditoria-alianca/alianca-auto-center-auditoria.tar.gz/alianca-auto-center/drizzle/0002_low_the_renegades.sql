CREATE TABLE `agendamentos` (
	`id` int AUTO_INCREMENT NOT NULL,
	`clienteId` int NOT NULL,
	`veiculoId` int,
	`dataHora` timestamp NOT NULL,
	`duracao` int NOT NULL DEFAULT 60,
	`servico` text NOT NULL,
	`status` enum('agendado','confirmado','em_atendimento','concluido','cancelado') NOT NULL DEFAULT 'agendado',
	`observacoes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `agendamentos_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `contasPagar` (
	`id` int AUTO_INCREMENT NOT NULL,
	`descricao` text NOT NULL,
	`fornecedorId` int,
	`valor` int NOT NULL DEFAULT 0,
	`dataEmissao` timestamp NOT NULL,
	`dataVencimento` timestamp NOT NULL,
	`dataPagamento` timestamp,
	`status` enum('pendente','pago','vencido','cancelado') NOT NULL DEFAULT 'pendente',
	`categoria` varchar(50),
	`formaPagamento` varchar(50),
	`observacoes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `contasPagar_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `contasReceber` (
	`id` int AUTO_INCREMENT NOT NULL,
	`descricao` text NOT NULL,
	`clienteId` int,
	`ordemServicoId` int,
	`valor` int NOT NULL DEFAULT 0,
	`dataEmissao` timestamp NOT NULL,
	`dataVencimento` timestamp NOT NULL,
	`dataRecebimento` timestamp,
	`status` enum('pendente','recebido','vencido','cancelado') NOT NULL DEFAULT 'pendente',
	`categoria` varchar(50),
	`formaPagamento` varchar(50),
	`observacoes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `contasReceber_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `fornecedores` (
	`id` int AUTO_INCREMENT NOT NULL,
	`nome` varchar(255) NOT NULL,
	`cnpj` varchar(18),
	`telefone` varchar(20),
	`email` varchar(320),
	`endereco` text,
	`cidade` varchar(100),
	`estado` varchar(2),
	`cep` varchar(9),
	`ativo` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `fornecedores_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `itensPedidoCompra` (
	`id` int AUTO_INCREMENT NOT NULL,
	`pedidoCompraId` int NOT NULL,
	`produtoId` int NOT NULL,
	`quantidade` int NOT NULL,
	`quantidadeRecebida` int NOT NULL DEFAULT 0,
	`valorUnitario` int NOT NULL DEFAULT 0,
	`valorTotal` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `itensPedidoCompra_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `movimentacoesEstoque` (
	`id` int AUTO_INCREMENT NOT NULL,
	`produtoId` int NOT NULL,
	`tipo` enum('entrada','saida','ajuste') NOT NULL,
	`quantidade` int NOT NULL,
	`valorUnitario` int NOT NULL DEFAULT 0,
	`motivo` text,
	`documento` varchar(50),
	`usuarioId` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `movimentacoesEstoque_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `pedidosCompra` (
	`id` int AUTO_INCREMENT NOT NULL,
	`numero` varchar(50) NOT NULL,
	`fornecedorId` int NOT NULL,
	`dataEmissao` timestamp NOT NULL,
	`dataPrevisao` timestamp,
	`dataRecebimento` timestamp,
	`status` enum('pendente','parcial','recebido','cancelado') NOT NULL DEFAULT 'pendente',
	`valorTotal` int NOT NULL DEFAULT 0,
	`observacoes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `pedidosCompra_id` PRIMARY KEY(`id`),
	CONSTRAINT `pedidosCompra_numero_unique` UNIQUE(`numero`)
);
--> statement-breakpoint
CREATE TABLE `produtos` (
	`id` int AUTO_INCREMENT NOT NULL,
	`codigo` varchar(50) NOT NULL,
	`descricao` text NOT NULL,
	`categoria` enum('peca','pintura','funilaria','outros') NOT NULL,
	`unidade` varchar(10) NOT NULL DEFAULT 'UN',
	`estoqueAtual` int NOT NULL DEFAULT 0,
	`estoqueMinimo` int NOT NULL DEFAULT 0,
	`valorCusto` int NOT NULL DEFAULT 0,
	`valorVenda` int NOT NULL DEFAULT 0,
	`ativo` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `produtos_id` PRIMARY KEY(`id`),
	CONSTRAINT `produtos_codigo_unique` UNIQUE(`codigo`)
);
