ALTER TABLE `users` ADD `username` varchar(50);--> statement-breakpoint
ALTER TABLE `users` ADD `passwordHash` varchar(255);--> statement-breakpoint
ALTER TABLE `users` ADD `nivelAcesso` enum('admin','gerente','atendente','mecanico','financeiro','personalizado') DEFAULT 'atendente';--> statement-breakpoint
ALTER TABLE `users` ADD `permissoes` text;--> statement-breakpoint
ALTER TABLE `users` ADD `ativo` boolean DEFAULT true NOT NULL;