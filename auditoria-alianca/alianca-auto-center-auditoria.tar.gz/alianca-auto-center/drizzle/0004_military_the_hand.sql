CREATE TABLE `emailsEnviados` (
	`id` int AUTO_INCREMENT NOT NULL,
	`orcamentoId` int,
	`ordemServicoId` int,
	`destinatario` varchar(320) NOT NULL,
	`assunto` varchar(255) NOT NULL,
	`corpo` text,
	`anexos` text,
	`status` enum('enviado','erro','pendente') NOT NULL DEFAULT 'pendente',
	`erroMensagem` text,
	`enviadoPor` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `emailsEnviados_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `midiasOrcamento` (
	`id` int AUTO_INCREMENT NOT NULL,
	`orcamentoId` int NOT NULL,
	`tipo` enum('foto','video') NOT NULL,
	`url` text NOT NULL,
	`fileKey` varchar(255) NOT NULL,
	`fileName` varchar(255),
	`fileSize` int,
	`mimeType` varchar(100),
	`descricao` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `midiasOrcamento_id` PRIMARY KEY(`id`)
);
