ALTER TABLE `ordensServico` MODIFY COLUMN `status` enum('aguardando','em_execucao','concluido','entregue') NOT NULL DEFAULT 'aguardando';--> statement-breakpoint
ALTER TABLE `ordensServico` ADD `orcamentoId` int;--> statement-breakpoint
ALTER TABLE `ordensServico` ADD `checklistEntrada` text;--> statement-breakpoint
ALTER TABLE `ordensServico` ADD `observacoesEntrada` text;--> statement-breakpoint
ALTER TABLE `ordensServico` ADD `fotosEntrada` text;--> statement-breakpoint
ALTER TABLE `ordensServico` ADD `checklistSaida` text;--> statement-breakpoint
ALTER TABLE `ordensServico` ADD `observacoesSaida` text;--> statement-breakpoint
ALTER TABLE `ordensServico` ADD `fotosSaida` text;--> statement-breakpoint
ALTER TABLE `ordensServico` ADD `dataEntrada` timestamp NOT NULL;--> statement-breakpoint
ALTER TABLE `ordensServico` ADD `dataPrevista` timestamp;--> statement-breakpoint
ALTER TABLE `ordensServico` ADD `dataConclusao` timestamp;--> statement-breakpoint
ALTER TABLE `ordensServico` ADD `dataSaida` timestamp;