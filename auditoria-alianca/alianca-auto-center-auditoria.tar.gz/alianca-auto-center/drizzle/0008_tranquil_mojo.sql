CREATE TABLE `colaboradores` (
	`id` int AUTO_INCREMENT NOT NULL,
	`nome` varchar(255) NOT NULL,
	`cargo` varchar(100),
	`salario` int NOT NULL,
	`tipoPagamento` enum('semanal','quinzenal','mensal') NOT NULL,
	`diaPagamento` int NOT NULL,
	`dataAdmissao` timestamp NOT NULL,
	`status` enum('ativo','inativo') NOT NULL DEFAULT 'ativo',
	`observacoes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `colaboradores_id` PRIMARY KEY(`id`)
);
