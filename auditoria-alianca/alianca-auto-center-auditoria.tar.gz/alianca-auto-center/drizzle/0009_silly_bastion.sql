CREATE TABLE `adiantamentos` (
	`id` int AUTO_INCREMENT NOT NULL,
	`colaboradorId` int NOT NULL,
	`valor` int NOT NULL,
	`dataAdiantamento` timestamp NOT NULL,
	`descricao` text,
	`descontado` boolean NOT NULL DEFAULT false,
	`contaPagarId` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `adiantamentos_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `contasPagar` ADD `colaboradorId` int;