CREATE TABLE `orcamentos_externos` (
	`id` int AUTO_INCREMENT NOT NULL,
	`cliente` varchar(255) NOT NULL,
	`placa` varchar(20) NOT NULL,
	`modelo` varchar(255) NOT NULL,
	`pdf_url` text NOT NULL,
	`pdf_key` varchar(500) NOT NULL,
	`data_recebimento` timestamp NOT NULL DEFAULT (now()),
	`status` enum('pendente','em_analise','aprovado','rejeitado') NOT NULL DEFAULT 'pendente',
	`observacoes` text,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `orcamentos_externos_id` PRIMARY KEY(`id`)
);
