ALTER TABLE `orcamentos_externos` MODIFY COLUMN `pdf_url` text;--> statement-breakpoint
ALTER TABLE `orcamentos_externos` MODIFY COLUMN `pdf_key` varchar(500);--> statement-breakpoint
ALTER TABLE `orcamentos_externos` ADD `valor` int NOT NULL;