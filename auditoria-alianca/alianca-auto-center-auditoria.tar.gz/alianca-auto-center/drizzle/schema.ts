import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean, decimal } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  // Campos para login local
  username: varchar("username", { length: 50 }),
  passwordHash: varchar("passwordHash", { length: 255 }),
  // Permissões
  nivelAcesso: mysqlEnum("nivelAcesso", ["admin", "gerente", "atendente", "mecanico", "financeiro", "personalizado"]).default("atendente"),
  permissoes: text("permissoes"), // JSON com permissões específicas
  ativo: boolean("ativo").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Clientes da oficina
 */
export const clientes = mysqlTable("clientes", {
  id: int("id").autoincrement().primaryKey(),
  nome: varchar("nome", { length: 255 }).notNull(),
  cpfCnpj: varchar("cpfCnpj", { length: 18 }),
  telefone: varchar("telefone", { length: 20 }),
  email: varchar("email", { length: 320 }),
  endereco: text("endereco"),
  cidade: varchar("cidade", { length: 100 }),
  estado: varchar("estado", { length: 2 }),
  cep: varchar("cep", { length: 9 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Cliente = typeof clientes.$inferSelect;
export type InsertCliente = typeof clientes.$inferInsert;

/**
 * Veículos dos clientes
 */
export const veiculos = mysqlTable("veiculos", {
  id: int("id").autoincrement().primaryKey(),
  clienteId: int("clienteId").notNull(),
  placa: varchar("placa", { length: 10 }).notNull(),
  marca: varchar("marca", { length: 100 }),
  modelo: varchar("modelo", { length: 100 }).notNull(),
  ano: int("ano"),
  cor: varchar("cor", { length: 50 }),
  status: mysqlEnum("status", ["aguardando_orcamento", "orcamento_pendente", "aprovado", "em_execucao", "finalizado", "entregue"]).default("aguardando_orcamento").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Veiculo = typeof veiculos.$inferSelect;
export type InsertVeiculo = typeof veiculos.$inferInsert;

/**
 * Orçamentos
 */
export const orcamentos = mysqlTable("orcamentos", {
  id: int("id").autoincrement().primaryKey(),
  numero: varchar("numero", { length: 50 }).notNull().unique(),
  clienteId: int("clienteId").notNull(),
  veiculoId: int("veiculoId").notNull(),
  dataEntrada: timestamp("dataEntrada").notNull(),
  prazoEntrega: timestamp("prazoEntrega"),
  numeroOS: varchar("numeroOS", { length: 50 }),
  status: mysqlEnum("status", ["pendente", "aprovado", "rejeitado", "em_execucao", "concluido"]).default("pendente").notNull(),
  observacoes: text("observacoes"),
  desconto: int("desconto").default(0).notNull(), // em centavos
  acrescimo: int("acrescimo").default(0).notNull(), // em centavos
  subtotalItens: int("subtotalItens").default(0).notNull(), // em centavos
  subtotalComplementos: int("subtotalComplementos").default(0).notNull(), // em centavos
  total: int("total").default(0).notNull(), // em centavos
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Orcamento = typeof orcamentos.$inferSelect;
export type InsertOrcamento = typeof orcamentos.$inferInsert;

/**
 * Itens do orçamento (peças, pintura, funilaria, outros)
 */
export const itensOrcamento = mysqlTable("itensOrcamento", {
  id: int("id").autoincrement().primaryKey(),
  orcamentoId: int("orcamentoId").notNull(),
  categoria: mysqlEnum("categoria", ["pecas", "pintura", "funilaria", "outros"]).notNull(),
  descricao: text("descricao").notNull(),
  quantidade: int("quantidade").default(1).notNull(),
  valorUnitario: int("valorUnitario").default(0).notNull(), // em centavos
  valorTotal: int("valorTotal").default(0).notNull(), // em centavos
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ItemOrcamento = typeof itensOrcamento.$inferSelect;
export type InsertItemOrcamento = typeof itensOrcamento.$inferInsert;

/**
 * Complementos do orçamento
 */
export const complementosOrcamento = mysqlTable("complementosOrcamento", {
  id: int("id").autoincrement().primaryKey(),
  orcamentoId: int("orcamentoId").notNull(),
  descricao: text("descricao").notNull(),
  valor: int("valor").default(0).notNull(), // em centavos
  data: timestamp("data").notNull(),
  responsavel: varchar("responsavel", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ComplementoOrcamento = typeof complementosOrcamento.$inferSelect;
export type InsertComplementoOrcamento = typeof complementosOrcamento.$inferInsert;

/**
 * Ordens de Serviço
 */
export const ordensServico = mysqlTable("ordensServico", {
  id: int("id").autoincrement().primaryKey(),
  numero: varchar("numero", { length: 50 }).notNull().unique(),
  numeroOSCliente: varchar("numeroOSCliente", { length: 50 }),
  orcamentoId: int("orcamentoId"), // vinculação com orçamento
  clienteId: int("clienteId").notNull(),
  veiculoId: int("veiculoId").notNull(),
  descricaoServicos: text("descricaoServicos").notNull(),
  valorTotal: int("valorTotal").default(0).notNull(), // em centavos
  
  // Checklist de Entrada
  nivelCombustivel: mysqlEnum("nivelCombustivel", ["vazio", "1/4", "1/2", "3/4", "cheio"]).default("vazio"),
  quilometragem: int("quilometragem").default(0),
  checklistEntrada: text("checklistEntrada"), // JSON com itens do checklist
  observacoesEntrada: text("observacoesEntrada"),
  fotosEntrada: text("fotosEntrada"), // JSON com URLs das fotos
  
  // Checklist de Saída
  checklistSaida: text("checklistSaida"), // JSON com itens do checklist
  observacoesSaida: text("observacoesSaida"),
  fotosSaida: text("fotosSaida"), // JSON com URLs das fotos
  
  // Datas importantes
  dataEntrada: timestamp("dataEntrada").notNull(),
  dataPrevista: timestamp("dataPrevista"),
  dataConclusao: timestamp("dataConclusao"),
  dataSaida: timestamp("dataSaida"),
  
  observacoes: text("observacoes"),
  status: mysqlEnum("status", ["aguardando", "em_execucao", "concluido", "entregue"]).default("aguardando").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type OrdemServico = typeof ordensServico.$inferSelect;
export type InsertOrdemServico = typeof ordensServico.$inferInsert;

/**
 * Notas Fiscais
 */
export const notasFiscais = mysqlTable("notasFiscais", {
  id: int("id").autoincrement().primaryKey(),
  ordemServicoId: int("ordemServicoId").notNull(),
  numero: varchar("numero", { length: 50 }).notNull(),
  valor: int("valor").default(0).notNull(), // em centavos
  dataEmissao: timestamp("dataEmissao").notNull(),
  dataVencimento: timestamp("dataVencimento").notNull(),
  dataPagamento: timestamp("dataPagamento"),
  status: mysqlEnum("status", ["a_vencer", "vencido", "pago"]).default("a_vencer").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type NotaFiscal = typeof notasFiscais.$inferSelect;
export type InsertNotaFiscal = typeof notasFiscais.$inferInsert;

/**
 * Produtos/Peças em estoque
 */
export const produtos = mysqlTable("produtos", {
  id: int("id").autoincrement().primaryKey(),
  codigo: varchar("codigo", { length: 50 }).notNull().unique(),
  descricao: text("descricao").notNull(),
  categoria: mysqlEnum("categoria", ["peca", "pintura", "funilaria", "outros"]).notNull(),
  unidade: varchar("unidade", { length: 10 }).default("UN").notNull(),
  estoqueAtual: int("estoqueAtual").default(0).notNull(),
  estoqueMinimo: int("estoqueMinimo").default(0).notNull(),
  valorCusto: int("valorCusto").default(0).notNull(), // em centavos
  valorVenda: int("valorVenda").default(0).notNull(), // em centavos
  ativo: boolean("ativo").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Produto = typeof produtos.$inferSelect;
export type InsertProduto = typeof produtos.$inferInsert;

/**
 * Movimentações de estoque
 */
export const movimentacoesEstoque = mysqlTable("movimentacoesEstoque", {
  id: int("id").autoincrement().primaryKey(),
  produtoId: int("produtoId").notNull(),
  tipo: mysqlEnum("tipo", ["entrada", "saida", "ajuste"]).notNull(),
  quantidade: int("quantidade").notNull(),
  valorUnitario: int("valorUnitario").default(0).notNull(), // em centavos
  motivo: text("motivo"),
  documento: varchar("documento", { length: 50 }),
  usuarioId: int("usuarioId"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type MovimentacaoEstoque = typeof movimentacoesEstoque.$inferSelect;
export type InsertMovimentacaoEstoque = typeof movimentacoesEstoque.$inferInsert;

/**
 * Fornecedores
 */
export const fornecedores = mysqlTable("fornecedores", {
  id: int("id").autoincrement().primaryKey(),
  nome: varchar("nome", { length: 255 }).notNull(),
  cnpj: varchar("cnpj", { length: 18 }),
  telefone: varchar("telefone", { length: 20 }),
  email: varchar("email", { length: 320 }),
  endereco: text("endereco"),
  cidade: varchar("cidade", { length: 100 }),
  estado: varchar("estado", { length: 2 }),
  cep: varchar("cep", { length: 9 }),
  ativo: boolean("ativo").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Fornecedor = typeof fornecedores.$inferSelect;
export type InsertFornecedor = typeof fornecedores.$inferInsert;

/**
 * Pedidos de Compra
 */
export const pedidosCompra = mysqlTable("pedidosCompra", {
  id: int("id").autoincrement().primaryKey(),
  numero: varchar("numero", { length: 50 }).notNull().unique(),
  fornecedorId: int("fornecedorId").notNull(),
  dataEmissao: timestamp("dataEmissao").notNull(),
  dataPrevisao: timestamp("dataPrevisao"),
  dataRecebimento: timestamp("dataRecebimento"),
  status: mysqlEnum("status", ["pendente", "parcial", "recebido", "cancelado"]).default("pendente").notNull(),
  valorTotal: int("valorTotal").default(0).notNull(), // em centavos
  observacoes: text("observacoes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PedidoCompra = typeof pedidosCompra.$inferSelect;
export type InsertPedidoCompra = typeof pedidosCompra.$inferInsert;

/**
 * Itens do Pedido de Compra
 */
export const itensPedidoCompra = mysqlTable("itensPedidoCompra", {
  id: int("id").autoincrement().primaryKey(),
  pedidoCompraId: int("pedidoCompraId").notNull(),
  produtoId: int("produtoId").notNull(),
  quantidade: int("quantidade").notNull(),
  quantidadeRecebida: int("quantidadeRecebida").default(0).notNull(),
  valorUnitario: int("valorUnitario").default(0).notNull(), // em centavos
  valorTotal: int("valorTotal").default(0).notNull(), // em centavos
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ItemPedidoCompra = typeof itensPedidoCompra.$inferSelect;
export type InsertItemPedidoCompra = typeof itensPedidoCompra.$inferInsert;

/**
 * Agendamentos
 */
export const agendamentos = mysqlTable("agendamentos", {
  id: int("id").autoincrement().primaryKey(),
  clienteId: int("clienteId").notNull(),
  veiculoId: int("veiculoId"),
  dataHora: timestamp("dataHora").notNull(),
  duracao: int("duracao").default(60).notNull(), // em minutos
  servico: text("servico").notNull(),
  status: mysqlEnum("status", ["agendado", "confirmado", "em_atendimento", "concluido", "cancelado"]).default("agendado").notNull(),
  observacoes: text("observacoes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Agendamento = typeof agendamentos.$inferSelect;
export type InsertAgendamento = typeof agendamentos.$inferInsert;

/**
 * Contas a Pagar
 */
export const contasPagar = mysqlTable("contasPagar", {
  id: int("id").autoincrement().primaryKey(),
  descricao: text("descricao").notNull(),
  fornecedorId: int("fornecedorId"),
  colaboradorId: int("colaboradorId"), // Para pagamentos de salário
  valor: int("valor").default(0).notNull(), // em centavos
  dataEmissao: timestamp("dataEmissao").notNull(),
  dataVencimento: timestamp("dataVencimento").notNull(),
  dataPagamento: timestamp("dataPagamento"),
  status: mysqlEnum("status", ["pendente", "pago", "vencido", "cancelado"]).default("pendente").notNull(),
  categoria: varchar("categoria", { length: 50 }),
  formaPagamento: varchar("formaPagamento", { length: 50 }),
  observacoes: text("observacoes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ContaPagar = typeof contasPagar.$inferSelect;
export type InsertContaPagar = typeof contasPagar.$inferInsert;

/**
 * Contas a Receber
 */
export const contasReceber = mysqlTable("contasReceber", {
  id: int("id").autoincrement().primaryKey(),
  descricao: text("descricao").notNull(),
  clienteId: int("clienteId"),
  orcamentoId: int("orcamentoId"),
  ordemServicoId: int("ordemServicoId"),
  valor: int("valor").default(0).notNull(), // em centavos
  dataEmissao: timestamp("dataEmissao").notNull(),
  dataVencimento: timestamp("dataVencimento").notNull(),
  dataRecebimento: timestamp("dataRecebimento"),
  status: mysqlEnum("status", ["pendente", "recebido", "vencido", "cancelado"]).default("pendente").notNull(),
  categoria: varchar("categoria", { length: 50 }),
  formaPagamento: varchar("formaPagamento", { length: 50 }),
  observacoes: text("observacoes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ContaReceber = typeof contasReceber.$inferSelect;
export type InsertContaReceber = typeof contasReceber.$inferInsert;

/**
 * Mídias (fotos e vídeos) dos orçamentos
 */
export const midiasOrcamento = mysqlTable("midiasOrcamento", {
  id: int("id").autoincrement().primaryKey(),
  orcamentoId: int("orcamentoId").notNull(),
  tipo: mysqlEnum("tipo", ["foto", "video"]).notNull(),
  url: text("url").notNull(),
  fileKey: varchar("fileKey", { length: 255 }).notNull(),
  fileName: varchar("fileName", { length: 255 }),
  fileSize: int("fileSize"), // em bytes
  mimeType: varchar("mimeType", { length: 100 }),
  descricao: text("descricao"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type MidiaOrcamento = typeof midiasOrcamento.$inferSelect;
export type InsertMidiaOrcamento = typeof midiasOrcamento.$inferInsert;

/**
 * Histórico de e-mails enviados
 */
export const emailsEnviados = mysqlTable("emailsEnviados", {
  id: int("id").autoincrement().primaryKey(),
  orcamentoId: int("orcamentoId"),
  ordemServicoId: int("ordemServicoId"),
  destinatario: varchar("destinatario", { length: 320 }).notNull(),
  assunto: varchar("assunto", { length: 255 }).notNull(),
  corpo: text("corpo"),
  anexos: text("anexos"), // JSON com lista de anexos
  status: mysqlEnum("status", ["enviado", "erro", "pendente"]).default("pendente").notNull(),
  erroMensagem: text("erroMensagem"),
  enviadoPor: int("enviadoPor"), // userId
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type EmailEnviado = typeof emailsEnviados.$inferSelect;
export type InsertEmailEnviado = typeof emailsEnviados.$inferInsert;

/**
 * Colaboradores (funcionários) da oficina
 */
export const colaboradores = mysqlTable("colaboradores", {
  id: int("id").autoincrement().primaryKey(),
  nome: varchar("nome", { length: 255 }).notNull(),
  cargo: varchar("cargo", { length: 100 }),
  salario: int("salario").notNull(), // em centavos
  tipoPagamento: mysqlEnum("tipoPagamento", ["semanal", "quinzenal", "mensal"]).notNull(),
  diaPagamento: int("diaPagamento").notNull(), // 0=domingo, 1=segunda, ..., 6=sábado (para semanal) ou dia do mês (1-31 para quinzenal/mensal)
  dataAdmissao: timestamp("dataAdmissao").notNull(),
  status: mysqlEnum("status", ["ativo", "inativo"]).default("ativo").notNull(),
  observacoes: text("observacoes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Colaborador = typeof colaboradores.$inferSelect;
export type InsertColaborador = typeof colaboradores.$inferInsert;

/**
 * Adiantamentos salariais
 */
export const adiantamentos = mysqlTable("adiantamentos", {
  id: int("id").autoincrement().primaryKey(),
  colaboradorId: int("colaboradorId").notNull(),
  valor: int("valor").notNull(), // em centavos
  dataAdiantamento: timestamp("dataAdiantamento").notNull(),
  descricao: text("descricao"),
  descontado: boolean("descontado").default(false).notNull(),
  contaPagarId: int("contaPagarId"), // ID da conta onde foi descontado
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Adiantamento = typeof adiantamentos.$inferSelect;
export type InsertAdiantamento = typeof adiantamentos.$inferInsert;


export const orcamentosExternos = mysqlTable("orcamentos_externos", {
  id: int("id").autoincrement().primaryKey(),
  cliente: varchar("cliente", { length: 255 }).notNull(),
  placa: varchar("placa", { length: 20 }).notNull(),
  modelo: varchar("modelo", { length: 255 }).notNull(),
  valor: int("valor").notNull(), // em centavos
  pdfUrl: text("pdf_url"),
  pdfKey: varchar("pdf_key", { length: 500 }),
  dataRecebimento: timestamp("data_recebimento").defaultNow().notNull(),
  status: mysqlEnum("status", ["pendente", "em_analise", "aprovado", "rejeitado"]).default("pendente").notNull(),
  observacoes: text("observacoes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type OrcamentoExterno = typeof orcamentosExternos.$inferSelect;
export type InsertOrcamentoExterno = typeof orcamentosExternos.$inferInsert;
