-- Script para corrigir permissões de administrador
-- Execute este script no painel Database do sistema publicado

-- Atualizar usuário para admin (substitua o email pelo seu)
UPDATE users 
SET role = 'admin', nivelAcesso = 'admin', ativo = 1
WHERE email = 'jocksanfaria@outlook.com';

-- Verificar se foi atualizado
SELECT id, email, role, nivelAcesso, ativo 
FROM users 
WHERE email = 'jocksanfaria@outlook.com';
