# Manual do Sistema Aliança Auto Center
## Guia Completo de Uso - Todas as Funcionalidades

---

## Slide 1: Bem-vindo ao Sistema Aliança Auto Center
### Seu sistema completo de gestão automotiva

**O que este manual oferece:**
- Guia passo a passo de todas as funcionalidades
- Dicas práticas para agilizar seu trabalho
- Exemplos reais de uso no dia a dia
- Atalhos e truques para economizar tempo

**Módulos principais:**
- Dashboard (visão geral)
- Orçamentos (criação e gestão)
- Orçamentos Externos (PDFs de seguradoras)
- Ordens de Serviço
- Clientes e Veículos
- Financeiro (contas a receber/pagar)
- Estoque
- Agendamentos
- Colaboradores

---

## Slide 2: Dashboard - Visão Geral do Negócio
### Acompanhe tudo em tempo real

**O que você vê no Dashboard:**
- **Orçamentos Pendentes**: Quantos orçamentos aguardam aprovação do cliente
- **OS em Execução**: Quantos veículos estão sendo trabalhados agora
- **A Receber**: Total de dinheiro que clientes devem (com quantidade de contas)
- **A Pagar**: Total de contas a pagar (fornecedores, colaboradores)
- **Produtos em Estoque Baixo**: Quantas peças precisam reposição urgente
- **Folha Semanal**: Quanto você vai pagar em salários nos próximos 7 dias

**Como usar:**
- Acesse ao abrir o sistema (tela inicial)
- Clique nos cards para ver detalhes (ex: clicar em "A Receber" abre o Financeiro filtrado)
- Verifique "Atividades Recentes" para acompanhar últimas ações
- Confira "Próximos Agendamentos" para se preparar

**Dica prática:** Comece o dia verificando o Dashboard para saber prioridades

---

## Slide 3: Orçamentos - Criando Novo Orçamento
### Passo a passo completo

**Como criar orçamento:**
1. Clique em "Orçamentos" no menu lateral
2. Clique no botão "+ Novo Orçamento" (canto superior direito)
3. Preencha dados do cliente:
   - **Cliente Cadastrado**: Busque por nome (autocomplete)
   - **Cliente Novo**: Digite nome, telefone, e-mail
4. Preencha dados do veículo:
   - Placa, Modelo, Ano
   - Sistema busca automaticamente se veículo já existe
5. Adicione itens do orçamento:
   - Escolha categoria: Peças, Pintura, Funilaria, Outros
   - Descrição, Quantidade, Valor Unitário
   - Sistema calcula subtotal automaticamente
6. Adicione complementos (serviços extras):
   - Descrição e valor
7. Aplique desconto ou acréscimo (se necessário)
8. Adicione observações importantes
9. Clique em "Salvar Orçamento"

**Dica:** Tire fotos do veículo durante criação do orçamento para documentar estado inicial

---

## Slide 4: Orçamentos - Gerenciando e Enviando
### Acompanhe e compartilhe orçamentos

**Como visualizar orçamento:**
- Na lista de orçamentos, clique no ícone de olho (👁️)
- Veja todos os detalhes: cliente, veículo, itens, valores, fotos

**Como enviar orçamento para cliente:**
1. Abra o orçamento (ícone de olho)
2. Clique no botão "Enviar por E-mail" (envelope)
3. Sistema abre seu app de e-mail com:
   - PDF do orçamento anexado automaticamente
   - Mensagem profissional pré-escrita
   - E-mail da oficina em cópia (funilariaalianca10@gmail.com)
4. Adicione e-mail do cliente e envie

**Como alterar status do orçamento:**
- No orçamento aberto, use o dropdown "Status"
- Opções: Pendente → Aprovado → Em Execução → Concluído → Cancelado
- **Importante:** Ao aprovar orçamento, sistema cria Ordem de Serviço automaticamente

**Como editar orçamento:**
- Clique no ícone de lápis (✏️) na lista
- Modifique o que precisar
- Salve alterações

---

## Slide 5: Orçamentos Externos - PDFs de Seguradoras
### Receba orçamentos de Localiza, Unidas, etc.

**O que são Orçamentos Externos:**
- Orçamentos que seguradoras enviam em PDF
- Sistema usa Inteligência Artificial para extrair dados automaticamente
- Cria conta a receber no Financeiro automaticamente

**Como cadastrar orçamento externo:**
1. Clique em "Orçamentos Externos" no menu
2. Clique em "+ Novo Orçamento Externo"
3. **Upload do PDF:**
   - Clique em "Escolher arquivo" ou arraste PDF
   - Sistema analisa PDF com IA e extrai: cliente, placa, modelo, valor
4. **Revise dados extraídos:**
   - Confira se cliente, placa e valor estão corretos
   - Corrija se necessário
5. Clique em "Salvar"

**O que acontece automaticamente:**
- Sistema cria conta a receber no Financeiro
- Vencimento: 30 dias após cadastro
- Descrição: "Orçamento Externo [cliente] - [placa]"

**Dica:** Mantenha PDFs organizados por seguradora para facilitar cobrança

---

## Slide 6: Ordens de Serviço - Executando Trabalhos
### Gerencie serviços em andamento

**O que é Ordem de Serviço (OS):**
- Documento que autoriza início do trabalho no veículo
- Criada automaticamente quando orçamento é aprovado
- Acompanha status do serviço até conclusão

**Como visualizar OS:**
1. Clique em "Ordens de Serviço" no menu
2. Veja cards de resumo:
   - Aguardando Início
   - Em Execução
   - Concluídas
3. Clique em uma OS para ver detalhes

**Como atualizar status da OS:**
- Abra a OS
- Use dropdown "Status"
- Opções: Aguardando → Em Execução → Concluída → Cancelada

**Informações importantes na OS:**
- Cliente e veículo
- Itens do orçamento original
- Valor total
- Data de criação
- Observações

**Dica:** Atualize status da OS diariamente para Dashboard refletir situação real

---

## Slide 7: Clientes - Cadastro e Gestão
### Organize informações de clientes

**Como cadastrar cliente:**
1. Clique em "Clientes" no menu
2. Clique em "+ Novo Cliente"
3. Preencha dados:
   - Nome completo
   - CPF/CNPJ
   - Telefone (com DDD)
   - E-mail
   - Endereço completo
4. Clique em "Salvar"

**Como buscar cliente:**
- Use campo de busca no topo da lista
- Digite nome, telefone ou CPF
- Resultados aparecem em tempo real

**Como editar cliente:**
- Clique no ícone de lápis ao lado do cliente
- Modifique dados necessários
- Salve alterações

**Como excluir cliente:**
- Clique no ícone de lixeira
- Confirme exclusão
- **Atenção:** Não é possível excluir cliente com orçamentos vinculados

**Dica:** Cadastre clientes com e-mail para enviar orçamentos automaticamente

---

## Slide 8: Veículos - Acompanhamento de Status
### Veja situação de cada veículo

**Como funciona o módulo Veículos:**
- Mostra todos os veículos cadastrados
- Organiza por status atual
- Facilita localização rápida

**Status possíveis:**
- **Aguardando Orçamento**: Cliente pediu orçamento mas ainda não foi criado
- **Orçamento Pendente**: Orçamento criado, aguardando aprovação do cliente
- **Aprovado**: Cliente aprovou, aguardando início do serviço
- **Em Execução**: Veículo está sendo trabalhado agora
- **Finalizado**: Serviço concluído, aguardando retirada
- **Entregue**: Veículo foi devolvido ao cliente

**Como cadastrar veículo:**
1. Clique em "Veículos" no menu
2. Clique em "+ Novo Veículo"
3. Preencha: Cliente, Placa, Modelo, Ano
4. Selecione status inicial
5. Salve

**Dica:** Status é atualizado automaticamente quando você muda status do orçamento/OS

---

## Slide 9: Financeiro - Contas a Receber
### Controle total do que clientes devem

**O que você vê em Contas a Receber:**
- **Total a Receber**: Soma de todas as contas pendentes
- **Contas Vencidas**: Quantas contas passaram da data de vencimento (em vermelho)
- **Vence em 7 dias**: Contas próximas do vencimento (em amarelo)
- **Recebidas no Mês**: Quanto você já recebeu este mês (em verde)

**Como usar o filtro por cliente:**
1. Na seção "Filtros Práticos", digite nome do cliente no campo "Cliente"
2. Sistema mostra autocomplete com clientes que têm contas
3. Selecione o cliente
4. **Card de Resumo aparece** mostrando:
   - Total a receber daquele cliente
   - Quantidade de veículos (placas)
   - Contas pendentes
5. **Detalhamento por veículo** mostra:
   - Cada placa com valor específico
   - Modelo do veículo
   - Quantidade de contas

**Como marcar conta como recebida:**
1. Localize a conta na tabela
2. Clique no botão "Marcar como Recebido" (verde)
3. Conta sai da lista de pendentes
4. Dashboard atualiza automaticamente

**Dica:** Use filtro por cliente para cobrar seguradoras (Localiza, Unidas, etc.)

---

## Slide 10: Financeiro - Contas a Pagar
### Organize pagamentos a fornecedores e colaboradores

**Como criar conta a pagar:**
1. Vá em "Financeiro" → Aba "Contas a Pagar"
2. Clique em "+ Nova Conta"
3. Preencha:
   - Descrição (ex: "Compra de peças - Fornecedor X")
   - Valor
   - Data de vencimento
   - Categoria (Fornecedor, Colaborador, Outros)
4. Salve

**Como marcar conta como paga:**
- Localize conta na tabela
- Clique em "Marcar como Pago"
- Conta sai da lista de pendentes

**Indicadores importantes:**
- **Total a Pagar**: Soma de contas pendentes
- **Contas Vencidas**: Contas atrasadas (vermelho)
- **Vence em 7 dias**: Contas próximas (amarelo)
- **Pagas no Mês**: Quanto você já pagou este mês

**Dica:** Cadastre contas a pagar assim que receber nota fiscal para não esquecer

---

## Slide 11: Estoque - Controle de Peças e Produtos
### Nunca fique sem peças importantes

**Como cadastrar produto:**
1. Clique em "Estoque" no menu
2. Clique em "+ Novo Produto"
3. Preencha:
   - Nome/Descrição
   - Código (opcional)
   - Categoria
   - Quantidade atual
   - Estoque mínimo (alerta)
   - Preço de custo
   - Preço de venda
4. Salve

**Como dar entrada no estoque:**
1. Localize produto na lista
2. Clique em "Entrada"
3. Digite quantidade recebida
4. Confirme

**Como dar saída do estoque:**
1. Localize produto
2. Clique em "Saída"
3. Digite quantidade usada
4. Confirme

**Alertas automáticos:**
- Produtos abaixo do estoque mínimo aparecem em vermelho
- Dashboard mostra quantidade de produtos em estoque baixo
- Card "Produtos em Estoque Baixo" facilita reposição

**Dica:** Configure estoque mínimo realista para não ficar sem peças essenciais

---

## Slide 12: Agendamentos - Organize Serviços Futuros
### Planeje trabalhos com antecedência

**Como criar agendamento:**
1. Clique em "Agendamentos" no menu
2. Clique em "+ Novo Agendamento"
3. Preencha:
   - Cliente (busca por nome)
   - Veículo (placa)
   - Data e hora
   - Tipo de serviço
   - Observações
4. Salve

**Como visualizar agendamentos:**
- **Agrupados por data**: Sistema organiza automaticamente
- **Hoje**: Agendamentos de hoje aparecem primeiro
- **Próximos dias**: Agendamentos futuros em ordem cronológica

**Indicadores no Dashboard:**
- "Próximos Agendamentos" mostra os 5 mais próximos
- Facilita preparação (separar peças, organizar equipe)

**Como cancelar agendamento:**
- Abra o agendamento
- Clique em "Cancelar"
- Confirme

**Dica:** Crie agendamentos ao telefone com cliente para não esquecer

---

## Slide 13: Colaboradores - Gestão de Equipe
### Controle salários e pagamentos

**Como cadastrar colaborador:**
1. Clique em "Colaboradores" no menu
2. Clique em "+ Novo Colaborador"
3. Preencha:
   - Nome completo
   - CPF
   - Telefone
   - Cargo
   - Salário
   - Data de admissão
   - Dia de pagamento (1-31)
4. Salve

**Como funciona o controle de pagamentos:**
- Sistema calcula automaticamente próximos pagamentos
- Dashboard mostra "Folha Semanal" (pagamentos nos próximos 7 dias)
- Lista de colaboradores mostra:
  - Próximo pagamento
  - Dias restantes
  - Valor do salário

**Como editar colaborador:**
- Clique no ícone de lápis
- Modifique dados (salário, cargo, etc.)
- Salve

**Como desativar colaborador:**
- Clique no ícone de lixeira
- Confirme exclusão
- **Atenção:** Histórico de pagamentos é mantido

**Dica:** Configure dia de pagamento correto para Dashboard alertar com antecedência

---

## Slide 14: Relatórios - Análise de Desempenho
### Tome decisões baseadas em dados

**Tipos de relatórios disponíveis:**
- **Faturamento Mensal**: Quanto você faturou por mês
- **Recebimentos por Cliente**: Quais clientes mais pagam
- **Inadimplência**: Quem está devendo e há quanto tempo
- **Produtos Mais Vendidos**: Quais peças saem mais
- **Serviços Mais Realizados**: Tipos de serviço mais comuns

**Como gerar relatório:**
1. Clique em "Relatórios" no menu
2. Escolha tipo de relatório
3. Selecione período (mês, trimestre, ano)
4. Clique em "Gerar"
5. Visualize gráficos e tabelas
6. Exporte para Excel se necessário

**Dica:** Gere relatórios mensalmente para acompanhar crescimento do negócio

---

## Slide 15: Administração - Configurações do Sistema
### Personalize o sistema para sua oficina

**O que você pode configurar:**
- **Dados da Empresa**: Nome, endereço, telefone, e-mail
- **Logo**: Aparece em orçamentos e documentos
- **Usuários**: Criar logins para equipe (em breve)
- **Permissões**: Controlar quem acessa cada módulo (em breve)

**Como acessar Administração:**
1. Clique em "Administração" no menu
2. Faça alterações necessárias
3. Salve

**Dica:** Mantenha dados da empresa atualizados para orçamentos profissionais

---

## Slide 16: Dicas Gerais e Boas Práticas
### Maximize produtividade com o sistema

**Rotina diária recomendada:**
1. **Manhã**: Abra Dashboard para ver prioridades do dia
2. **Durante o dia**: 
   - Crie orçamentos conforme clientes chegam
   - Atualize status de OS em andamento
   - Registre saídas de estoque
3. **Fim do dia**: 
   - Marque contas recebidas
   - Verifique agendamentos do dia seguinte

**Atalhos para agilizar trabalho:**
- Use autocomplete de clientes (não precisa digitar tudo)
- Clique nos cards do Dashboard para ir direto ao módulo filtrado
- Tire fotos durante criação de orçamento (não precisa voltar depois)

**Organização:**
- Cadastre clientes com e-mail completo
- Configure estoque mínimo realista
- Atualize status de orçamentos/OS diariamente
- Use filtro por cliente no Financeiro para cobranças

**Backup:**
- Sistema salva tudo automaticamente na nuvem
- Acesse de qualquer dispositivo (celular, notebook, tablet)

---

## Slide 17: Fluxo Completo - Do Orçamento ao Recebimento
### Entenda o ciclo completo de um serviço

**Passo a passo completo:**

1. **Cliente chega** → Crie agendamento (ou atenda na hora)
2. **Avalie veículo** → Tire fotos, anote problemas
3. **Crie orçamento** → Adicione peças e serviços necessários
4. **Envie para cliente** → Use botão "Enviar por E-mail"
5. **Cliente aprova** → Mude status para "Aprovado"
6. **Sistema cria OS automaticamente** → Veículo vai para "Em Execução"
7. **Execute serviço** → Dê saída de peças no estoque
8. **Conclua OS** → Mude status para "Concluída"
9. **Cliente retira veículo** → Mude status para "Entregue"
10. **Receba pagamento** → Marque conta como recebida no Financeiro

**Tudo sincronizado:**
- Dashboard atualiza automaticamente
- Veículo muda de status sozinho
- Financeiro cria conta a receber
- Estoque desconta peças usadas

---

## Slide 18: Suporte e Próximos Passos
### Continue evoluindo com o sistema

**Precisa de ajuda?**
- Este manual cobre todas as funcionalidades atuais
- Consulte sempre que tiver dúvida
- Compartilhe com sua equipe

**Funcionalidades futuras:**
- Sistema de usuários com permissões
- Relatórios mais avançados
- Integração com WhatsApp
- App mobile nativo

**Boas práticas:**
- Treine sua equipe com este manual
- Comece usando módulos básicos (Orçamentos, Clientes)
- Expanda gradualmente para outros módulos
- Mantenha dados sempre atualizados

**Lembre-se:**
- Sistema foi feito para facilitar seu trabalho
- Quanto mais você usa, mais produtivo fica
- Dados organizados = decisões melhores

---

## Slide 19: Resumo de Atalhos Rápidos
### Referência rápida para o dia a dia

**Navegação:**
- **Dashboard**: Clique no logo ou botão "Dashboard"
- **Novo Orçamento**: Orçamentos → "+ Novo Orçamento"
- **Buscar Cliente**: Digite nome em qualquer campo de cliente
- **Filtrar Financeiro**: Digite nome do cliente em "Filtros Práticos"

**Ações rápidas:**
- **Enviar orçamento**: Abra orçamento → "Enviar por E-mail"
- **Aprovar orçamento**: Abra orçamento → Status → "Aprovado"
- **Marcar como recebido**: Financeiro → Botão verde na conta
- **Dar saída de estoque**: Estoque → Produto → "Saída"

**Cards clicáveis no Dashboard:**
- "Orçamentos Pendentes" → Lista de orçamentos pendentes
- "OS em Execução" → Lista de OS em execução
- "A Receber" → Financeiro filtrado
- "A Pagar" → Contas a pagar

**Dica final:** Imprima este slide e deixe próximo ao computador!

---

## Slide 20: Obrigado!
### Sucesso com o Sistema Aliança Auto Center

**Você agora domina:**
- ✅ Criação de orçamentos profissionais
- ✅ Gestão de ordens de serviço
- ✅ Controle financeiro completo
- ✅ Organização de estoque
- ✅ Agendamentos e planejamento
- ✅ Gestão de equipe

**Próximos passos:**
1. Pratique criando orçamentos de teste
2. Cadastre seus clientes atuais
3. Configure estoque com peças principais
4. Comece a usar no dia a dia

**Lembre-se:** Este manual está sempre disponível para consulta!

**Bom trabalho e ótimas vendas! 🚗💼**
