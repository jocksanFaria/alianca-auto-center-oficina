import PDFDocument from 'pdfkit';

interface OrcamentoData {
  orcamento: {
    numero: string;
    dataEntrada: Date;
    status: string;
    observacoes?: string | null;
    total: number;
    desconto: number;
    acrescimo: number;
  };
  cliente: {
    nome: string;
    cpfCnpj?: string | null;
    telefone?: string | null;
    email?: string | null;
  };
  veiculo: {
    placa: string;
    marca?: string | null;
    modelo?: string | null;
    ano?: number | null;
  };
  itens: Array<{
    categoria: string;
    descricao: string;
    quantidade: number;
    valorUnitario: number;
    valorTotal: number;
  }>;
  complementos: Array<{
    descricao: string;
    valor: number;
  }>;
}

export function generateOrcamentoPDF(data: OrcamentoData) {
  const doc = new PDFDocument({ 
    margin: 40,
    size: 'A4',
    bufferPages: true
  });

  const pageWidth = 595.28; // A4 width in points
  const margin = 40;
  const contentWidth = pageWidth - (margin * 2);

  // Cores do padrão
  const goldColor = '#D4AF37';
  const darkGray = '#333333';
  const lightGray = '#666666';

  // ========== CABEÇALHO ==========
  doc
    .fontSize(26)
    .fillColor(goldColor)
    .font('Helvetica-Bold')
    .text('ORÇAMENTO', margin, 50, { 
      width: contentWidth,
      align: 'center' 
    });

  doc
    .fontSize(18)
    .fillColor(darkGray)
    .font('Helvetica-Bold')
    .text('Aliança Auto Center', margin, doc.y + 10, {
      width: contentWidth,
      align: 'center'
    });

  doc
    .fontSize(9)
    .fillColor(lightGray)
    .font('Helvetica')
    .text('Nerópolis QD-01 LT-07 Residencial José Viandeli', margin, doc.y + 5, {
      width: contentWidth,
      align: 'center'
    })
    .text('Bairro: Balneário Meia Ponte - Goiânia/GO - CEP: 74594-300', margin, doc.y + 2, {
      width: contentWidth,
      align: 'center'
    })
    .text('WhatsApp: (62) 9 9662-7364', margin, doc.y + 2, {
      width: contentWidth,
      align: 'center'
    })
    .text('E-mail: funilariaalianca10@gmail.com', margin, doc.y + 2, {
      width: contentWidth,
      align: 'center'
    });

  // Linha separadora
  const lineY = doc.y + 15;
  doc
    .strokeColor(goldColor)
    .lineWidth(2)
    .moveTo(margin, lineY)
    .lineTo(pageWidth - margin, lineY)
    .stroke();

  // ========== INFORMAÇÕES DO ORÇAMENTO ==========
  doc.y = lineY + 20;
  
  doc
    .fontSize(10)
    .fillColor(darkGray)
    .font('Helvetica-Bold')
    .text(`Orçamento Nº: `, margin, doc.y, { continued: true })
    .font('Helvetica')
    .text(data.orcamento.numero);

  doc
    .font('Helvetica-Bold')
    .text(`Data: `, margin, doc.y + 5, { continued: true })
    .font('Helvetica')
    .text(new Date(data.orcamento.dataEntrada).toLocaleDateString('pt-BR'));

  doc
    .font('Helvetica-Bold')
    .text(`Status: `, margin, doc.y + 5, { continued: true })
    .font('Helvetica')
    .text(data.orcamento.status.toUpperCase());

  doc.y += 20;

  // ========== DADOS DO CLIENTE ==========
  doc
    .fontSize(12)
    .fillColor(goldColor)
    .font('Helvetica-Bold')
    .text('DADOS DO CLIENTE', margin, doc.y);

  doc.y += 10;

  doc
    .fontSize(10)
    .fillColor(darkGray)
    .font('Helvetica-Bold')
    .text('Nome: ', margin, doc.y, { continued: true })
    .font('Helvetica')
    .text(data.cliente.nome);

  if (data.cliente.cpfCnpj) {
    doc
      .font('Helvetica-Bold')
      .text('CPF/CNPJ: ', margin, doc.y + 5, { continued: true })
      .font('Helvetica')
      .text(data.cliente.cpfCnpj);
  }

  if (data.cliente.telefone) {
    doc
      .font('Helvetica-Bold')
      .text('Telefone: ', margin, doc.y + 5, { continued: true })
      .font('Helvetica')
      .text(data.cliente.telefone);
  }

  if (data.cliente.email) {
    doc
      .font('Helvetica-Bold')
      .text('E-mail: ', margin, doc.y + 5, { continued: true })
      .font('Helvetica')
      .text(data.cliente.email);
  }

  doc.y += 20;

  // ========== DADOS DO VEÍCULO ==========
  doc
    .fontSize(12)
    .fillColor(goldColor)
    .font('Helvetica-Bold')
    .text('DADOS DO VEÍCULO', margin, doc.y);

  doc.y += 10;

  doc
    .fontSize(10)
    .fillColor(darkGray)
    .font('Helvetica-Bold')
    .text('Placa: ', margin, doc.y, { continued: true })
    .font('Helvetica')
    .text(data.veiculo.placa);

  const marcaModelo = `${data.veiculo.marca || ''} ${data.veiculo.modelo || ''}`.trim();
  if (marcaModelo) {
    doc
      .font('Helvetica-Bold')
      .text('Marca/Modelo: ', margin, doc.y + 5, { continued: true })
      .font('Helvetica')
      .text(marcaModelo);
  }

  if (data.veiculo.ano) {
    doc
      .font('Helvetica-Bold')
      .text('Ano: ', margin, doc.y + 5, { continued: true })
      .font('Helvetica')
      .text(data.veiculo.ano.toString());
  }

  doc.y += 25;

  // ========== ITENS POR CATEGORIA ==========
  const categorias = ['pecas', 'pintura', 'funilaria', 'outros'];
  const categoriasNomes: Record<string, string> = {
    pecas: 'PEÇAS',
    pintura: 'SERVIÇOS DE PINTURA',
    funilaria: 'SERVIÇOS DE FUNILARIA',
    outros: 'OUTROS',
  };

  categorias.forEach((categoria) => {
    const itensDaCategoria = data.itens.filter((item) => item.categoria === categoria);
    
    if (itensDaCategoria.length > 0) {
      // Cabeçalho da categoria
      doc
        .fontSize(12)
        .fillColor(goldColor)
        .font('Helvetica-Bold')
        .text(categoriasNomes[categoria], margin, doc.y);

      doc.y += 10;

      // Cabeçalho da tabela
      doc
        .fontSize(9)
        .fillColor(darkGray)
        .font('Helvetica-Bold');

      const col1 = margin;
      const col2 = margin + 280;
      const col3 = margin + 350;
      const col4 = margin + 450;

      const tableHeaderY = doc.y;
      doc.text('Descrição', col1, tableHeaderY);
      doc.text('Qtd', col2, tableHeaderY);
      doc.text('Valor Unit.', col3, tableHeaderY);
      doc.text('Total', col4, tableHeaderY);

      doc.y = tableHeaderY + 15;

      // Linha separadora
      doc
        .strokeColor(lightGray)
        .lineWidth(0.5)
        .moveTo(margin, doc.y)
        .lineTo(pageWidth - margin, doc.y)
        .stroke();

      doc.y += 8;

      // Itens
      doc.font('Helvetica').fontSize(9);
      
      itensDaCategoria.forEach((item) => {
        const itemY = doc.y;
        
        // Truncar descrição se for muito longa (max 50 caracteres)
        const desc = item.descricao.length > 50 ? item.descricao.substring(0, 47) + '...' : item.descricao;
        
        // Desenhar cada campo com lineBreak false
        doc.text(desc, col1, itemY, { lineBreak: false });
        doc.text(item.quantidade.toString(), col2, itemY, { lineBreak: false });
        doc.text(`R$ ${item.valorUnitario.toFixed(2).replace('.', ',')}`, col3, itemY, { lineBreak: false });
        doc.text(`R$ ${item.valorTotal.toFixed(2).replace('.', ',')}`, col4, itemY, { lineBreak: false });
        
        // Avançar para próxima linha manualmente
        doc.y = itemY + 18;
      });

      doc.y += 10;
    }
  });

  // ========== COMPLEMENTOS ==========
  if (data.complementos.length > 0) {
    doc
      .fontSize(12)
      .fillColor(goldColor)
      .font('Helvetica-Bold')
      .text('COMPLEMENTOS', margin, doc.y);

    doc.y += 10;

    doc
      .fontSize(10)
      .fillColor(darkGray)
      .font('Helvetica');

    data.complementos.forEach((comp) => {
      doc.text(`${comp.descricao}: R$ ${comp.valor.toFixed(2).replace('.', ',')}`, margin, doc.y);
      doc.y += 15;
    });

    doc.y += 10;
  }

  // ========== OBSERVAÇÕES ==========
  if (data.orcamento.observacoes) {
    doc
      .fontSize(12)
      .fillColor(goldColor)
      .font('Helvetica-Bold')
      .text('OBSERVAÇÕES', margin, doc.y);

    doc.y += 10;

    doc
      .fontSize(10)
      .fillColor(darkGray)
      .font('Helvetica')
      .text(data.orcamento.observacoes, margin, doc.y, {
        width: contentWidth,
        align: 'justify'
      });

    doc.y += 20;
  }

  // ========== RESUMO FINANCEIRO ==========
  const resumoY = doc.y;
  doc
    .fontSize(12)
    .fillColor(goldColor)
    .font('Helvetica-Bold')
    .text('RESUMO FINANCEIRO', 0, resumoY, { width: pageWidth, align: 'center' });

  doc.y = resumoY + 20;

  // Calcular subtotais separados
  // Subtotal de Peças: apenas itens da categoria "pecas"
  const subtotalPecas = data.itens
    .filter(item => item.categoria.toLowerCase() === 'pecas')
    .reduce((sum, item) => sum + item.valorTotal, 0);
  
  // Subtotal de Serviços: Pintura + Funilaria + Outros + Complementos
  const subtotalServicosItens = data.itens
    .filter(item => item.categoria.toLowerCase() !== 'pecas')
    .reduce((sum, item) => sum + item.valorTotal, 0);
  const subtotalServicosComplementos = data.complementos.reduce((sum, comp) => sum + comp.valor, 0);
  const subtotalServicos = subtotalServicosItens + subtotalServicosComplementos;
  
  const subtotalGeral = subtotalPecas + subtotalServicos;

  // Centralizar resumo financeiro
  const financialWidth = 300;
  const financialX = (pageWidth - financialWidth) / 2;
  
  doc
    .fontSize(11)
    .fillColor(darkGray)
    .font('Helvetica');
  
  // Subtotal de Peças
  doc.text('Subtotal de Peças:', financialX, doc.y, { width: 150, align: 'left' });
  doc.text(`R$ ${subtotalPecas.toFixed(2).replace('.', ',')}`, financialX + 150, doc.y, { width: 150, align: 'right', lineBreak: false });

  doc.y += 18;

  // Subtotal de Serviços
  doc.text('Subtotal de Serviços:', financialX, doc.y, { width: 150, align: 'left' });
  doc.text(`R$ ${subtotalServicos.toFixed(2).replace('.', ',')}`, financialX + 150, doc.y, { width: 150, align: 'right', lineBreak: false });

  doc.y += 18;

  // Subtotal Geral
  doc.fillColor(goldColor).font('Helvetica-Bold');
  doc.text('Subtotal Geral:', financialX, doc.y, { width: 150, align: 'left' });
  doc.text(`R$ ${subtotalGeral.toFixed(2).replace('.', ',')}`, financialX + 150, doc.y, { width: 150, align: 'right', lineBreak: false });

  doc.fillColor(darkGray).font('Helvetica');

  if (data.orcamento.desconto > 0) {
    doc.y += 18;
    doc.fillColor('#DC2626');
    doc.text('Desconto:', financialX, doc.y, { width: 150, align: 'left' });
    doc.text(`- R$ ${data.orcamento.desconto.toFixed(2).replace('.', ',')}`, financialX + 150, doc.y, { width: 150, align: 'right', lineBreak: false });
  }

  if (data.orcamento.acrescimo > 0) {
    doc.y += 18;
    doc.fillColor('#16A34A');
    doc.text('Acréscimo:', financialX, doc.y, { width: 150, align: 'left' });
    doc.text(`+ R$ ${data.orcamento.acrescimo.toFixed(2).replace('.', ',')}`, financialX + 150, doc.y, { width: 150, align: 'right', lineBreak: false });
  }

  doc.y += 20;

  // Linha separadora
  doc
    .strokeColor(goldColor)
    .lineWidth(2)
    .moveTo(financialX, doc.y)
    .lineTo(financialX + financialWidth, doc.y)
    .stroke();

  doc.y += 12;

  // Total final
  doc
    .fontSize(14)
    .fillColor(goldColor)
    .font('Helvetica-Bold');
  
  doc.text('TOTAL GERAL:', financialX, doc.y, { width: 150, align: 'left' });
  doc.text(`R$ ${data.orcamento.total.toFixed(2).replace('.', ',')}`, financialX + 150, doc.y, { width: 150, align: 'right', lineBreak: false });

  // ========== RODAPÉ ==========
  doc.y = pageWidth - 100;

  doc
    .fontSize(8)
    .fillColor(lightGray)
    .font('Helvetica')
    .text('Orçamento válido por 7 dias', margin, doc.y, {
      width: contentWidth,
      align: 'center'
    })
    .text('Aliança Auto Center - Todos os direitos reservados', margin, doc.y + 2, {
      width: contentWidth,
      align: 'center'
    });

  doc.end();

  return doc;
}
