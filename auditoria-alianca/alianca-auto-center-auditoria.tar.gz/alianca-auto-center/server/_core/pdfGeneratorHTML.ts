// @ts-ignore
import htmlPdf from 'html-pdf-node';

interface OrcamentoData {
  orcamento: {
    numero: string;
    dataEntrada: Date;
    status: string;
    observacoes?: string | null;
    total: number;
    desconto: number;
    acrescimo: number;
  };
  cliente: {
    nome: string;
    cpfCnpj?: string | null;
    telefone?: string | null;
    email?: string | null;
  };
  veiculo: {
    placa: string;
    marca?: string | null;
    modelo?: string | null;
    ano?: number | null;
  };
  itens: Array<{
    categoria: string;
    descricao: string;
    quantidade: number;
    valorUnitario: number;
    valorTotal: number;
  }>;
  complementos: Array<{
    descricao: string;
    valor: number;
  }>;
}

function formatCurrency(value: number): string {
  return `R$ ${value.toFixed(2).replace('.', ',')}`;
}

function formatDate(date: Date): string {
  return new Date(date).toLocaleDateString('pt-BR');
}

export async function generateOrcamentoPDFHTML(data: OrcamentoData): Promise<Buffer> {
  const { orcamento, cliente, veiculo, itens, complementos } = data;

  // Agrupar itens por categoria
  const itensPorCategoria: Record<string, typeof itens> = {};
  itens.forEach(item => {
    if (!itensPorCategoria[item.categoria]) {
      itensPorCategoria[item.categoria] = [];
    }
    itensPorCategoria[item.categoria].push(item);
  });

  const categoriasNomes: Record<string, string> = {
    pecas: 'PEÇAS',
    pintura: 'PINTURA',
    funilaria: 'FUNILARIA',
    outros: 'OUTROS'
  };

  // Gerar HTML das tabelas de itens
  let tabelasHTML = '';
  Object.entries(itensPorCategoria).forEach(([categoria, itensDaCategoria]) => {
    const nomeCategoria = categoriasNomes[categoria] || categoria.toUpperCase();
    
    tabelasHTML += `
      <div class="categoria-section">
        <h3 class="categoria-titulo">${nomeCategoria}</h3>
        <table class="tabela-itens">
          <thead>
            <tr>
              <th style="width: 50%;">Descrição</th>
              <th style="width: 15%;">Qtd</th>
              <th style="width: 17.5%;">Valor Unit.</th>
              <th style="width: 17.5%;">Total</th>
            </tr>
          </thead>
          <tbody>
            ${itensDaCategoria.map(item => `
              <tr>
                <td>${item.descricao}</td>
                <td style="text-align: center;">${item.quantidade}</td>
                <td style="text-align: right;">${formatCurrency(item.valorUnitario)}</td>
                <td style="text-align: right;">${formatCurrency(item.valorTotal)}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;
  });

  // Gerar HTML dos complementos
  let complementosHTML = '';
  if (complementos.length > 0) {
    complementosHTML = `
      <div class="categoria-section">
        <h3 class="categoria-titulo">COMPLEMENTOS</h3>
        <table class="tabela-complementos">
          <tbody>
            ${complementos.map(comp => `
              <tr>
                <td style="width: 70%;">${comp.descricao}</td>
                <td style="width: 30%; text-align: right; font-weight: bold;">${formatCurrency(comp.valor)}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;
  }

  // Calcular subtotal
  const subtotal = orcamento.total + orcamento.desconto - orcamento.acrescimo;

  const html = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <style>
        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }
        
        body {
          font-family: 'Helvetica', 'Arial', sans-serif;
          font-size: 11pt;
          line-height: 1.4;
          color: #333;
          padding: 30px;
        }
        
        .header {
          text-align: center;
          margin-bottom: 30px;
          border-bottom: 3px solid #D4AF37;
          padding-bottom: 20px;
        }
        
        .header h1 {
          font-size: 28pt;
          color: #D4AF37;
          margin-bottom: 10px;
        }
        
        .header .empresa-nome {
          font-size: 16pt;
          font-weight: bold;
          margin-bottom: 5px;
        }
        
        .header .empresa-info {
          font-size: 9pt;
          color: #666;
          line-height: 1.6;
        }
        
        .info-section {
          display: flex;
          justify-content: space-between;
          margin-bottom: 25px;
          gap: 20px;
        }
        
        .info-box {
          flex: 1;
          border: 1px solid #ddd;
          padding: 15px;
          border-radius: 5px;
          background-color: #f9f9f9;
        }
        
        .info-box h3 {
          font-size: 12pt;
          color: #D4AF37;
          margin-bottom: 10px;
          border-bottom: 1px solid #D4AF37;
          padding-bottom: 5px;
        }
        
        .info-box p {
          margin: 5px 0;
          font-size: 10pt;
        }
        
        .info-box strong {
          color: #555;
        }
        
        .categoria-section {
          margin-bottom: 25px;
        }
        
        .categoria-titulo {
          background-color: #D4AF37;
          color: white;
          padding: 8px 12px;
          font-size: 12pt;
          margin-bottom: 0;
        }
        
        .tabela-itens, .tabela-complementos {
          width: 100%;
          border-collapse: collapse;
          margin-bottom: 15px;
        }
        
        .tabela-itens thead th {
          background-color: #f0f0f0;
          padding: 8px;
          text-align: left;
          font-size: 10pt;
          border: 1px solid #ddd;
        }
        
        .tabela-itens tbody td, .tabela-complementos tbody td {
          padding: 8px;
          border: 1px solid #ddd;
          font-size: 10pt;
        }
        
        .tabela-itens tbody tr:nth-child(even) {
          background-color: #f9f9f9;
        }
        
        .observacoes {
          margin: 20px 0;
          padding: 15px;
          background-color: #f9f9f9;
          border-left: 4px solid #D4AF37;
        }
        
        .observacoes h3 {
          font-size: 12pt;
          color: #D4AF37;
          margin-bottom: 8px;
        }
        
        .resumo-financeiro {
          margin-top: 30px;
          text-align: right;
        }
        
        .resumo-financeiro table {
          margin-left: auto;
          border-collapse: collapse;
        }
        
        .resumo-financeiro td {
          padding: 8px 15px;
          font-size: 11pt;
        }
        
        .resumo-financeiro .label {
          text-align: right;
          font-weight: bold;
          color: #555;
        }
        
        .resumo-financeiro .valor {
          text-align: right;
          min-width: 120px;
        }
        
        .resumo-financeiro .total-row {
          border-top: 2px solid #D4AF37;
          font-size: 14pt;
          font-weight: bold;
          color: #D4AF37;
        }
      </style>
    </head>
    <body>
      <div class="header">
        <h1>ORÇAMENTO</h1>
        <div class="empresa-nome">Aliança Auto Center</div>
        <div class="empresa-info">
          Nerópolis QD-01 LT-07 Residencial José Viandeli<br>
          Bairro Balneário Meia Ponte - Goiânia/GO - CEP: 74594-300<br>
          WhatsApp: (62) 9 9662-7364 | E-mail: funilariaalianca10@gmail.com
        </div>
      </div>
      
      <div class="info-section" style="display: table; width: 100%;">
        <div class="info-box" style="display: table-cell; width: 33%;">
          <h3>DADOS DO ORÇAMENTO</h3>
          <p><strong>Número:</strong> ${orcamento.numero}</p>
          <p><strong>Data:</strong> ${formatDate(orcamento.dataEntrada)}</p>
          <p><strong>Status:</strong> ${orcamento.status}</p>
        </div>
        
        <div class="info-box" style="display: table-cell; width: 33%;">
          <h3>CLIENTE</h3>
          <p><strong>Nome:</strong> ${cliente.nome}</p>
          ${cliente.cpfCnpj ? `<p><strong>CPF/CNPJ:</strong> ${cliente.cpfCnpj}</p>` : ''}
          ${cliente.telefone ? `<p><strong>Telefone:</strong> ${cliente.telefone}</p>` : ''}
          ${cliente.email ? `<p><strong>E-mail:</strong> ${cliente.email}</p>` : ''}
        </div>
        
        <div class="info-box" style="display: table-cell; width: 33%;">
          <h3>VEÍCULO</h3>
          <p><strong>Placa:</strong> ${veiculo.placa}</p>
          ${veiculo.marca ? `<p><strong>Marca:</strong> ${veiculo.marca}</p>` : ''}
          ${veiculo.modelo ? `<p><strong>Modelo:</strong> ${veiculo.modelo}</p>` : ''}
          ${veiculo.ano ? `<p><strong>Ano:</strong> ${veiculo.ano}</p>` : ''}
        </div>
      </div>
      
      ${tabelasHTML}
      
      ${complementosHTML}
      
      ${orcamento.observacoes ? `
        <div class="observacoes">
          <h3>OBSERVAÇÕES</h3>
          <p>${orcamento.observacoes}</p>
        </div>
      ` : ''}
      
      <div class="resumo-financeiro">
        <table>
          <tr>
            <td class="label">Subtotal:</td>
            <td class="valor">${formatCurrency(subtotal)}</td>
          </tr>
          ${orcamento.desconto > 0 ? `
            <tr>
              <td class="label">Desconto:</td>
              <td class="valor">- ${formatCurrency(orcamento.desconto)}</td>
            </tr>
          ` : ''}
          ${orcamento.acrescimo > 0 ? `
            <tr>
              <td class="label">Acréscimo:</td>
              <td class="valor">+ ${formatCurrency(orcamento.acrescimo)}</td>
            </tr>
          ` : ''}
          <tr class="total-row">
            <td class="label">TOTAL GERAL:</td>
            <td class="valor">${formatCurrency(orcamento.total)}</td>
          </tr>
        </table>
      </div>
    </body>
    </html>
  `;

  const options = { 
    format: 'A4',
    margin: { top: '20mm', right: '15mm', bottom: '20mm', left: '15mm' }
  };

  const file = { content: html };
  
  // @ts-ignore
  const pdfBuffer = await htmlPdf.generatePdf(file, options);
  
  return pdfBuffer;
}
