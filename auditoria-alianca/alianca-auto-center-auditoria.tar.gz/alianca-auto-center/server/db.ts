import { eq, desc, and, or, like, gte, lte, lt, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { 
  InsertUser, users,
  clientes, InsertCliente,
  veiculos, InsertVeiculo,
  orcamentos, InsertOrcamento,
  itensOrcamento, InsertItemOrcamento,
  complementosOrcamento, InsertComplementoOrcamento,
  ordensServico, InsertOrdemServico,
  notasFiscais, InsertNotaFiscal,
  produtos, InsertProduto,
  movimentacoesEstoque, InsertMovimentacaoEstoque,
  fornecedores, InsertFornecedor,
  pedidosCompra, InsertPedidoCompra,
  itensPedidoCompra, InsertItemPedidoCompra,
  agendamentos, InsertAgendamento,
  contasPagar, InsertContaPagar,
  contasReceber, InsertContaReceber,
  midiasOrcamento, InsertMidiaOrcamento,
  colaboradores, InsertColaborador,
  adiantamentos, InsertAdiantamento,
  orcamentosExternos, InsertOrcamentoExterno
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ============ USERS ============
export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    // Sempre forçar admin para o dono do projeto
    if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
      values.nivelAcesso = 'admin';
      updateSet.nivelAcesso = 'admin';
      values.ativo = true;
      updateSet.ativo = true;
    } else if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ============ CLIENTES ============
export async function createCliente(data: InsertCliente) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(clientes).values(data).$returningId();
  return result[0].id;
}

export async function getClientes() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(clientes).orderBy(desc(clientes.createdAt));
}

export async function getClienteById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(clientes).where(eq(clientes.id, id)).limit(1);
  return result[0];
}

export async function updateCliente(id: number, data: Partial<InsertCliente>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.update(clientes).set(data).where(eq(clientes.id, id));
}

export async function deleteCliente(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.delete(clientes).where(eq(clientes.id, id));
}

// ============ VEÍCULOS ============
export async function createVeiculo(data: InsertVeiculo) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(veiculos).values(data).$returningId();
  return result[0].id;
}

export async function getVeiculos(clienteId?: number) {
  const db = await getDb();
  if (!db) return [];
  if (clienteId) {
    return await db.select().from(veiculos).where(eq(veiculos.clienteId, clienteId)).orderBy(desc(veiculos.createdAt));
  }
  return await db.select().from(veiculos).orderBy(desc(veiculos.createdAt));
}

export async function getVeiculoById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(veiculos).where(eq(veiculos.id, id)).limit(1);
  return result[0];
}

export async function updateVeiculo(id: number, data: Partial<InsertVeiculo>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.update(veiculos).set(data).where(eq(veiculos.id, id));
}

export async function deleteVeiculo(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.delete(veiculos).where(eq(veiculos.id, id));
}

export async function updateVeiculoStatus(id: number, status: "aguardando_orcamento" | "orcamento_pendente" | "aprovado" | "em_execucao" | "finalizado" | "entregue") {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.update(veiculos).set({ status }).where(eq(veiculos.id, id));
}

// ============ ORÇAMENTOS ============
export async function createOrcamento(data: InsertOrcamento) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(orcamentos).values(data).$returningId();
  return result[0].id;
}

export async function getOrcamentos(filters?: { status?: string; search?: string; placa?: string }) {
  const db = await getDb();
  if (!db) return [];
  
  // JOIN com veículos e clientes para trazer dados completos
  let query = db.select({
    id: orcamentos.id,
    numero: orcamentos.numero,
    clienteId: orcamentos.clienteId,
    veiculoId: orcamentos.veiculoId,
    dataEntrada: orcamentos.dataEntrada,
    prazoEntrega: orcamentos.prazoEntrega,
    numeroOS: orcamentos.numeroOS,
    status: orcamentos.status,
    observacoes: orcamentos.observacoes,
    desconto: orcamentos.desconto,
    acrescimo: orcamentos.acrescimo,
    subtotalItens: orcamentos.subtotalItens,
    subtotalComplementos: orcamentos.subtotalComplementos,
    total: orcamentos.total,
    createdAt: orcamentos.createdAt,
    updatedAt: orcamentos.updatedAt,
    veiculoPlaca: veiculos.placa,
    veiculoModelo: veiculos.modelo,
    veiculoAno: veiculos.ano,
  }).from(orcamentos)
    .leftJoin(veiculos, eq(orcamentos.veiculoId, veiculos.id));
  
  const conditions = [];
  if (filters?.status) {
    conditions.push(eq(orcamentos.status, filters.status as any));
  }
  if (filters?.search) {
    conditions.push(
      or(
        like(orcamentos.numero, `%${filters.search}%`),
        like(orcamentos.numeroOS, `%${filters.search}%`)
      )!
    );
  }
  
  // Filtro por placa do veículo
  if (filters?.placa) {
    // Buscar IDs dos veículos que correspondem à placa
    const veiculosComPlaca = await db.select({ id: veiculos.id })
      .from(veiculos)
      .where(like(veiculos.placa, `%${filters.placa}%`));
    
    const veiculoIds = veiculosComPlaca.map(v => v.id);
    
    if (veiculoIds.length > 0) {
      conditions.push(
        or(...veiculoIds.map(id => eq(orcamentos.veiculoId, id)))!
      );
    } else {
      // Se não encontrou nenhum veículo com a placa, retorna vazio
      return [];
    }
  }
  
  if (conditions.length > 0) {
    query = query.where(and(...conditions)!) as any;
  }
  
  return await (query as any).orderBy(desc(orcamentos.createdAt));
}

export async function getOrcamentoById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(orcamentos).where(eq(orcamentos.id, id)).limit(1);
  return result[0];
}

export async function updateOrcamento(id: number, data: Partial<InsertOrcamento>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.update(orcamentos).set(data).where(eq(orcamentos.id, id));
}

export async function deleteOrcamento(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  // Delete related items first
  await db.delete(itensOrcamento).where(eq(itensOrcamento.orcamentoId, id));
  await db.delete(complementosOrcamento).where(eq(complementosOrcamento.orcamentoId, id));
  return await db.delete(orcamentos).where(eq(orcamentos.id, id));
}

// ============ ITENS ORÇAMENTO ============
export async function createItemOrcamento(data: InsertItemOrcamento) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.insert(itensOrcamento).values(data);
}

export async function getItensOrcamento(orcamentoId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(itensOrcamento).where(eq(itensOrcamento.orcamentoId, orcamentoId));
}

export async function deleteItemOrcamento(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.delete(itensOrcamento).where(eq(itensOrcamento.id, id));
}

// ============ COMPLEMENTOS ORÇAMENTO ============
export async function createComplementoOrcamento(data: InsertComplementoOrcamento) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.insert(complementosOrcamento).values(data);
}

export async function getComplementosOrcamento(orcamentoId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(complementosOrcamento).where(eq(complementosOrcamento.orcamentoId, orcamentoId));
}

export async function deleteComplementoOrcamento(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.delete(complementosOrcamento).where(eq(complementosOrcamento.id, id));
}

// ============ ORDENS DE SERVIÇO ============
export async function createOrdemServico(data: InsertOrdemServico) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.insert(ordensServico).values(data);
}

export async function getOrdensServico(filters?: { status?: string; search?: string }) {
  const db = await getDb();
  if (!db) return [];
  
  let query = db.select().from(ordensServico);
  
  const conditions = [];
  if (filters?.status) {
    conditions.push(eq(ordensServico.status, filters.status as any));
  }
  if (filters?.search) {
    conditions.push(
      or(
        like(ordensServico.numero, `%${filters.search}%`),
        like(ordensServico.numeroOSCliente, `%${filters.search}%`)
      )!
    );
  }
  
  if (conditions.length > 0) {
    query = query.where(and(...conditions)!) as any;
  }
  
  return await query.orderBy(desc(ordensServico.createdAt));
}

export async function getOrdemServicoById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(ordensServico).where(eq(ordensServico.id, id)).limit(1);
  return result[0];
}

export async function updateOrdemServico(id: number, data: Partial<InsertOrdemServico>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.update(ordensServico).set(data).where(eq(ordensServico.id, id));
}

// ============ PRODUTOS ============
export async function createProduto(data: InsertProduto) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.insert(produtos).values(data);
}

export async function getProdutos(filters?: { categoria?: string; search?: string; ativo?: boolean }) {
  const db = await getDb();
  if (!db) return [];
  
  let query = db.select().from(produtos);
  
  const conditions = [];
  if (filters?.categoria) {
    conditions.push(eq(produtos.categoria, filters.categoria as any));
  }
  if (filters?.ativo !== undefined) {
    conditions.push(eq(produtos.ativo, filters.ativo));
  }
  if (filters?.search) {
    conditions.push(
      or(
        like(produtos.codigo, `%${filters.search}%`),
        like(produtos.descricao, `%${filters.search}%`)
      )!
    );
  }
  
  if (conditions.length > 0) {
    query = query.where(and(...conditions)!) as any;
  }
  
  return await query.orderBy(desc(produtos.createdAt));
}

export async function getProdutoById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(produtos).where(eq(produtos.id, id)).limit(1);
  return result[0];
}

export async function updateProduto(id: number, data: Partial<InsertProduto>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.update(produtos).set(data).where(eq(produtos.id, id));
}

export async function movimentarEstoque(data: { produtoId: number; tipo: 'entrada' | 'saida' | 'ajuste'; quantidade: number; motivo?: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  // Buscar produto atual
  const produto = await getProdutoById(data.produtoId);
  if (!produto) throw new Error("Produto não encontrado");
  
  // Calcular novo estoque
  let novoEstoque = produto.estoqueAtual;
  if (data.tipo === 'entrada') {
    novoEstoque += data.quantidade;
  } else if (data.tipo === 'saida') {
    novoEstoque -= data.quantidade;
    if (novoEstoque < 0) throw new Error("Estoque insuficiente");
  } else if (data.tipo === 'ajuste') {
    novoEstoque = data.quantidade;
  }
  
  // Atualizar estoque do produto
  await db.update(produtos).set({ estoqueAtual: novoEstoque }).where(eq(produtos.id, data.produtoId));
  
  // Registrar movimentação
  await db.insert(movimentacoesEstoque).values({
    produtoId: data.produtoId,
    tipo: data.tipo,
    quantidade: data.quantidade,
    valorUnitario: produto.valorCusto,
    motivo: data.motivo,
  });
  
  return { success: true, novoEstoque };
}

// ============ FORNECEDORES ============
export async function createFornecedor(data: InsertFornecedor) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.insert(fornecedores).values(data);
}

export async function getFornecedores(ativo?: boolean) {
  const db = await getDb();
  if (!db) return [];
  
  if (ativo !== undefined) {
    return await db.select().from(fornecedores).where(eq(fornecedores.ativo, ativo)).orderBy(desc(fornecedores.createdAt));
  }
  return await db.select().from(fornecedores).orderBy(desc(fornecedores.createdAt));
}

export async function getFornecedorById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(fornecedores).where(eq(fornecedores.id, id)).limit(1);
  return result[0];
}

export async function updateFornecedor(id: number, data: Partial<InsertFornecedor>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.update(fornecedores).set(data).where(eq(fornecedores.id, id));
}

// ============ AGENDAMENTOS ============
export async function createAgendamento(data: InsertAgendamento) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.insert(agendamentos).values(data);
}

export async function getAgendamentos(filters?: { dataInicio?: Date; dataFim?: Date; status?: string }) {
  const db = await getDb();
  if (!db) return [];
  
  let query = db.select().from(agendamentos);
  
  const conditions = [];
  if (filters?.dataInicio) {
    conditions.push(gte(agendamentos.dataHora, filters.dataInicio));
  }
  if (filters?.dataFim) {
    conditions.push(lte(agendamentos.dataHora, filters.dataFim));
  }
  if (filters?.status) {
    conditions.push(eq(agendamentos.status, filters.status as any));
  }
  
  if (conditions.length > 0) {
    query = query.where(and(...conditions)!) as any;
  }
  
  return await query.orderBy(agendamentos.dataHora);
}

export async function updateAgendamento(id: number, data: Partial<InsertAgendamento>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.update(agendamentos).set(data).where(eq(agendamentos.id, id));
}

// ============ CONTAS A PAGAR ============
export async function createContaPagar(data: InsertContaPagar) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.insert(contasPagar).values(data);
}

export async function getContasPagar(filters?: { status?: string; dataInicio?: Date; dataFim?: Date }) {
  const db = await getDb();
  if (!db) return [];
  
  let query = db
    .select({
      id: contasPagar.id,
      descricao: contasPagar.descricao,
      valor: contasPagar.valor,
      dataEmissao: contasPagar.dataEmissao,
      dataVencimento: contasPagar.dataVencimento,
      dataPagamento: contasPagar.dataPagamento,
      status: contasPagar.status,
      categoria: contasPagar.categoria,
      observacoes: contasPagar.observacoes,
      fornecedorId: contasPagar.fornecedorId,
      fornecedor: fornecedores,
    })
    .from(contasPagar)
    .leftJoin(fornecedores, eq(contasPagar.fornecedorId, fornecedores.id));
  
  const conditions = [];
  if (filters?.status) {
    conditions.push(eq(contasPagar.status, filters.status as any));
  }
  if (filters?.dataInicio) {
    conditions.push(gte(contasPagar.dataVencimento, filters.dataInicio));
  }
  if (filters?.dataFim) {
    conditions.push(lte(contasPagar.dataVencimento, filters.dataFim));
  }
  
  if (conditions.length > 0) {
    query = query.where(and(...conditions)!) as any;
  }
  
  return await query.orderBy(contasPagar.dataVencimento);
}

export async function updateContaPagar(id: number, data: Partial<InsertContaPagar>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.update(contasPagar).set(data).where(eq(contasPagar.id, id));
}

// ============ CONTAS A RECEBER ============
export async function createContaReceber(data: InsertContaReceber) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.insert(contasReceber).values(data);
}

export async function getContasReceber(filters?: { status?: string; dataInicio?: Date; dataFim?: Date; clienteNome?: string }) {
  const db = await getDb();
  if (!db) return [];
  
  let query = db
    .select({
      id: contasReceber.id,
      descricao: contasReceber.descricao,
      valor: contasReceber.valor,
      dataEmissao: contasReceber.dataEmissao,
      dataVencimento: contasReceber.dataVencimento,
      dataRecebimento: contasReceber.dataRecebimento,
      status: contasReceber.status,
      observacoes: contasReceber.observacoes,
      clienteId: contasReceber.clienteId,
      orcamentoId: contasReceber.orcamentoId,
      cliente: clientes,
      orcamento: orcamentos,
      veiculo: veiculos,
    })
    .from(contasReceber)
    .leftJoin(clientes, eq(contasReceber.clienteId, clientes.id))
    .leftJoin(orcamentos, eq(contasReceber.orcamentoId, orcamentos.id))
    .leftJoin(veiculos, eq(orcamentos.veiculoId, veiculos.id));
  
  const conditions = [];
  if (filters?.status) {
    conditions.push(eq(contasReceber.status, filters.status as any));
  }
  if (filters?.dataInicio) {
    conditions.push(gte(contasReceber.dataVencimento, filters.dataInicio));
  }
  if (filters?.dataFim) {
    conditions.push(lte(contasReceber.dataVencimento, filters.dataFim));
  }
  if (filters?.clienteNome) {
    conditions.push(sql`${clientes.nome} LIKE ${`%${filters.clienteNome}%`}`);
  }
  
  if (conditions.length > 0) {
    query = query.where(and(...conditions)!) as any;
  }
  
  return await query.orderBy(contasReceber.dataVencimento);
}

export async function updateContaReceber(id: number, data: Partial<InsertContaReceber>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.update(contasReceber).set(data).where(eq(contasReceber.id, id));
}

// ============ DASHBOARD STATS ============
export async function getDashboardStats() {
  const db = await getDb();
  if (!db) return null;
  
  const [
    totalOrcamentos,
    orcamentosPendentes,
    totalOS,
    osEmExecucao,
    osConcluidas,
    contasReceberPendentes,
    contasPagarPendentes,
    produtosEstoqueBaixo
  ] = await Promise.all([
    db.select({ count: sql<number>`count(*)` }).from(orcamentos),
    db.select({ count: sql<number>`count(*)` }).from(orcamentos).where(eq(orcamentos.status, 'pendente')),
    db.select({ count: sql<number>`count(*)` }).from(ordensServico),
    db.select({ count: sql<number>`count(*)` }).from(ordensServico).where(eq(ordensServico.status, 'em_execucao')),
    db.select({ count: sql<number>`count(*)` }).from(ordensServico).where(eq(ordensServico.status, 'concluido')),
    db.select({ 
      total: sql<number>`COALESCE(SUM(valor), 0)`,
      count: sql<number>`count(*)`
    }).from(contasReceber).where(eq(contasReceber.status, 'pendente')),
    db.select({ 
      total: sql<number>`COALESCE(SUM(valor), 0)`,
      count: sql<number>`count(*)`
    }).from(contasPagar).where(eq(contasPagar.status, 'pendente')),
    db.select({ count: sql<number>`count(*)` }).from(produtos).where(
      and(
        eq(produtos.ativo, true),
        sql`${produtos.estoqueAtual} <= ${produtos.estoqueMinimo}`
      )!
    )
  ]);
  
  return {
    orcamentos: {
      total: totalOrcamentos[0].count,
      pendentes: orcamentosPendentes[0].count
    },
    ordensServico: {
      total: totalOS[0].count,
      emExecucao: osEmExecucao[0].count,
      concluidas: osConcluidas[0].count
    },
    financeiro: {
      aReceber: {
        total: contasReceberPendentes[0].total,
        quantidade: contasReceberPendentes[0].count
      },
      aPagar: {
        total: contasPagarPendentes[0].total,
        quantidade: contasPagarPendentes[0].count
      }
    },
    estoque: {
      produtosBaixos: produtosEstoqueBaixo[0].count
    }
  };
}

// ============ MÍDIAS ============
export async function createMidia(data: {
  orcamentoId: number;
  tipo: 'foto' | 'video';
  url: string;
  fileKey: string;
  fileName?: string;
  fileSize?: number;
  mimeType?: string;
  descricao?: string;
}) {
  const database = await getDb();
  if (!database) throw new Error("Database not available");

  const [result] = await database.insert(midiasOrcamento).values(data);
  return result;
}

export async function getMidiasByOrcamento(orcamentoId: number) {
  const database = await getDb();
  if (!database) throw new Error("Database not available");

  return database.select().from(midiasOrcamento).where(eq(midiasOrcamento.orcamentoId, orcamentoId));
}

// ============ RELATÓRIOS FINANCEIROS ============

/**
 * Retorna faturamento mensal dos últimos 12 meses
 */
export async function getFaturamentoMensal() {
  const database = await getDb();
  if (!database) throw new Error("Database not available");

  // Buscar orçamentos concluídos dos últimos 12 meses
  const dozeMesesAtras = new Date();
  dozeMesesAtras.setMonth(dozeMesesAtras.getMonth() - 12);

  const result = await database
    .select({
      mes: sql<string>`DATE_FORMAT(${orcamentos.dataEntrada}, '%Y-%m')`,
      total: sql<number>`SUM(${orcamentos.total})`,
      quantidade: sql<number>`COUNT(*)`,
    })
    .from(orcamentos)
    .where(
      and(
        eq(orcamentos.status, 'concluido'),
        gte(orcamentos.dataEntrada, dozeMesesAtras)
      )
    )
    .groupBy(sql`DATE_FORMAT(${orcamentos.dataEntrada}, '%Y-%m')`)
    .orderBy(sql`DATE_FORMAT(${orcamentos.dataEntrada}, '%Y-%m')`);

  return result;
}

/**
 * Retorna funil de vendas (orçamentos criados, aprovados, rejeitados, concluídos)
 */
export async function getFunilVendas() {
  const database = await getDb();
  if (!database) throw new Error("Database not available");

  const [total] = await database
    .select({ count: sql<number>`COUNT(*)` })
    .from(orcamentos);

  const [pendentes] = await database
    .select({ count: sql<number>`COUNT(*)` })
    .from(orcamentos)
    .where(eq(orcamentos.status, 'pendente'));

  const [aprovados] = await database
    .select({ count: sql<number>`COUNT(*)` })
    .from(orcamentos)
    .where(eq(orcamentos.status, 'aprovado'));

  const [rejeitados] = await database
    .select({ count: sql<number>`COUNT(*)` })
    .from(orcamentos)
    .where(eq(orcamentos.status, 'rejeitado'));

  const [concluidos] = await database
    .select({ count: sql<number>`COUNT(*)` })
    .from(orcamentos)
    .where(eq(orcamentos.status, 'concluido'));

  const [valorTotal] = await database
    .select({ total: sql<number>`SUM(${orcamentos.total})` })
    .from(orcamentos);

  const [valorAprovado] = await database
    .select({ total: sql<number>`SUM(${orcamentos.total})` })
    .from(orcamentos)
    .where(eq(orcamentos.status, 'aprovado'));

  const [valorConcluido] = await database
    .select({ total: sql<number>`SUM(${orcamentos.total})` })
    .from(orcamentos)
    .where(eq(orcamentos.status, 'concluido'));

  const taxaConversao = total.count > 0 
    ? ((aprovados.count + concluidos.count) / total.count) * 100 
    : 0;

  return {
    total: total.count,
    pendentes: pendentes.count,
    aprovados: aprovados.count,
    rejeitados: rejeitados.count,
    concluidos: concluidos.count,
    taxaConversao: Math.round(taxaConversao * 100) / 100,
    valorTotal: valorTotal.total || 0,
    valorAprovado: valorAprovado.total || 0,
    valorConcluido: valorConcluido.total || 0,
  };
}

/**
 * Retorna análise de clientes (ranking, inadimplentes, etc)
 */
export async function getAnaliseClientes() {
  const database = await getDb();
  if (!database) throw new Error("Database not available");

  // Ranking de clientes por valor total em orçamentos
  const ranking = await database
    .select({
      clienteId: clientes.id,
      clienteNome: clientes.nome,
      totalOrcamentos: sql<number>`COUNT(DISTINCT ${orcamentos.id})`,
      valorTotal: sql<number>`SUM(${orcamentos.total})`,
    })
    .from(clientes)
    .leftJoin(orcamentos, eq(orcamentos.clienteId, clientes.id))
    .groupBy(clientes.id, clientes.nome)
    .orderBy(sql`SUM(${orcamentos.total}) DESC`)
    .limit(10);

  // Clientes inadimplentes (com contas vencidas)
  const hoje = new Date();
  const inadimplentes = await database
    .select({
      clienteId: clientes.id,
      clienteNome: clientes.nome,
      totalVencido: sql<number>`SUM(${contasReceber.valor})`,
      quantidadeContas: sql<number>`COUNT(*)`,
    })
    .from(contasReceber)
    .innerJoin(orcamentos, eq(contasReceber.orcamentoId, orcamentos.id))
    .innerJoin(clientes, eq(orcamentos.clienteId, clientes.id))
    .where(
      and(
        eq(contasReceber.status, 'pendente'),
        lt(contasReceber.dataVencimento, hoje)
      )
    )
    .groupBy(clientes.id, clientes.nome)
    .orderBy(sql`SUM(${contasReceber.valor}) DESC`)
    .limit(10);

  // Total de clientes com contas pendentes
  const [clientesPendentes] = await database
    .select({
      count: sql<number>`COUNT(DISTINCT ${clientes.id})`,
      totalPendente: sql<number>`SUM(${contasReceber.valor})`,
    })
    .from(contasReceber)
    .innerJoin(orcamentos, eq(contasReceber.orcamentoId, orcamentos.id))
    .innerJoin(clientes, eq(orcamentos.clienteId, clientes.id))
    .where(eq(contasReceber.status, 'pendente'));

  return {
    ranking,
    inadimplentes,
    totalClientesPendentes: clientesPendentes.count,
    totalValorPendente: clientesPendentes.totalPendente || 0,
  };
}

/**
 * Retorna fluxo de caixa (entradas e saídas) por período
 */
export async function getFluxoCaixa(params?: { dataInicio?: Date; dataFim?: Date }) {
  const database = await getDb();
  if (!database) throw new Error("Database not available");

  const dataInicio = params?.dataInicio || (() => {
    const d = new Date();
    d.setDate(1); // Primeiro dia do mês
    return d;
  })();

  const dataFim = params?.dataFim || new Date();

  // Entradas (contas recebidas)
  const [entradas] = await database
    .select({
      total: sql<number>`SUM(${contasReceber.valor})`,
      quantidade: sql<number>`COUNT(*)`,
    })
    .from(contasReceber)
    .where(
      and(
        eq(contasReceber.status, 'recebido'),
        gte(contasReceber.dataEmissao, dataInicio),
        lte(contasReceber.dataEmissao, dataFim)
      )
    );

  // Saídas (contas pagas)
  const [saidas] = await database
    .select({
      total: sql<number>`SUM(${contasPagar.valor})`,
      quantidade: sql<number>`COUNT(*)`,
    })
    .from(contasPagar)
    .where(
      and(
        eq(contasPagar.status, 'pago'),
        gte(contasPagar.dataEmissao, dataInicio),
        lte(contasPagar.dataEmissao, dataFim)
      )
    );

  // Entradas por dia (para gráfico)
  const entradasPorDia = await database
    .select({
      data: sql<string>`DATE(${contasReceber.dataEmissao})`,
      total: sql<number>`SUM(${contasReceber.valor})`,
    })
    .from(contasReceber)
    .where(
      and(
        eq(contasReceber.status, 'recebido'),
        gte(contasReceber.dataEmissao, dataInicio),
        lte(contasReceber.dataEmissao, dataFim)
      )
    )
    .groupBy(sql`DATE(${contasReceber.dataEmissao})`)
    .orderBy(sql`DATE(${contasReceber.dataEmissao})`);

  // Saídas por dia (para gráfico)
  const saidasPorDia = await database
    .select({
      data: sql<string>`DATE(${contasPagar.dataEmissao})`,
      total: sql<number>`SUM(${contasPagar.valor})`,
    })
    .from(contasPagar)
    .where(
      and(
        eq(contasPagar.status, 'pago'),
        gte(contasPagar.dataEmissao, dataInicio),
        lte(contasPagar.dataEmissao, dataFim)
      )
    )
    .groupBy(sql`DATE(${contasPagar.dataEmissao})`)
    .orderBy(sql`DATE(${contasPagar.dataEmissao})`);

  const totalEntradas = entradas.total || 0;
  const totalSaidas = saidas.total || 0;
  const saldo = totalEntradas - totalSaidas;

  return {
    totalEntradas,
    totalSaidas,
    saldo,
    quantidadeEntradas: entradas.quantidade,
    quantidadeSaidas: saidas.quantidade,
    entradasPorDia,
    saidasPorDia,
  };
}


// ============================================
// COLABORADORES
// ============================================

export async function getAllColaboradores() {
  const database = await getDb();
  if (!database) return [];
  
  return await database.select().from(colaboradores).orderBy(colaboradores.nome);
}

export async function getColaboradorById(id: number) {
  const database = await getDb();
  if (!database) return undefined;
  
  const result = await database.select().from(colaboradores).where(eq(colaboradores.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createColaborador(data: InsertColaborador) {
  const database = await getDb();
  if (!database) throw new Error("Database not available");
  
  const result = await database.insert(colaboradores).values(data);
  return result[0].insertId;
}

export async function updateColaborador(id: number, data: Partial<InsertColaborador>) {
  const database = await getDb();
  if (!database) throw new Error("Database not available");
  
  await database.update(colaboradores).set(data).where(eq(colaboradores.id, id));
}

export async function deleteColaborador(id: number) {
  const database = await getDb();
  if (!database) throw new Error("Database not available");
  
  await database.delete(colaboradores).where(eq(colaboradores.id, id));
}

export async function getColaboradoresAtivos() {
  const database = await getDb();
  if (!database) return [];
  
  return await database.select().from(colaboradores).where(eq(colaboradores.status, 'ativo')).orderBy(colaboradores.nome);
}

// Calcular próximos pagamentos de colaboradores
export async function getProximosPagamentosColaboradores() {
  const database = await getDb();
  if (!database) return [];
  
  const colaboradoresAtivos = await getColaboradoresAtivos();
  const hoje = new Date();
  const diasSemana = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];
  
  return colaboradoresAtivos.map(colab => {
    let proximoPagamento = new Date();
    let diasRestantes = 0;
    
    if (colab.tipoPagamento === 'semanal') {
      // Calcular próximo dia da semana
      const diaAtual = hoje.getDay();
      const diaAlvo = colab.diaPagamento;
      let diff = diaAlvo - diaAtual;
      if (diff <= 0) diff += 7;
      proximoPagamento.setDate(hoje.getDate() + diff);
      diasRestantes = diff;
    } else if (colab.tipoPagamento === 'quinzenal') {
      // Próximo dia 15 ou próximo dia especificado
      const diaAtual = hoje.getDate();
      const diaAlvo = colab.diaPagamento;
      if (diaAtual < diaAlvo) {
        proximoPagamento.setDate(diaAlvo);
      } else {
        proximoPagamento.setMonth(proximoPagamento.getMonth() + 1);
        proximoPagamento.setDate(diaAlvo);
      }
      diasRestantes = Math.ceil((proximoPagamento.getTime() - hoje.getTime()) / (1000 * 60 * 60 * 24));
    } else { // mensal
      const diaAtual = hoje.getDate();
      const diaAlvo = colab.diaPagamento;
      if (diaAtual < diaAlvo) {
        proximoPagamento.setDate(diaAlvo);
      } else {
        proximoPagamento.setMonth(proximoPagamento.getMonth() + 1);
        proximoPagamento.setDate(diaAlvo);
      }
      diasRestantes = Math.ceil((proximoPagamento.getTime() - hoje.getTime()) / (1000 * 60 * 60 * 24));
    }
    
    return {
      ...colab,
      proximoPagamento,
      diasRestantes,
      diaPagamentoNome: colab.tipoPagamento === 'semanal' ? diasSemana[colab.diaPagamento] : `Dia ${colab.diaPagamento}`,
    };
  });
}


// ==================== ADIANTAMENTOS ====================

export async function createAdiantamento(data: {
  colaboradorId: number;
  valor: number;
  dataAdiantamento: Date;
  descricao?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.insert(adiantamentos).values({
    colaboradorId: data.colaboradorId,
    valor: data.valor,
    dataAdiantamento: data.dataAdiantamento,
    descricao: data.descricao,
    descontado: false,
  });
  
  return { success: true };
}

export async function getAdiantamentosPendentes(colaboradorId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(adiantamentos)
    .where(and(
      eq(adiantamentos.colaboradorId, colaboradorId),
      eq(adiantamentos.descontado, false)
    ));
}

export async function marcarAdiantamentoDescontado(adiantamentoId: number, contaPagarId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(adiantamentos)
    .set({ descontado: true, contaPagarId })
    .where(eq(adiantamentos.id, adiantamentoId));
}

// ==================== GERAÇÃO DE PAGAMENTOS ====================

export async function gerarPagamentoColaborador(colaboradorId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  // Buscar colaborador
  const colaborador = await db.select().from(colaboradores)
    .where(eq(colaboradores.id, colaboradorId))
    .limit(1);
  
  if (colaborador.length === 0) {
    throw new Error("Colaborador não encontrado");
  }
  
  const colab = colaborador[0];
  if (colab.status !== 'ativo') {
    throw new Error("Colaborador inativo");
  }
  
  // Calcular próxima data de pagamento
  const hoje = new Date();
  const proximoPagamento = new Date(hoje);
  
  if (colab.tipoPagamento === 'semanal') {
    // Próximo dia da semana especificado
    const diasAte = (colab.diaPagamento - proximoPagamento.getDay() + 7) % 7;
    proximoPagamento.setDate(proximoPagamento.getDate() + (diasAte === 0 ? 7 : diasAte));
  } else if (colab.tipoPagamento === 'quinzenal') {
    // Próximo dia 15 ou último dia do mês
    if (proximoPagamento.getDate() < 15) {
      proximoPagamento.setDate(15);
    } else {
      proximoPagamento.setMonth(proximoPagamento.getMonth() + 1, 0); // Último dia do mês
    }
  } else { // mensal
    // Próximo dia especificado do mês
    proximoPagamento.setDate(colab.diaPagamento);
    if (proximoPagamento <= hoje) {
      proximoPagamento.setMonth(proximoPagamento.getMonth() + 1);
    }
  }
  
  // Buscar adiantamentos pendentes
  const adiantamentosPendentes = await getAdiantamentosPendentes(colaboradorId);
  const totalAdiantamentos = adiantamentosPendentes.reduce((sum, a) => sum + a.valor, 0);
  
  // Calcular valor líquido
  const valorLiquido = colab.salario - totalAdiantamentos;
  
  if (valorLiquido <= 0) {
    throw new Error("Salário totalmente descontado por adiantamentos");
  }
  
  // Criar conta a pagar
  await db.insert(contasPagar).values({
    descricao: `Salário - ${colab.nome} (${colab.cargo})`,
    colaboradorId: colaboradorId,
    valor: valorLiquido,
    dataEmissao: hoje,
    dataVencimento: proximoPagamento,
    status: 'pendente',
    categoria: 'Salários',
    formaPagamento: 'PIX',
    observacoes: totalAdiantamentos > 0 
      ? `Valor original: R$ ${(colab.salario / 100).toFixed(2)} - Adiantamentos: R$ ${(totalAdiantamentos / 100).toFixed(2)}`
      : undefined,
  });
  
  // Buscar a conta recém criada
  const contas = await db.select().from(contasPagar)
    .where(eq(contasPagar.colaboradorId, colaboradorId))
    .orderBy(desc(contasPagar.createdAt))
    .limit(1);
  
  const contaPagarId = contas[0]?.id || 0;
  
  // Marcar adiantamentos como descontados
  for (const adiantamento of adiantamentosPendentes) {
    await marcarAdiantamentoDescontado(adiantamento.id, contaPagarId);
  }
  
  return { id: contaPagarId, valorLiquido, totalAdiantamentos };
}

export async function getHistoricoPagamentosColaborador(colaboradorId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(contasPagar)
    .where(eq(contasPagar.colaboradorId, colaboradorId))
    .orderBy(desc(contasPagar.dataVencimento));
}


// ========== Orçamentos Externos ==========
export async function getAllOrcamentosExternos() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(orcamentosExternos).orderBy(desc(orcamentosExternos.createdAt));
}

export async function getOrcamentoExternoById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(orcamentosExternos).where(eq(orcamentosExternos.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createOrcamentoExterno(data: InsertOrcamentoExterno) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const [result] = await db.insert(orcamentosExternos).values(data).$returningId();
  return { id: result.id };
}

export async function updateOrcamentoExterno(id: number, data: Partial<InsertOrcamentoExterno>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(orcamentosExternos).set(data).where(eq(orcamentosExternos.id, id));
  return { success: true };
}

export async function deleteOrcamentoExterno(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(orcamentosExternos).where(eq(orcamentosExternos.id, id));
  return { success: true };
}


// ========== Gestão de Usuários e Permissões ==========
export async function getAllUsers() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(users).orderBy(desc(users.createdAt));
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserByEmail(email: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.email, email)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createUser(data: {
  email: string;
  name?: string;
  nivelAcesso?: "admin" | "gerente" | "atendente" | "mecanico" | "financeiro" | "personalizado";
  permissoes?: string; // JSON string
  ativo?: boolean;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  // Gerar openId único baseado no email (para usuários criados manualmente)
  const openId = `manual_${data.email}_${Date.now()}`;
  
  const [result] = await db.insert(users).values({
    openId,
    email: data.email,
    name: data.name || data.email.split('@')[0],
    nivelAcesso: data.nivelAcesso || "atendente",
    permissoes: data.permissoes || null,
    ativo: data.ativo !== undefined ? data.ativo : true,
    role: data.nivelAcesso === "admin" ? "admin" : "user",
  }).$returningId();
  
  return { id: result.id };
}

export async function updateUserPermissions(id: number, data: {
  nivelAcesso?: "admin" | "gerente" | "atendente" | "mecanico" | "financeiro" | "personalizado";
  permissoes?: string; // JSON string
  ativo?: boolean;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const updateData: any = {};
  if (data.nivelAcesso !== undefined) {
    updateData.nivelAcesso = data.nivelAcesso;
    updateData.role = data.nivelAcesso === "admin" ? "admin" : "user";
  }
  if (data.permissoes !== undefined) updateData.permissoes = data.permissoes;
  if (data.ativo !== undefined) updateData.ativo = data.ativo;
  
  await db.update(users).set(updateData).where(eq(users.id, id));
  return { success: true };
}

export async function deleteUser(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(users).where(eq(users.id, id));
  return { success: true };
}

export async function toggleUserStatus(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const user = await getUserById(id);
  if (!user) throw new Error("User not found");
  
  await db.update(users).set({ ativo: !user.ativo }).where(eq(users.id, id));
  return { success: true, ativo: !user.ativo };
}
