import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import * as db from "./db";
import { invokeLLM } from "./_core/llm";
import { storagePut } from "./storage";

// Helper para gerar números sequenciais
function gerarNumero(prefixo: string, contador: number): string {
  const ano = new Date().getFullYear();
  return `${prefixo}-${ano}-${String(contador).padStart(4, '0')}`;
}

export const appRouter = router({
  system: systemRouter,
  
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ============ DASHBOARD ============
  dashboard: router({
    stats: protectedProcedure.query(async () => {
      return await db.getDashboardStats();
    }),
  }),

  // ============ CLIENTES ============
  clientes: router({
    list: protectedProcedure.query(async () => {
      return await db.getClientes();
    }),
    
    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return await db.getClienteById(input.id);
      }),
    
    create: protectedProcedure
      .input(z.object({
        nome: z.string(),
        cpfCnpj: z.string().optional(),
        telefone: z.string().optional(),
        email: z.string().optional(),
        endereco: z.string().optional(),
        cidade: z.string().optional(),
        estado: z.string().optional(),
        cep: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const id = await db.createCliente(input);
        return { success: true, id };
      }),
    
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        nome: z.string().optional(),
        cpfCnpj: z.string().optional(),
        telefone: z.string().optional(),
        email: z.string().optional(),
        endereco: z.string().optional(),
        cidade: z.string().optional(),
        estado: z.string().optional(),
        cep: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await db.updateCliente(id, data);
        return { success: true };
      }),
    
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteCliente(input.id);
        return { success: true };
      }),
  }),

  // ============ VEÍCULOS ============
  veiculos: router({
    list: protectedProcedure
      .input(z.object({ clienteId: z.number().optional() }).optional())
      .query(async ({ input }) => {
        return await db.getVeiculos(input?.clienteId);
      }),
    
    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return await db.getVeiculoById(input.id);
      }),
    
    create: protectedProcedure
      .input(z.object({
        clienteId: z.number(),
        placa: z.string(),
        marca: z.string().optional(),
        modelo: z.string(),
        ano: z.number().optional(),
        cor: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const id = await db.createVeiculo(input);
        return { success: true, id };
      }),
    
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        placa: z.string().optional(),
        marca: z.string().optional(),
        modelo: z.string().optional(),
        ano: z.number().optional(),
        cor: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await db.updateVeiculo(id, data);
        return { success: true };
      }),
    
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteVeiculo(input.id);
        return { success: true };
      }),
    
    updateStatus: protectedProcedure
      .input(z.object({
        id: z.number(),
        status: z.enum(["aguardando_orcamento", "orcamento_pendente", "aprovado", "em_execucao", "finalizado", "entregue"])
      }))
      .mutation(async ({ input }) => {
        await db.updateVeiculoStatus(input.id, input.status);
        return { success: true };
      }),
  }),

  // ============ ORÇAMENTOS ============
  orcamentos: router({
    list: protectedProcedure
      .input(z.object({
        status: z.string().optional(),
        search: z.string().optional(),
        placa: z.string().optional(),
      }).optional())
      .query(async ({ input }) => {
        return await db.getOrcamentos(input);
      }),
    
    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const orcamento = await db.getOrcamentoById(input.id);
        if (!orcamento) return null;
        
        const [cliente, veiculo, itens, complementos, midias] = await Promise.all([
          db.getClienteById(orcamento.clienteId),
          db.getVeiculoById(orcamento.veiculoId),
          db.getItensOrcamento(orcamento.id),
          db.getComplementosOrcamento(orcamento.id),
          db.getMidiasByOrcamento(orcamento.id),
        ]);
        
        return { orcamento, cliente, veiculo, itens, complementos, midias };
      }),
    
    create: protectedProcedure
      .input(z.object({
        clienteId: z.number(),
        veiculoId: z.number(),
        dataEntrada: z.date(),
        prazoEntrega: z.date().optional(),
        numeroOS: z.string().optional(),
        status: z.enum(['pendente', 'aprovado', 'rejeitado', 'em_execucao', 'concluido']).default('pendente'),
        observacoes: z.string().optional(),
        desconto: z.number().default(0),
        acrescimo: z.number().default(0),
        itens: z.array(z.object({
          categoria: z.enum(['pecas', 'pintura', 'funilaria', 'outros']),
          descricao: z.string(),
          quantidade: z.number(),
          valorUnitario: z.number(),
        })),
        complementos: z.array(z.object({
          descricao: z.string(),
          valor: z.number(),
          data: z.date(),
          responsavel: z.string().optional(),
        })).optional(),
      }))
      .mutation(async ({ input }) => {
        // Gerar número do orçamento
        const orcamentos = await db.getOrcamentos();
        const numero = gerarNumero('ORC', orcamentos.length + 1);
        
        // Calcular totais
        const subtotalItens = input.itens.reduce((acc, item) => 
          acc + (item.quantidade * item.valorUnitario), 0);
        const subtotalComplementos = input.complementos?.reduce((acc, comp) => 
          acc + comp.valor, 0) || 0;
        const total = subtotalItens + subtotalComplementos - input.desconto + input.acrescimo;
        
        // Criar orçamento
        const result = await db.createOrcamento({
          numero,
          clienteId: input.clienteId,
          veiculoId: input.veiculoId,
          dataEntrada: input.dataEntrada,
          prazoEntrega: input.prazoEntrega,
          numeroOS: input.numeroOS,
          status: input.status,
          observacoes: input.observacoes,
          desconto: input.desconto,
          acrescimo: input.acrescimo,
          subtotalItens,
          subtotalComplementos,
          total,
        });
        
        const orcamentoId = result;
        
        // Criar itens
        for (const item of input.itens) {
          await db.createItemOrcamento({
            orcamentoId,
            categoria: item.categoria,
            descricao: item.descricao,
            quantidade: item.quantidade,
            valorUnitario: item.valorUnitario,
            valorTotal: item.quantidade * item.valorUnitario,
          });
        }
        
        // Criar complementos
        if (input.complementos) {
          for (const comp of input.complementos) {
            await db.createComplementoOrcamento({
              orcamentoId,
              descricao: comp.descricao,
              valor: comp.valor,
              data: comp.data,
              responsavel: comp.responsavel,
            });
          }
        }
        
        return { success: true, id: orcamentoId, numero };
      }),
    
    generatePDF: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        const orcamento = await db.getOrcamentoById(input.id);
        if (!orcamento) throw new Error('Orçamento não encontrado');
        
        const [cliente, veiculo, itens, complementos] = await Promise.all([
          db.getClienteById(orcamento.clienteId),
          db.getVeiculoById(orcamento.veiculoId),
          db.getItensOrcamento(orcamento.id),
          db.getComplementosOrcamento(orcamento.id),
        ]);
        
        if (!cliente || !veiculo) throw new Error('Dados incompletos');
        
        const { generateOrcamentoPDF } = await import('./_core/pdfGenerator');
        const pdfStream = generateOrcamentoPDF({
          orcamento,
          cliente,
          veiculo,
          itens,
          complementos,
        });
        
        // Converter stream para buffer
        const chunks: Buffer[] = [];
        for await (const chunk of pdfStream) {
          chunks.push(Buffer.from(chunk));
        }
        const pdfBuffer = Buffer.concat(chunks);
        
        // Retornar como base64 para o frontend
        return {
          success: true,
          pdf: pdfBuffer.toString('base64'),
          filename: `orcamento-${orcamento.numero}.pdf`,
        };
      }),
    
    updateStatus: protectedProcedure
      .input(z.object({
        id: z.number(),
        status: z.enum(['pendente', 'aprovado', 'rejeitado', 'em_execucao', 'concluido']),
      }))
      .mutation(async ({ input }) => {
        // Atualizar status do orçamento
        await db.updateOrcamento(input.id, { status: input.status });
        
        // Se aprovado, criar OS automaticamente e atualizar veículo
        if (input.status === 'aprovado') {
          const orcamento = await db.getOrcamentoById(input.id);
          if (orcamento) {
            // Criar OS
            const ordens = await db.getOrdensServico();
            const numeroOS = gerarNumero('OS', ordens.length + 1);
            await db.createOrdemServico({
              numero: numeroOS,
              orcamentoId: input.id,
              clienteId: orcamento.clienteId,
              veiculoId: orcamento.veiculoId,
              dataEntrada: new Date(),
              descricaoServicos: orcamento.observacoes || 'Serviços conforme orçamento',
              status: 'aguardando',
            });
            
            // Atualizar status do veículo para "aprovado"
            await db.updateVeiculoStatus(orcamento.veiculoId, 'aprovado');
          }
        }
        
        // Se em execução, atualizar veículo
        if (input.status === 'em_execucao') {
          const orcamento = await db.getOrcamentoById(input.id);
          if (orcamento) {
            await db.updateVeiculoStatus(orcamento.veiculoId, 'em_execucao');
          }
        }
        
        // Se concluído, atualizar veículo e criar conta a receber
        if (input.status === 'concluido') {
          const orcamento = await db.getOrcamentoById(input.id);
          if (orcamento) {
            await db.updateVeiculoStatus(orcamento.veiculoId, 'finalizado');
            
            // Criar conta a receber automaticamente
            const hoje = new Date();
            const dataVencimento = new Date();
            dataVencimento.setDate(dataVencimento.getDate() + 30); // Vencimento em 30 dias
            
            // Calcular valor total do orçamento
            const itens = await db.getItensOrcamento(orcamento.id);
            const complementos = await db.getComplementosOrcamento(orcamento.id);
            const subtotal = itens.reduce((sum: number, item: any) => sum + (item.valorUnitario * item.quantidade), 0) +
                            complementos.reduce((sum: number, comp: any) => sum + comp.valor, 0);
            const valorTotal = subtotal - (orcamento.desconto || 0) + (orcamento.acrescimo || 0);
            
            await db.createContaReceber({
              clienteId: orcamento.clienteId,
              orcamentoId: orcamento.id,
              descricao: `Orçamento ${orcamento.numero}`,
              valor: valorTotal,
              dataEmissao: hoje,
              dataVencimento: dataVencimento,
              status: 'pendente',
            });
          }
        }
        
        return { success: true };
      }),
    
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        clienteId: z.number().optional(),
        veiculoId: z.number().optional(),
        dataEntrada: z.date().optional(),
        prazoEntrega: z.date().optional(),
        numeroOS: z.string().optional(),
        status: z.enum(['pendente', 'aprovado', 'rejeitado', 'em_execucao', 'concluido']).optional(),
        observacoes: z.string().optional(),
        desconto: z.number().optional(),
        acrescimo: z.number().optional(),
        itens: z.array(z.object({
          id: z.number().optional(), // Se tiver ID, atualiza; senão, cria novo
          categoria: z.enum(['pecas', 'pintura', 'funilaria', 'outros']),
          descricao: z.string(),
          quantidade: z.number(),
          valorUnitario: z.number(),
        })).optional(),
        complementos: z.array(z.object({
          id: z.number().optional(),
          descricao: z.string(),
          valor: z.number(),
          data: z.date(),
          responsavel: z.string().optional(),
        })).optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, itens, complementos, ...orcamentoData } = input;
        
        // Atualizar orçamento
        if (Object.keys(orcamentoData).length > 0) {
          // Recalcular totais se necessário
          if (itens || complementos || orcamentoData.desconto !== undefined || orcamentoData.acrescimo !== undefined) {
            const itensAtuais = itens || await db.getItensOrcamento(id);
            const complementosAtuais = complementos || await db.getComplementosOrcamento(id);
            
            const subtotalItens = itensAtuais.reduce((acc: number, item: any) => 
              acc + (item.quantidade * item.valorUnitario), 0);
            const subtotalComplementos = complementosAtuais.reduce((acc: number, comp: any) => 
              acc + comp.valor, 0);
            
            const orcamentoAtual = await db.getOrcamentoById(id);
            const desconto = orcamentoData.desconto !== undefined ? orcamentoData.desconto : orcamentoAtual?.desconto || 0;
            const acrescimo = orcamentoData.acrescimo !== undefined ? orcamentoData.acrescimo : orcamentoAtual?.acrescimo || 0;
            
            const total = subtotalItens + subtotalComplementos - desconto + acrescimo;
            
            await db.updateOrcamento(id, {
              ...orcamentoData,
              subtotalItens,
              subtotalComplementos,
              total,
            });
          } else {
            await db.updateOrcamento(id, orcamentoData);
          }
        }
        
        // Atualizar itens se fornecidos
        if (itens) {
          // Deletar itens antigos e criar novos (simplificado)
          const itensAntigos = await db.getItensOrcamento(id);
          for (const item of itensAntigos) {
            await db.deleteItemOrcamento(item.id);
          }
          for (const item of itens) {
            await db.createItemOrcamento({
              orcamentoId: id,
              categoria: item.categoria,
              descricao: item.descricao,
              quantidade: item.quantidade,
              valorUnitario: item.valorUnitario,
              valorTotal: item.quantidade * item.valorUnitario,
            });
          }
        }
        
        // Atualizar complementos se fornecidos
        if (complementos) {
          const complementosAntigos = await db.getComplementosOrcamento(id);
          for (const comp of complementosAntigos) {
            if (comp.id) await db.deleteComplementoOrcamento(comp.id);
          }
          for (const comp of complementos) {
            await db.createComplementoOrcamento({
              orcamentoId: id,
              descricao: comp.descricao,
              valor: comp.valor,
              data: comp.data,
              responsavel: comp.responsavel,
            });
          }
        }
        
        return { success: true };
      }),
    
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteOrcamento(input.id);
        return { success: true };
      }),
    
    // Importar de PDF usando LLM
    importFromPDF: protectedProcedure
      .input(z.object({
        pdfUrl: z.string(),
      }))
      .mutation(async ({ input }) => {
        // Usar LLM para extrair dados do PDF
        const response = await invokeLLM({
          messages: [
            {
              role: "system",
              content: "Você é um assistente especializado em extrair dados de orçamentos de oficina mecânica de PDFs. Extraia todas as informações relevantes e retorne em formato JSON estruturado."
            },
            {
              role: "user",
              content: [
                {
                  type: "text",
                  text: "Extraia os dados deste orçamento de oficina. Identifique: dados do cliente (nome, CPF/CNPJ, telefone, email), dados do veículo (placa, marca, modelo, ano, cor), itens do orçamento (descrição, quantidade, valor unitário, categoria: peças/pintura/funilaria/outros), valores (subtotal, desconto, acréscimo, total), datas, observações."
                },
                {
                  type: "file_url",
                  file_url: {
                    url: input.pdfUrl,
                    mime_type: "application/pdf"
                  }
                }
              ]
            }
          ],
          response_format: {
            type: "json_schema",
            json_schema: {
              name: "orcamento_data",
              strict: true,
              schema: {
                type: "object",
                properties: {
                  cliente: {
                    type: "object",
                    properties: {
                      nome: { type: "string" },
                      cpfCnpj: { type: "string" },
                      telefone: { type: "string" },
                      email: { type: "string" }
                    },
                    required: ["nome"],
                    additionalProperties: false
                  },
                  veiculo: {
                    type: "object",
                    properties: {
                      placa: { type: "string" },
                      marca: { type: "string" },
                      modelo: { type: "string" },
                      ano: { type: "number" },
                      cor: { type: "string" }
                    },
                    required: ["placa", "modelo"],
                    additionalProperties: false
                  },
                  itens: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        descricao: { type: "string" },
                        quantidade: { type: "number" },
                        valorUnitario: { type: "number" },
                        categoria: { 
                          type: "string",
                          enum: ["pecas", "pintura", "funilaria", "outros"]
                        }
                      },
                      required: ["descricao", "quantidade", "valorUnitario", "categoria"],
                      additionalProperties: false
                    }
                  },
                  observacoes: { type: "string" }
                },
                required: ["cliente", "veiculo", "itens"],
                additionalProperties: false
              }
            }
          }
        });
        
        const messageContent = response.choices[0].message.content;
        const extractedData = JSON.parse(typeof messageContent === 'string' ? messageContent : '{}');
        return extractedData;
      }),
  }),

  // ============ ORDENS DE SERVIÇO ============
  ordensServico: router({
    list: protectedProcedure
      .input(z.object({
        status: z.string().optional(),
        search: z.string().optional(),
      }).optional())
      .query(async ({ input }) => {
        return await db.getOrdensServico(input);
      }),
    
    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const os = await db.getOrdemServicoById(input.id);
        if (!os) return null;
        
        const [cliente, veiculo] = await Promise.all([
          db.getClienteById(os.clienteId),
          db.getVeiculoById(os.veiculoId),
        ]);
        
        return { os, cliente, veiculo };
      }),
    
    create: protectedProcedure
      .input(z.object({
        numeroOSCliente: z.string().optional(),
        orcamentoId: z.number().optional(),
        clienteId: z.number(),
        veiculoId: z.number(),
        descricaoServicos: z.string(),
        valorTotal: z.number().default(0),
        dataEntrada: z.date().optional(),
        dataPrevista: z.date().optional(),
        nivelCombustivel: z.enum(['vazio', '1/4', '1/2', '3/4', 'cheio']).optional(),
        quilometragem: z.number().optional(),
        checklistEntrada: z.string().optional(),
        observacoesEntrada: z.string().optional(),
        fotosEntrada: z.string().optional(),
        observacoes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const ordensServico = await db.getOrdensServico();
        const numero = gerarNumero('OS', ordensServico.length + 1);
        
        await db.createOrdemServico({
          numero,
          dataEntrada: input.dataEntrada || new Date(),
          ...input,
        });
        
        return { success: true, numero };
      }),
    
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        status: z.enum(['aguardando', 'em_execucao', 'concluido', 'entregue']).optional(),
        valorTotal: z.number().optional(),
        dataPrevista: z.date().optional(),
        dataConclusao: z.date().optional(),
        dataSaida: z.date().optional(),
        checklistSaida: z.string().optional(),
        observacoesSaida: z.string().optional(),
        fotosSaida: z.string().optional(),
        observacoes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await db.updateOrdemServico(id, data);
        return { success: true };
      }),
  }),

  // ============ PRODUTOS/ESTOQUE ============
  produtos: router({
    list: protectedProcedure
      .input(z.object({
        categoria: z.string().optional(),
        search: z.string().optional(),
        ativo: z.boolean().optional(),
      }).optional())
      .query(async ({ input }) => {
        return await db.getProdutos(input);
      }),
    
    create: protectedProcedure
      .input(z.object({
        codigo: z.string(),
        descricao: z.string(),
        categoria: z.enum(['peca', 'pintura', 'funilaria', 'outros']),
        unidade: z.string().default('UN'),
        estoqueMinimo: z.number().default(0),
        valorCusto: z.number().default(0),
        valorVenda: z.number().default(0),
      }))
      .mutation(async ({ input }) => {
        await db.createProduto(input);
        return { success: true };
      }),
    
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        descricao: z.string().optional(),
        estoqueMinimo: z.number().optional(),
        valorCusto: z.number().optional(),
        valorVenda: z.number().optional(),
        ativo: z.boolean().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await db.updateProduto(id, data);
        return { success: true };
      }),
    
    movimentar: protectedProcedure
      .input(z.object({
        produtoId: z.number(),
        tipo: z.enum(['entrada', 'saida', 'ajuste']),
        quantidade: z.number(),
        motivo: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        await db.movimentarEstoque(input);
        return { success: true };
      }),
  }),

  // ============ FORNECEDORES ============
  fornecedores: router({
    list: protectedProcedure
      .input(z.object({ ativo: z.boolean().optional() }).optional())
      .query(async ({ input }) => {
        return await db.getFornecedores(input?.ativo);
      }),
    
    create: protectedProcedure
      .input(z.object({
        nome: z.string(),
        cnpj: z.string().optional(),
        telefone: z.string().optional(),
        email: z.string().optional(),
        endereco: z.string().optional(),
        cidade: z.string().optional(),
        estado: z.string().optional(),
        cep: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        await db.createFornecedor(input);
        return { success: true };
      }),
  }),

  // ============ AGENDAMENTOS ============
  agendamentos: router({
    list: protectedProcedure
      .input(z.object({
        dataInicio: z.date().optional(),
        dataFim: z.date().optional(),
        status: z.string().optional(),
      }).optional())
      .query(async ({ input }) => {
        return await db.getAgendamentos(input);
      }),
    
    create: protectedProcedure
      .input(z.object({
        clienteId: z.number(),
        veiculoId: z.number().optional(),
        dataHora: z.date(),
        duracao: z.number().default(60),
        servico: z.string(),
        observacoes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        await db.createAgendamento(input);
        return { success: true };
      }),
    
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        status: z.enum(['agendado', 'confirmado', 'em_atendimento', 'concluido', 'cancelado']),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await db.updateAgendamento(id, data);
        return { success: true };
      }),
  }),

  // ============ FINANCEIRO ============
  financeiro: router({
    contasPagar: router({
      list: protectedProcedure
        .input(z.object({
          status: z.string().optional(),
          dataInicio: z.date().optional(),
          dataFim: z.date().optional(),
        }).optional())
        .query(async ({ input }) => {
          return await db.getContasPagar(input);
        }),
      
      create: protectedProcedure
        .input(z.object({
          descricao: z.string(),
          fornecedorId: z.number().optional(),
          valor: z.number(),
          dataEmissao: z.date(),
          dataVencimento: z.date(),
          categoria: z.string().optional(),
          observacoes: z.string().optional(),
        }))
        .mutation(async ({ input }) => {
          await db.createContaPagar(input);
          return { success: true };
        }),
      
      pagar: protectedProcedure
        .input(z.object({
          id: z.number(),
          dataPagamento: z.date(),
          formaPagamento: z.string(),
        }))
        .mutation(async ({ input }) => {
          await db.updateContaPagar(input.id, {
            dataPagamento: input.dataPagamento,
            formaPagamento: input.formaPagamento,
            status: 'pago',
          });
          return { success: true };
        }),
      
      marcarPago: protectedProcedure
        .input(z.object({ id: z.number() }))
        .mutation(async ({ input }) => {
          await db.updateContaPagar(input.id, {
            dataPagamento: new Date(),
            status: 'pago',
          });
          return { success: true };
        }),
    }),
    
    contasReceber: router({
      list: protectedProcedure
        .input(z.object({
          status: z.string().optional(),
          dataInicio: z.date().optional(),
          dataFim: z.date().optional(),
          clienteNome: z.string().optional(),
        }).optional())
        .query(async ({ input }) => {
          return await db.getContasReceber(input);
        }),
      
      create: protectedProcedure
        .input(z.object({
          descricao: z.string(),
          clienteId: z.number().optional(),
          ordemServicoId: z.number().optional(),
          valor: z.number(),
          dataEmissao: z.date(),
          dataVencimento: z.date(),
          categoria: z.string().optional(),
          observacoes: z.string().optional(),
        }))
        .mutation(async ({ input }) => {
          await db.createContaReceber(input);
          return { success: true };
        }),
      
      receber: protectedProcedure
        .input(z.object({
          id: z.number(),
          dataRecebimento: z.date(),
          formaPagamento: z.string(),
        }))
        .mutation(async ({ input }) => {
          await db.updateContaReceber(input.id, {
            dataRecebimento: input.dataRecebimento,
            formaPagamento: input.formaPagamento,
            status: 'recebido',
          });
          return { success: true };
        }),
      
      marcarRecebido: protectedProcedure
        .input(z.object({ id: z.number() }))
        .mutation(async ({ input }) => {
          await db.updateContaReceber(input.id, {
            dataRecebimento: new Date(),
            status: 'recebido',
          });
          return { success: true };
        }),
    }),
  }),

  // ============ UPLOAD ============
  upload: router({
    uploadPDF: protectedProcedure
      .input(z.object({
        fileName: z.string(),
        fileData: z.string(), // base64
      }))
      .mutation(async ({ input, ctx }) => {
        const buffer = Buffer.from(input.fileData, 'base64');
        const fileKey = `uploads/${ctx.user.id}/${Date.now()}-${input.fileName}`;
        const result = await storagePut(fileKey, buffer, 'application/pdf');
        return { url: result.url, key: result.key };
      }),
  }),
  
  // ============ UPLOAD DE MÍDIAS ============
  media: router({
    uploadOrcamento: protectedProcedure
      .input(z.object({
        orcamentoId: z.number(),
        files: z.array(z.object({
          name: z.string(),
          type: z.string(),
          size: z.number(),
          data: z.string(), // base64
        })),
      }))
      .mutation(async ({ input }) => {
        const { orcamentoId, files } = input;
        const uploadedUrls: string[] = [];

        for (const file of files) {
          // Decodificar base64
          const buffer = Buffer.from(file.data, 'base64');
          
          // Gerar nome único para o arquivo
          const timestamp = Date.now();
          const randomSuffix = Math.random().toString(36).substring(7);
          const extension = file.name.split('.').pop();
          const fileKey = `orcamentos/${orcamentoId}/${timestamp}-${randomSuffix}.${extension}`;
          
          // Upload para S3
          const { storagePut } = await import('./storage');
          const { url } = await storagePut(fileKey, buffer, file.type);
          
          // Salvar no banco de dados
          await db.createMidia({
            orcamentoId,
            tipo: file.type.startsWith('video/') ? 'video' : 'foto',
            url,
            fileKey,
            fileName: file.name,
            fileSize: file.size,
            mimeType: file.type,
          });
          
          uploadedUrls.push(url);
        }

        return { success: true, urls: uploadedUrls };
      }),
    
    extractPdfData: protectedProcedure
      .input(z.object({
        pdfData: z.string(), // base64
      }))
      .mutation(async ({ input }) => {
        // TODO: Implementar extração de dados do PDF usando LLM
        // Por enquanto retorna estrutura vazia
        return {
          nomeCliente: "",
          cpfCnpj: "",
          telefone: "",
          email: "",
          modeloVeiculo: "",
          placa: "",
          itens: [],
          total: 0,
        };
      }),
  }),

  // ============ COLABORADORES ============
  colaboradores: router({
    list: protectedProcedure.query(async () => {
      return await db.getAllColaboradores();
    }),

    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return await db.getColaboradorById(input.id);
      }),

    create: protectedProcedure
      .input(z.object({
        nome: z.string().min(1),
        cargo: z.string().optional(),
        salario: z.number().positive(),
        tipoPagamento: z.enum(['semanal', 'quinzenal', 'mensal']),
        diaPagamento: z.number().min(0).max(31),
        dataAdmissao: z.date(),
        status: z.enum(['ativo', 'inativo']).default('ativo'),
        observacoes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const id = await db.createColaborador(input);
        return { id };
      }),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        nome: z.string().min(1).optional(),
        cargo: z.string().optional(),
        salario: z.number().positive().optional(),
        tipoPagamento: z.enum(['semanal', 'quinzenal', 'mensal']).optional(),
        diaPagamento: z.number().min(0).max(31).optional(),
        dataAdmissao: z.date().optional(),
        status: z.enum(['ativo', 'inativo']).optional(),
        observacoes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await db.updateColaborador(id, data);
        return { success: true };
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteColaborador(input.id);
        return { success: true };
      }),

    proximosPagamentos: protectedProcedure.query(async () => {
      return await db.getProximosPagamentosColaboradores();
    }),

    gerarPagamento: protectedProcedure
      .input(z.object({ colaboradorId: z.number() }))
      .mutation(async ({ input }) => {
        return db.gerarPagamentoColaborador(input.colaboradorId);
      }),
    
    historicoPagamentos: protectedProcedure
      .input(z.object({ colaboradorId: z.number() }))
      .query(async ({ input }) => {
        return db.getHistoricoPagamentosColaborador(input.colaboradorId);
      }),
  }),

  // ============ RELATÓRIOS ============
  relatorios: router({
    faturamento: protectedProcedure.query(async () => {
      return await db.getFaturamentoMensal();
    }),

    funil: protectedProcedure.query(async () => {
      return await db.getFunilVendas();
    }),

    clientes: protectedProcedure.query(async () => {
      return await db.getAnaliseClientes();
    }),

    fluxoCaixa: protectedProcedure
      .input(z.object({
        dataInicio: z.date().optional(),
        dataFim: z.date().optional(),
      }).optional())
      .query(async ({ input }) => {
        return await db.getFluxoCaixa(input);
      }),
  }),

  adiantamentos: router({
    create: protectedProcedure
      .input(z.object({
        colaboradorId: z.number(),
        valor: z.number(),
        dataAdiantamento: z.date(),
        descricao: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        return db.createAdiantamento(input);
      }),
    
    pendentes: protectedProcedure
      .input(z.object({ colaboradorId: z.number() }))
      .query(async ({ input }) => {
        return db.getAdiantamentosPendentes(input.colaboradorId);
      }),
  }),

  orcamentosExternos: router({
    getAll: publicProcedure.query(async () => {
      return await db.getAllOrcamentosExternos();
    }),

    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return await db.getOrcamentoExternoById(input.id);
      }),

    create: publicProcedure
      .input(z.object({
        cliente: z.string(),
        placa: z.string(),
        modelo: z.string(),
        valor: z.number(),
        pdfUrl: z.string().optional(),
        pdfKey: z.string().optional(),
        status: z.enum(['pendente', 'em_analise', 'aprovado', 'rejeitado']).default('pendente'),
        observacoes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const result = await db.createOrcamentoExterno(input);
        
        // Criar conta a receber automaticamente
        if (input.status === 'aprovado' && input.valor > 0) {
          const vencimento = new Date();
          vencimento.setDate(vencimento.getDate() + 30); // 30 dias
          
          await db.createContaReceber({
            descricao: `Orçamento Externo ${input.cliente} - ${input.placa}`,
            valor: input.valor,
            dataEmissao: new Date(),
            dataVencimento: vencimento,
            status: 'pendente',
          });
        }
        
        return result;
      }),

    update: publicProcedure
      .input(z.object({
        id: z.number(),
        cliente: z.string().optional(),
        placa: z.string().optional(),
        modelo: z.string().optional(),
        valor: z.number().optional(),
        status: z.enum(['pendente', 'em_analise', 'aprovado', 'rejeitado']).optional(),
        observacoes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return await db.updateOrcamentoExterno(id, data);
      }),

    delete: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        return await db.deleteOrcamentoExterno(input.id);
      }),

    uploadPDF: publicProcedure
      .input(z.object({
        fileName: z.string(),
        fileData: z.string(), // base64
      }))
      .mutation(async ({ input }) => {
        // Upload para S3
        const buffer = Buffer.from(input.fileData.split(',')[1], 'base64');
        const fileKey = `orcamentos-externos/${Date.now()}-${input.fileName}`;
        const { url } = await storagePut(fileKey, buffer, 'application/pdf');

        // Extrair dados via IA
        const extractedData = await invokeLLM({
          messages: [
            {
              role: 'system',
              content: 'Você é um assistente especializado em extrair informações de orçamentos de seguradoras. Analise o PDF e extraia: nome do cliente/seguradora, placa do veículo, modelo do veículo e valor total. Retorne APENAS um JSON válido com as chaves: cliente, placa, modelo, valor (número).'
            },
            {
              role: 'user',
              content: [
                { type: 'text', text: 'Extraia as informações deste orçamento:' },
                { type: 'file_url', file_url: { url, mime_type: 'application/pdf' } }
              ]
            }
          ],
          response_format: {
            type: 'json_schema',
            json_schema: {
              name: 'orcamento_externo',
              strict: true,
              schema: {
                type: 'object',
                properties: {
                  cliente: { type: 'string' },
                  placa: { type: 'string' },
                  modelo: { type: 'string' },
                  valor: { type: 'number' }
                },
                required: ['cliente', 'placa', 'modelo', 'valor'],
                additionalProperties: false
              }
            }
          }
        });

        const content = extractedData.choices[0].message.content;
        const extracted = JSON.parse(typeof content === 'string' ? content : '{}');

        return {
          pdfUrl: url,
          pdfKey: fileKey,
          extractedData: {
            cliente: extracted.cliente || '',
            placa: extracted.placa || '',
            modelo: extracted.modelo || '',
            valor: extracted.valor || 0
          }
        };
      }),
  }),

  // ============ GESTÃO DE USUÁRIOS (DESABILITADO) ============
  // Sistema de controle de acesso removido para simplificar
  /*
  usuarios: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      // Apenas admin pode listar usuários
      if (ctx.user.role !== 'admin') {
        throw new TRPCError({ code: 'FORBIDDEN', message: 'Acesso negado' });
      }
      return await db.getAllUsers();
    }),

    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ ctx, input }) => {
        if (ctx.user.role !== 'admin') {
          throw new TRPCError({ code: 'FORBIDDEN', message: 'Acesso negado' });
        }
        return await db.getUserById(input.id);
      }),

    create: protectedProcedure
      .input(z.object({
        email: z.string().email(),
        name: z.string().optional(),
        nivelAcesso: z.enum(['admin', 'gerente', 'atendente', 'mecanico', 'financeiro', 'personalizado']).optional(),
        permissoes: z.string().optional(), // JSON string
        ativo: z.boolean().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== 'admin') {
          throw new TRPCError({ code: 'FORBIDDEN', message: 'Acesso negado' });
        }
        
        // Verificar se email já existe
        const existing = await db.getUserByEmail(input.email);
        if (existing) {
          throw new TRPCError({ code: 'BAD_REQUEST', message: 'E-mail já cadastrado' });
        }
        
        return await db.createUser(input);
      }),

    updatePermissions: protectedProcedure
      .input(z.object({
        id: z.number(),
        nivelAcesso: z.enum(['admin', 'gerente', 'atendente', 'mecanico', 'financeiro', 'personalizado']).optional(),
        permissoes: z.string().optional(),
        ativo: z.boolean().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== 'admin') {
          throw new TRPCError({ code: 'FORBIDDEN', message: 'Acesso negado' });
        }
        const { id, ...data } = input;
        return await db.updateUserPermissions(id, data);
      }),

    toggleStatus: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== 'admin') {
          throw new TRPCError({ code: 'FORBIDDEN', message: 'Acesso negado' });
        }
        return await db.toggleUserStatus(input.id);
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== 'admin') {
          throw new TRPCError({ code: 'FORBIDDEN', message: 'Acesso negado' });
        }
        
        // Não permitir deletar a si mesmo
        if (ctx.user.id === input.id) {
          throw new TRPCError({ code: 'BAD_REQUEST', message: 'Você não pode deletar sua própria conta' });
        }
        
        return await db.deleteUser(input.id);
      }),
  }),
  */
});

export type AppRouter = typeof appRouter;
