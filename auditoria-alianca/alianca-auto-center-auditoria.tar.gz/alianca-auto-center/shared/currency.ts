/**
 * Utilitários para formatação monetária no padrão brasileiro
 * Valores são armazenados em centavos no banco de dados
 */

/**
 * Converte centavos para reais formatado (1.000,00)
 */
export function centavosParaReais(centavos: number): string {
  const reais = centavos / 100;
  return reais.toLocaleString('pt-BR', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}

/**
 * Converte centavos para reais formatado com símbolo (R$ 1.000,00)
 */
export function formatarMoeda(centavos: number): string {
  const reais = centavos / 100;
  return reais.toLocaleString('pt-BR', {
    style: 'currency',
    currency: 'BRL'
  });
}

/**
 * Converte string de reais para centavos
 * Aceita: "1.000,00", "1000,00", "1000.00", "1000"
 */
export function reaisParaCentavos(valor: string | number): number {
  if (typeof valor === 'number') {
    return Math.round(valor * 100);
  }
  
  // Remove espaços e símbolo R$
  let limpo = valor.replace(/\s/g, '').replace('R$', '');
  
  // Se tem vírgula e ponto, assume formato brasileiro (1.000,00)
  if (limpo.includes('.') && limpo.includes(',')) {
    limpo = limpo.replace(/\./g, '').replace(',', '.');
  }
  // Se tem apenas vírgula, assume que é decimal brasileiro (1000,00)
  else if (limpo.includes(',')) {
    limpo = limpo.replace(',', '.');
  }
  
  const numero = parseFloat(limpo);
  if (isNaN(numero)) {
    return 0;
  }
  
  return Math.round(numero * 100);
}

/**
 * Valida se uma string é um valor monetário válido
 */
export function validarValorMonetario(valor: string): boolean {
  const limpo = valor.replace(/\s/g, '').replace('R$', '');
  const regex = /^(\d{1,3}(\.\d{3})*|\d+)(,\d{2})?$/;
  return regex.test(limpo);
}
