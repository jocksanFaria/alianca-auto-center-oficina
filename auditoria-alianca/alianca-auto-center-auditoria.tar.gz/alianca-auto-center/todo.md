# Aliança Auto Center - TODO

## Funcionalidades Principais

### Sistema de Orçamentos
- [ ] Criar orçamento com dados completos (veículo, cliente, itens)
- [ ] Listar orçamentos com filtros e busca
- [ ] Editar orçamentos existentes
- [ ] Excluir orçamentos
- [ ] Categorias de itens (Peças, Pintura, Funilaria, Outros)
- [ ] Complementos com data e responsável
- [ ] Cálculo automático de totais com desconto e acréscimo
- [ ] Formatação monetária brasileira (1.000,00)

### Sistema de Ordens de Serviço
- [ ] Criar ordem de serviço
- [ ] Listar ordens de serviço com indicadores
- [ ] Editar ordens de serviço
- [ ] Checklist de entrada (combustível, quilometragem)
- [ ] Status de OS (aguardando, em execução, concluído)

### Gestão de Clientes
- [ ] Cadastrar clientes
- [ ] Listar clientes
- [ ] Editar clientes
- [ ] Vincular clientes a orçamentos e OS

### Gestão de Veículos
- [ ] Cadastrar veículos
- [ ] Listar veículos
- [ ] Vincular veículos a orçamentos e OS

### Financeiro
- [ ] Dashboard financeiro com indicadores
- [ ] Notas fiscais vinculadas a OS
- [ ] Controle de pagamentos (a vencer, vencido, pago)
- [ ] Relatórios financeiros

### Importação e Exportação
- [ ] Importar orçamentos de PDF com extração inteligente via LLM
- [ ] Exportar orçamentos para PDF
- [ ] Exportar orçamentos para TXT
- [ ] Exportar dados para Excel

### Interface e UX
- [ ] Dashboard principal com navegação unificada
- [ ] Formatação de valores no padrão brasileiro
- [ ] Responsividade mobile
- [ ] Feedback visual de ações (toasts, loading states)

## Bugs Conhecidos
- [ ] Corrigir exportação de PDF (não está funcionando)
- [ ] Corrigir importação de PDF (não está funcionando)

## Melhorias Futuras
- [ ] Histórico de serviços por veículo
- [ ] Relatórios analíticos
- [ ] Notificações de vencimento

### Controle de Estoque
- [ ] Cadastrar produtos/peças
- [ ] Controle de entrada e saída
- [ ] Inventário de estoque
- [ ] Alertas de estoque mínimo
- [ ] Histórico de movimentações

### Pedidos de Compra
- [ ] Criar pedidos de compra
- [ ] Listar pedidos pendentes
- [ ] Receber pedidos
- [ ] Vincular pedidos a orçamentos

### Agendamento
- [ ] Agendar serviços
- [ ] Calendário de agendamentos
- [ ] Notificações de agendamento
- [ ] Histórico de agendamentos

### Controle de Caixa
- [ ] Abertura de caixa
- [ ] Lançamentos de entrada/saída
- [ ] Fechamento de caixa
- [ ] Relatório de caixa

### Contas a Pagar/Receber
- [ ] Lançar contas a pagar
- [ ] Lançar contas a receber
- [ ] Controle de vencimentos
- [ ] Baixa de contas pagas/recebidas
- [ ] Relatório de fluxo de caixa

### Controle de Acesso e Usuários
- [ ] Painel de administração (apenas admin)
- [ ] Criar usuários com login e senha
- [ ] Definir níveis de permissão (Admin, Gerente, Atendente, Mecânico, Financeiro, Personalizado)
- [ ] Controle de acesso por tela/módulo
- [ ] Ativar/desativar usuários
- [ ] Histórico de ações dos usuários
- [ ] Alterar senha de usuários

### Fotos, Vídeos e Envio por E-mail
- [ ] Upload de fotos no orçamento (câmera ou galeria)
- [ ] Upload de vídeos no orçamento
- [ ] Galeria de mídia por orçamento
- [ ] Enviar orçamento por e-mail para cliente
- [ ] Template de e-mail profissional
- [ ] Anexar PDF do orçamento no e-mail
- [ ] Incluir fotos e vídeos no e-mail
- [ ] Link para visualização online do orçamento
- [ ] Histórico de e-mails enviados

### Envio de E-mail (Urgente)
- [ ] Configurar envio de e-mail com jocksanfaria@outlook.com
- [ ] Implementar botão de envio de orçamento por e-mail
- [ ] Template de e-mail profissional com orçamento
- [ ] Anexar fotos e vídeos no e-mail

### Sistema de Autenticação Próprio (Urgente)
- [ ] Criar sistema de login com e-mail e senha
- [ ] Criptografia de senhas com bcrypt
- [ ] Tela de login personalizada
- [ ] Gerenciamento de sessões
- [ ] Criar conta admin padrão: jocksanfaria@outlook.com
- [ ] Painel de gerenciamento de usuários
- [ ] Funcionalidade de criar novos usuários
- [ ] Funcionalidade de redefinir senha

### Bugs Urgentes
- [ ] Erro ao salvar cliente
- [ ] Erro ao criar orçamento
- [ ] Não consegue selecionar cliente no orçamento

### Ajustes de Orçamento (Urgente)
- [x] Permitir digitar placa e modelo direto no orçamento (sem cadastro prévio)
- [x] Adicionar categorias de itens: Peças, Pintura, Funilaria, Outros
- [x] Ajustar layout conforme orçamento antigo

### Upload de Mídias (Em Andamento)
- [x] Criar componente MediaUpload para fotos e vídeos
- [x] Integrar MediaUpload ao formulário de orçamento
- [x] Criar backend para upload de arquivos para S3
- [x] Criar tabela midiasOrcamento no banco de dados
- [x] Implementar conversão de arquivos para base64
- [x] Implementar salvamento de mídias no banco após upload
- [ ] Testar upload completo de fotos e vídeos
- [ ] Implementar visualização de mídias no orçamento
- [ ] Implementar exclusão de mídias

### Importação Inteligente de PDF (Próxima)
- [ ] Criar componente de upload de PDF
- [ ] Implementar extração de texto do PDF
- [ ] Usar LLM para extrair dados estruturados do PDF
- [ ] Preencher formulário automaticamente com dados extraídos
- [ ] Testar com PDFs de diferentes plataformas (Unidas, etc)

### Envio de E-mail (Próxima)
- [ ] Configurar serviço de envio de e-mail
- [ ] Criar template de e-mail profissional
- [ ] Implementar geração de PDF do orçamento
- [ ] Anexar fotos e vídeos ao e-mail
- [ ] Implementar botão "Enviar por E-mail" no orçamento
- [ ] Salvar histórico de e-mails enviados

### Bugs Reportados
- [x] Corrigir layout no notebook - cabeçalho fica no topo e conteúdo fica na parte inferior com espaço vazio no meio

- [x] Corrigir salvamento de orçamentos - orçamento criado no celular não aparece no notebook (não está salvando no banco de dados)

### Melhorias de Orçamento
- [x] Implementar seleção de cliente cadastrado no formulário de orçamento
- [x] Adicionar opção de alternar entre "Cliente Cadastrado" e "Cliente Novo"
- [x] Implementar autocomplete/busca de clientes
- [x] Permitir criar orçamento com cliente cadastrado OU cliente novo

- [x] Corrigir validação de cliente - erro ao salvar orçamento com cliente cadastrado selecionado

### Melhorias de UX
- [x] Melhorar digitação de valores unitários - remover formatação em tempo real que trava a digitação
- [x] Aplicar formatação de moeda apenas ao sair do campo (onBlur)

- [x] Corrigir erro NaN no veiculoId ao salvar orçamento - "Invalid input: expected number, received NaN"

### Visualização e Envio de Orçamento
- [x] Criar página de visualização detalhada de orçamento com todos os dados
- [x] Mostrar fotos e vídeos anexados no orçamento
- [x] Implementar botão de visualizar orçamento (olho)
- [x] Implementar botão de download/exportar PDF
- [x] Implementar botão de imprimir orçamento
- [ ] Implementar botão de enviar por e-mail
- [ ] Implementar botão de editar orçamento
- [ ] Implementar botão de excluir orçamento (com confirmação)
- [ ] Tornar card "Orçamentos Pendentes" no Dashboard clicável
- [ ] Implementar navegação do Dashboard para lista de orçamentos filtrada
- [ ] Implementar upload de PDF de orçamentos externos (Unidas, Localiza, etc.)
- [ ] Armazenar PDF no S3 e vincular ao orçamento
- [ ] Permitir visualizar PDF anexado dentro do sistema

### Alteração de Status e Navegação
- [x] Adicionar campo para alterar status do orçamento na visualização
- [x] Implementar backend para atualizar status
- [x] Tornar card "Orçamentos Pendentes" clicável (filtrar por pendente)
- [x] Tornar card "OS em Execução" clicável (filtrar por em_execucao)
- [x] Tornar card "A Receber" clicável (filtrar contas a receber)
- [x] Tornar card "A Pagar" clicável (filtrar contas a pagar)
- [x] Adicionar gráficos visuais nos cards do Dashboard (circular/barra de progresso)
- [ ] Implementar indicadores de urgência (verde/amarelo/vermelho) nos cards financeiros

### Bugs Reportados
- [x] Corrigir atualização do Dashboard - não atualiza estatísticas após mudança de status do orçamento

### Adaptação do Padrão Visual do Orçamento
- [ ] Adaptar visualização de orçamento para seguir padrão atual da empresa
- [ ] Usar cores amarelo/dourado nos cabeçalhos de seções
- [ ] Organizar itens em seções: PEÇAS, SERVIÇOS DE PINTURA, SERVIÇOS DE FUNILARIA, MÃO DE OBRA
- [ ] Adicionar logo e dados da empresa no cabeçalho
- [x] Implementar geração de PDF seguindo padrão visual
- [ ] Adicionar campo de observações com destaque
- [ ] Adicionar total geral em destaque no rodapé

### Compartilhamento Nativo de Orçamento (Nova Solicitação)
- [x] Implementar Web Share API para compartilhamento nativo
- [x] Gerar PDF do orçamento para compartilhamento
- [x] Implementar botão "Compartilhar" na visualização de orçamento
- [x] Adicionar fallback para desktop (mailto com PDF)
- [ ] Testar compartilhamento em mobile (WhatsApp, E-mail, etc.)
- [ ] Testar compartilhamento em desktop (cliente de e-mail padrão)

### Bug Urgente Reportado
- [x] Corrigir erro "Rendered more hooks than during the previous render" na página de visualização de orçamento (/orcamentos/:id)

### Correção de Dados da Empresa no PDF
- [x] Atualizar informações da empresa no gerador de PDF (endereço, telefone, e-mail)

### Correção de Layout do PDF
- [x] Ajustar alinhamento e centralização do conteúdo do PDF
- [x] Melhorar organização e espaçamento das seções
- [x] Tornar PDF mais legível e profissional

### Bug no Resumo Financeiro do PDF
- [x] Corrigir sobreposição de texto no resumo financeiro (Subtotal e Total Geral)

### Correção de Nome de Categoria no PDF
- [x] Alterar "MÃO DE OBRA" para "OUTROS" no PDF

### Ajuste de Impressão de Orçamento
- [x] Modificar função de impressão para usar o mesmo PDF gerado (idêntico ao download)

### Melhoria na Mensagem de E-mail
- [x] Atualizar mensagem pré-escrita do e-mail com texto profissional e assinatura da empresa

### E-mail em Cópia Automática
- [x] Adicionar funilariaalianca10@gmail.com em cópia (Cc) automaticamente no e-mail

### Remover Menu de Compartilhamento
- [x] Desabilitar Web Share API e usar sempre mailto para abrir app de e-mail direto

### Funcionalidade de Edição de Orçamentos
- [x] Criar endpoint backend para atualizar orçamentos
- [x] Criar página de edição de orçamento (formulário pré-preenchido)
- [x] Conectar botão "Editar" à página de edição
- [x] Permitir edição de todos os dados (cliente, veículo, itens, valores, observações)
- [ ] Testar edição completa e salvamento

### Bug na Tabela de Itens do PDF (URGENTE)
- [x] Investigar por que doc.text() avança cursor mesmo sem opções
- [x] Testar abordagem alternativa salvando/restaurando cursor antes de cada text()
- [x] Reescrever gerador de PDF usando HTML e html-pdf-node

### Bug Crítico - Geração de PDF com html-pdf-node
- [x] html-pdf-node falhando (precisa Puppeteer/Chromium)
- [x] Reverter para PDFKit
- [x] Adicionar lineBreak: false em todos os text() dos itens

### Ajuste de Layout do Resumo Financeiro
- [x] Centralizar resumo financeiro (Subtotal e Total Geral) no meio da página

### Separação de Subtotais no Resumo Financeiro do PDF
- [x] Separar resumo em: Subtotal de Peças, Subtotal de Serviços, Subtotal Geral, Desconto, Acréscimo, Total Geral
- [x] Calcular subtotal de peças (Peças + Pintura + Funilaria + Outros)
- [x] Calcular subtotal de serviços (Complementos)
- [x] Atualizar layout do PDF com nova estrutura de resumo

### Correção de Cálculo de Subtotais no PDF
- [x] Corrigir subtotal de peças: somar APENAS itens da categoria "pecas"
- [x] Corrigir subtotal de serviços: somar Pintura + Funilaria + Outros + Complementos
- [x] Testar com orçamento real para validar cálculo

### Bug Crítico - Módulo de Clientes
- [x] Investigar erro ao salvar cliente
- [x] Corrigir backend de cadastro de clientes (adicionado CORS)
- [x] Testar cadastro completo de cliente
- [x] Validar edição de cliente existente

### Módulo de Veículos - Painel de Acompanhamento
- [x] Adicionar campo `status` no schema de veículos (aguardando_orcamento, orcamento_pendente, aprovado, em_execucao, finalizado, entregue)
- [x] Remover campos desnecessários do formulário (chassi, renavam, marca, cor)
- [x] Simplificar formulário: Cliente, Placa, Modelo, Ano
- [x] Criar interface com cards de status (visual de kanban/dashboard)
- [x] Implementar filtro por status
- [x] Mostrar nome do cliente na listagem
- [x] Adicionar função de mudança de status
- [ ] Integrar mudança de status com orçamentos (próxima fase)
- [ ] Atualizar dashboard para refletir status dos veículos (próxima fase)
- [x] Habilitar função de exclusão de veículos

### Busca por Placa no Módulo de Orçamentos
- [x] Adicionar campo de busca por placa na interface de orçamentos
- [x] Atualizar backend para filtrar orçamentos por placa do veículo
- [x] Implementar busca em tempo real (debounced)
- [x] Testar busca com diferentes placas

## 🚀 DESENVOLVIMENTO AUTÔNOMO - Sessão de 1h-1h30

### Melhorias no Módulo de Orçamentos
- [x] Adicionar coluna "Veículo" na tabela de orçamentos (placa + modelo)
- [x] Corrigir exibição de placa nos detalhes do orçamento
- [x] Melhorar layout da tabela para incluir mais informações

### Módulo de Ordens de Serviço (OS)
- [x] Criar schema de OS no banco de dados
- [x] Implementar CRUD de OS no backend
- [x] Criar interface de listagem de OS com cards de resumo
- [ ] Criar formulário de criação/edição de OS (próxima fase)
- [ ] Implementar checklist de entrada do veículo (próxima fase)
- [ ] Implementar checklist de saída do veículo (próxima fase)
- [x] Vincular OS com orçamento e veículo (schema pronto)
- [x] Implementar mudança de status da OS (backend pronto)
- [ ] Adicionar upload de fotos do veículo (próxima fase)

### Módulo Financeiro
- [x] Criar schema de contas a receber/pagar no banco
- [x] Implementar CRUD de contas no backend
- [x] Criar interface de contas a receber
- [x] Criar interface de contas a pagar
- [x] Implementar marcar como recebido/pago
- [ ] Adicionar filtros por data e status (próxima fase)
- [ ] Criar relatório de fluxo de caixa (próxima fase)] Criar relatórios financeiros### Módulo de Estoque
- [x] Criar schema de produtos/peças no banco
- [x] Implementar CRUD de produtos no backend
- [x] Criar interface de listagem de produtos
- [x] Implementar movimentações de estoque (entrada/saída)
- [x] Adicionar alertas de estoque mínimo
- [x] Criar cards de resumo com produtos em estoque baixos
### Módulo de Agendamentos
- [x] Criar schema de agendamentos no banco
- [x] Implementar CRUD de agendamentos no backend
- [x] Criar interface de lista de agendamentos agrupados por data
- [x] Implementar criação de agendamento com vínculo a cliente/veículo
- [x] Adicionar cards de resumo (hoje, próximos 7 dias)
- [ ] Adicionar notificações de agendamentos próximos
- [ ] Vincular agendamento com cliente e veículo

### Integrações e Dashboard
- [x] Integrar orçamento aprovado com criação automática de OS
- [x] Atualizar status do veículo automaticamente quando orçamento mudar de status
- [x] Sincronizar status entre Orçamentos, OS e Veículos
- [ ] Criar conta a receber automaticamente quando OS for concluída (próxima fase)
- [ ] Atualizar Dashboard com dados reais de todos os módulos (já funcional)
- [ ] Integrar mudança de status entre Veículos, Orçamentos e OS
- [ ] Atualizar Dashboard com dados de todos os módulos
- [ ] Adicionar gráficos e estatísticas
- [ ] Implementar atividades recentes no Dashboard


## 🔍 REVISÃO E SINCRONIZAÇÃO COMPLETA

### Revisão de Funcionamento Individual
- [x] Testar CRUD completo de Clientes
- [x] Testar CRUD completo de Veículos
- [x] Testar criação e edição de Orçamentos
- [x] Testar criação e visualização de OS
- [x] Testar Financeiro (criar/marcar como pago/recebido)
- [x] Testar Estoque (produtos e movimentações)
- [x] Testar Agendamentos (criar/listar)

### Sincronizações Entre Módulos
- [x] Orçamento aprovado → Criar OS automaticamente (TESTADO E FUNCIONANDO)
- [x] Orçamento aprovado → Atualizar status do veículo para "aprovado" (TESTADO E FUNCIONANDO)
- [x] Orçamento em execução → Atualizar status do veículo para "em_execucao" (implementado)
- [x] Orçamento concluído → Atualizar status do veículo para "finalizado" (implementado)
- [ ] OS concluída → Criar conta a receber automaticamente (próxima fase)
- [ ] Veículo entregue → Atualizar status da OS (próxima fase)
- [x] Movimentação de estoque → Atualizar quantidade de produtos (implementado)

### Dashboard - Dados Reais
- [x] Card "Orçamentos Pendentes" buscar dados reais do banco (TESTADO - mostrando 2 pendentes)
- [x] Card "OS em Execução" buscar dados reais do banco (TESTADO - mostrando 0)
- [x] Card "A Receber" buscar dados reais do banco (TESTADO - mostrando R$ 0,00)
- [x] Card "A Pagar" buscar dados reais do banco (TESTADO - mostrando R$ 0,00)
- [x] Card "Produtos em Estoque Baixo" buscar dados reais do banco (TESTADO - mostrando 0)
- [x] Seção "Atividades Recentes" mostrar últimas ações do sistema (implementado e funcionando)
- [x] Seção "Próximos Agendamentos" mostrar agendamentos futuros (implementado)

### Correções e Melhorias
- [x] Corrigir erro TypeScript em Orcamentos.tsx (linha 64) - já corrigido
- [x] Adicionar loading states em todas as listagens (implementado)
- [x] Adicionar mensagens de erro amigáveis (implementado via toast)
- [x] Implementar refresh automático após mutations (implementado via invalidate)


## 💰 INTEGRAÇÃO FINANCEIRA - CONTAS A RECEBER

### Criação Automática de Conta a Receber
- [x] Modificar procedure updateStatus de orçamentos para criar conta a receber quando status = "concluido"
- [x] Conta deve conter: valor total do orçamento, clienteId, veiculoId, orcamentoId, descrição
- [x] Status inicial da conta: "pendente"
- [x] Data de vencimento: data de conclusão + 30 dias (padrão)

### Filtros de Período no Financeiro
- [x] Adicionar botões de filtro rápido: Semana / Mês / Ano
- [x] Adicionar filtro personalizado com data inicial e data final
- [x] Calcular e mostrar total a receber do período selecionado
- [x] Filtrar contas por data de criação/vencimento

### Melhorias na Interface de Contas a Receber
- [x] Mostrar resumo: Total Pendente / Total Vencido / Total Recebido
- [x] Cards de resumo com valores e quantidades
- [x] Badge de status com cores (Pendente/Vencido/Pago)
- [ ] Mostrar placa do veículo na listagem de contas (próxima fase)
- [ ] Mostrar número do orçamento vinculado (próxima fase)

### Testes
- [ ] Testar criação automática ao concluir orçamento
- [ ] Testar filtros de período
- [ ] Verificar sincronização com Dashboard


## 📊 MÓDULO DE RELATÓRIOS E ANÁLISE

### Relatório de Faturamento
- [ ] Criar página de Relatórios
- [ ] Card com total faturado no mês
- [ ] Card com total faturado no ano
- [ ] Gráfico de faturamento mensal (últimos 12 meses)
- [ ] Comparação com mês anterior (% crescimento)
- [ ] Filtros por período

### Funil de Vendas
- [ ] Card: Total Orçado (soma de todos os orçamentos)
- [ ] Card: Total Aprovado (orçamentos aprovados)
- [ ] Card: Total Rejeitado (orçamentos rejeitados)
- [ ] Calcular taxa de conversão (aprovados / total * 100)
- [ ] Gráfico visual do funil (100% → 60% → conversão)
- [ ] Lista de orçamentos rejeitados para análise

### Análise de Contas a Receber
- [ ] Seção "Quem está devendo" (pendentes + vencidas)
- [ ] Seção "Quem já pagou" (recebidas)
- [ ] Ranking de clientes devedores
- [ ] Tempo médio de recebimento
- [ ] Alertas de contas vencidas

### Backend
- [ ] Criar procedure para calcular faturamento por período
- [ ] Criar procedure para calcular funil de vendas
- [ ] Criar procedure para análise de contas a receber


## 🐛 BUG CRÍTICO - Visualização de Orçamentos

### Problema Reportado
- [ ] Usuário não consegue visualizar detalhes de orçamentos ao clicar
- [ ] Página não carrega/não abre quando clica no botão de visualizar
- [ ] Funciona no navegador de desenvolvimento mas não no navegador do usuário
- [ ] Provável causa: problema de autenticação/cookies no domínio de preview

### Investigação
- [ ] Verificar logs do servidor para erros de autenticação
- [ ] Verificar se há erro 401/403 nas requisições
- [ ] Verificar console do navegador para erros JavaScript
- [ ] Testar rota de visualização diretamente

### Solução
- [ ] Corrigir qualquer problema de roteamento
- [ ] Garantir que procedure de visualização está funcionando
- [ ] Orientar usuário a publicar sistema para resolver problema de cookies definitivamente


## 💰 MELHORIAS NO MÓDULO FINANCEIRO

### Informações Adicionais em Contas a Receber
- [x] Mostrar número do orçamento vinculado (ex: ORC-2025-0004)
- [x] Mostrar placa do veículo (ex: PHP8J32)
- [x] Calcular e mostrar "Dias para Vencer" ou "Vencido há X dias"
- [x] Ordenar por data de vencimento (mais urgente primeiro)
- [x] Destaque visual: amarelo (vence em <7 dias), laranja (hoje), vermelho (vencido)
- [ ] Adicionar link para abrir orçamento original (próxima fase)

### Backend
- [x] Atualizar query de contas a receber para fazer JOIN com orçamentos e veículos
- [x] Retornar dados completos: orcamento.numero, veiculo.placa, cliente.nome
- [x] Adicionar campo orcamentoId no schema de contasReceber


## 📊 FERRAMENTAS COMPLETAS DE CONTROLE FINANCEIRO

### Filtros Avançados no Módulo Financeiro
- [ ] Filtro por cliente específico (dropdown com lista de clientes)
- [ ] Filtro por faixa de valor (valor mínimo e máximo)
- [ ] Filtro por tipo de conta (orçamento, serviço, outros)
- [ ] Filtro combinado (múltiplos filtros simultâneos)
- [ ] Botão "Limpar Filtros" para resetar todos os filtros

### Página de Relatórios Financeiros
- [ ] Criar nova página "Relatórios" no menu principal
- [ ] Adicionar rota /relatorios no App.tsx
- [ ] Criar componente client/src/pages/Relatorios.tsx

### Relatórios - Faturamento
- [ ] Gráfico de barras: Faturamento mensal (últimos 12 meses)
- [ ] Tabela com detalhamento: Mês, Total Faturado, Quantidade de Orçamentos
- [ ] Comparativo: Mês atual vs Mês anterior (% de crescimento)
- [ ] Total faturado no ano
- [ ] Ticket médio (valor médio por orçamento)

### Relatórios - Funil de Vendas
- [ ] Total de orçamentos criados
- [ ] Total de orçamentos aprovados
- [ ] Total de orçamentos rejeitados
- [ ] Total de orçamentos pendentes
- [ ] Taxa de conversão (aprovados / total)
- [ ] Gráfico de funil visual (criados → aprovados → concluídos)
- [ ] Valor total orçado vs Valor total aprovado

### Relatórios - Análise de Clientes
- [ ] Ranking de clientes (maiores valores em orçamentos)
- [ ] Clientes com contas pendentes
- [ ] Clientes com contas vencidas (inadimplentes)
- [ ] Clientes que mais pagam em dia
- [ ] Total a receber por cliente
- [ ] Histórico de pagamentos por cliente

### Relatórios - Contas Vencidas
- [ ] Lista detalhada de contas vencidas
- [ ] Total vencido
- [ ] Quantidade de contas vencidas
- [ ] Dias de atraso médio
- [ ] Cliente com maior valor vencido
- [ ] Gráfico de evolução de inadimplência

### Gráficos Visuais (usando recharts)
- [ ] Gráfico de linha: Evolução de receitas (últimos 6 meses)
- [ ] Gráfico de pizza: Contas por status (Pendente/Vencido/Recebido)
- [ ] Gráfico de barras: Faturamento mensal comparativo
- [ ] Gráfico de área: Fluxo de caixa (entradas vs saídas)
- [ ] Gráfico de funil: Conversão de orçamentos

### Exportação para Excel
- [ ] Instalar biblioteca xlsx (npm install xlsx)
- [ ] Criar função exportToExcel() no frontend
- [ ] Botão "Exportar para Excel" em Contas a Receber
- [ ] Botão "Exportar para Excel" em Contas a Pagar
- [ ] Botão "Exportar Relatório" na página de Relatórios
- [ ] Incluir filtros aplicados na exportação
- [ ] Formatar células (datas, valores monetários)
- [ ] Adicionar cabeçalhos e totalizadores

### Exportação para PDF (Relatórios)
- [ ] Criar função generateRelatorioPDF() usando PDFKit
- [ ] Botão "Exportar PDF" na página de Relatórios
- [ ] Incluir gráficos no PDF (converter para imagem)
- [ ] Incluir tabelas formatadas
- [ ] Cabeçalho com logo e dados da empresa
- [ ] Rodapé com data de geração

### Fluxo de Caixa
- [ ] Criar card "Fluxo de Caixa" na página Financeiro
- [ ] Total de Entradas do mês (contas recebidas)
- [ ] Total de Saídas do mês (contas pagas)
- [ ] Saldo do mês (entradas - saídas)
- [ ] Gráfico de fluxo de caixa diário (últimos 30 dias)
- [ ] Projeção de fluxo de caixa (próximos 30 dias baseado em contas a vencer)
- [ ] Filtro por período (semana/mês/ano/personalizado)

### Totalizadores Detalhados
- [ ] Card "Total a Receber" com breakdown:
  * Total Geral a Receber
  * Total Vencido (vermelho)
  * Total a Vencer nos próximos 7 dias (amarelo)
  * Total a Vencer após 7 dias (cinza)
- [ ] Card "Total a Pagar" com breakdown similar
- [ ] Card "Recebido no Período" (filtro por mês/ano)
- [ ] Card "Pago no Período" (filtro por mês/ano)
- [ ] Ticket Médio por Orçamento
- [ ] Quantidade de Contas (Total, Pendentes, Vencidas, Pagas)

### Backend - Novas Funções
- [ ] Criar função getRelatorioFinanceiro() em server/db.ts
  * Retorna: faturamento mensal, funil de vendas, análise de clientes
- [ ] Criar função getFluxoCaixa() em server/db.ts
  * Retorna: entradas, saídas e saldo por período
- [ ] Criar função getFaturamentoMensal() em server/db.ts
  * Retorna: array com faturamento dos últimos 12 meses
- [ ] Criar função getFunilVendas() em server/db.ts
  * Retorna: total criados, aprovados, rejeitados, taxa de conversão
- [ ] Criar função getAnaliseClientes() em server/db.ts
  * Retorna: ranking de clientes, inadimplentes, histórico

### Backend - Endpoints tRPC
- [ ] Adicionar router "relatorios" em server/routers.ts
- [ ] Procedure: relatorios.getFinanceiro (relatório completo)
- [ ] Procedure: relatorios.getFluxoCaixa (fluxo de caixa)
- [ ] Procedure: relatorios.getFaturamento (faturamento mensal)
- [ ] Procedure: relatorios.getFunil (funil de vendas)
- [ ] Procedure: relatorios.getClientes (análise de clientes)

### Interface - Componentes Reutilizáveis
- [ ] Criar componente ChartCard.tsx (card com gráfico)
- [ ] Criar componente StatCard.tsx (card com estatística)
- [ ] Criar componente ExportButton.tsx (botão de exportação)
- [ ] Criar componente DateRangePicker.tsx (seletor de período)
- [ ] Criar componente FilterBar.tsx (barra de filtros)

### Interface - Página de Relatórios
- [ ] Criar layout com tabs: Faturamento, Funil de Vendas, Clientes, Contas
- [ ] Tab Faturamento: gráficos + tabelas + totalizadores
- [ ] Tab Funil de Vendas: gráfico de funil + métricas de conversão
- [ ] Tab Clientes: ranking + análise de inadimplência
- [ ] Tab Contas: detalhamento de contas a receber/pagar
- [ ] Filtro global de período (aplicado a todos os tabs)
- [ ] Botões de exportação (Excel + PDF) em cada tab

### Melhorias na Interface Financeiro
- [ ] Adicionar barra de filtros no topo da página
- [ ] Adicionar cards de totalizadores antes das tabelas
- [ ] Adicionar indicadores visuais (ícones, cores) nos valores
- [ ] Adicionar gráfico de pizza com distribuição de status
- [ ] Melhorar responsividade para mobile


## 📊 RELATÓRIO VISUAL DE CONTAS A RECEBER (PRIORIDADE MÁXIMA)

### Cards de Resumo Grandes e Visuais
- [x] Card "Total a Receber" - valor grande + quantidade + ícone
- [x] Card "Contas Vencidas" - vermelho, urgente, com alerta
- [x] Card "Vence em 7 dias" - amarelo, atenção
- [x] Card "Recebidas no Mês" - verde, sucesso
- [x] Cada card com gráfico circular de progresso

### Gráficos Dinâmicos e Intuitivos
- [x] Gráfico de Pizza: Distribuição Pendente/Vencido/Recebido (com percentuais)
- [x] Gráfico de Barras: Top 10 clientes que devem mais
- [ ] Gráfico de Linha do Tempo: Vencimentos dos próximos 30 dias
- [ ] Gráfico de Evolução: Recebimentos mês a mês (últimos 6 meses)
- [x] Cores intuitivas: Verde (ok), Amarelo (atenção), Vermelho (urgente)

### Tabela Detalhada com Destaque Visual
- [x] Linhas com cores de fundo por urgência (vermelho=vencido, amarelo=próximo, branco=normal)
- [x] Ícones visuais de status (✅ recebido, ⚠️ vencido, ⏳ pendente)
- [x] Ordenação automática: vencidas primeiro
- [x] Destaque em negrito para valores altos
- [x] Badge grande e colorido para status

### Exportação e Ações
- [x] Botão "Exportar para Excel" bem visível
- [x] Botão "Marcar como Recebido" com confirmação
- [x] Filtros rápidos (Todas/Vencidas/A Vencer/Recebidas)
- [x] Busca por cliente em tempo real

### Layout e UX
- [x] Página focada 100% em Contas a Receber (remover Contas a Pagar por enquanto)
- [x] Cards ocupando largura total para melhor visualização
- [x] Gráficos grandes e legíveis
- [x] Espaçamento adequado entre seções
- [x] Responsivo para mobile

### Depois: Contas a Pagar
- [ ] Replicar mesmo padrão visual para Contas a Pagar
- [ ] Adicionar tab para alternar entre Receber e Pagar


## 🖱️ NAVEGAÇÃO INTERATIVA COM UM CLIQUE

### Cards Clicáveis
- [x] Card "Total a Receber" → Clica → Filtra tabela para mostrar todas pendentes
- [x] Card "Vencidas" → Clica → Filtra tabela para mostrar só vencidas
- [x] Card "Vence em 7 dias" → Clica → Filtra tabela para próximas
- [x] Card "Recebidas no Mês" → Clica → Filtra tabela para recebidas
- [x] Indicador visual de card ativo (borda destacada)

### Gráfico Clicável
- [x] Gráfico de Pizza → Clica em fatia → Filtra por status
- [x] Clica em "Vencidas" → Mostra só vencidas
- [x] Clica em "Pendentes" → Mostra só pendentes
- [x] Clica em "Recebidas" → Mostra só recebidas

### Modal Detalhado ao Clicar na Linha
- [x] Linha da tabela clicável (cursor pointer)
- [x] Abre modal grande com detalhes completos
- [x] Exibir dados do veículo (placa, modelo, cliente)
- [x] Exibir orçamento completo separado:
  - [x] Seção "Peças" com lista e valores
  - [x] Seção "Serviços" com lista e valores
  - [x] Subtotal de Peças
  - [x] Subtotal de Serviços
  - [x] Total Geral
- [x] Botão "Ver Orçamento Completo" (link para /orcamentos/:id)
- [x] Botão "Marcar como Recebido" no modal
- [x] Botão "Fechar" ou ESC para sair


## 💰 CONTAS A PAGAR - PADRÃO VISUAL COMPLETO

### Estrutura Geral
- [x] Adicionar Tabs na página Financeiro (Contas a Receber / Contas a Pagar)
- [x] Manter estado do filtro ao trocar de tab
- [x] Layout idêntico ao de Contas a Receber

### Cards de Resumo (Contas a Pagar)
- [x] Card "Total a Pagar" (azul) - valor + quantidade pendentes
- [x] Card "Contas Vencidas" (vermelho) - urgente
- [x] Card "Vence em 7 dias" (amarelo) - atenção
- [x] Card "Pagas no Mês" (verde) - sucesso
- [ ] Todos cards clicáveis com indicador visual

### Gráficos Dinâmicos (Contas a Pagar)
- [ ] Gráfico de Pizza: Distribuição (Pendente/Vencido/Pago)
- [ ] Gráfico de Barras: Top 10 fornecedores (quem recebe mais)
- [ ] Ambos clicáveis para filtrar tabela

### Tabela Interativa (Contas a Pagar)
- [x] Colunas: Descrição, Fornecedor, Valor, Vencimento, Status, Ações
- [x] Cores de fundo por urgência (vermelho/amarelo/branco)
- [ ] Ordenação automática (vencidas primeiro)
- [x] Badges coloridos para status
- [ ] Linhas clicáveis (abre modal detalhado)
- [x] Botão "Marcar como Pago"

### Modal Detalhado (Contas a Pagar)
- [ ] Dados da conta (descrição, fornecedor, categoria)
- [ ] Valor detalhado
- [ ] Data de emissão e vencimento
- [ ] Observações (se houver)
- [ ] Botão "Marcar como Pago"
- [ ] Botão "Fechar" ou ESC

### Funcionalidades Adicionais
- [ ] Botão "Nova Conta a Pagar" (dialog para cadastro)
- [ ] Filtros: Status, Fornecedor, Faixa de valor
- [ ] Botão "Exportar para Excel"
- [ ] Busca por fornecedor em tempo real

### Formulário de Nova Conta
- [ ] Campo: Descrição (obrigatório)
- [ ] Campo: Fornecedor (opcional)
- [ ] Campo: Valor (obrigatório)
- [ ] Campo: Data de Vencimento (obrigatório)
- [ ] Campo: Categoria (dropdown: Fornecedores, Aluguel, Salários, Impostos, Outros)
- [ ] Campo: Observações (opcional)
- [ ] Validação de campos
- [ ] Salvar e atualizar lista


## 🎨 TEMA VISUAL PROFISSIONAL

### Paleta de Cores
- [x] Fundo geral: Azul claro acinzentado
- [x] Cards/Módulos: Branco (#ffffff) com sombras sutis
- [x] Sidebar: Azul marinho forte
- [x] Texto principal: Cinza escuro em fundos claros
- [x] Texto secundário: Cinza médio

### Ícones Coloridos por Módulo
- [x] Dashboard: Azul (#3b82f6)
- [x] Orçamentos: Roxo (#8b5cf6)
- [x] Ordens de Serviço: Laranja (#f97316)
- [x] Clientes: Verde (#22c55e)
- [x] Veículos: Cyan (#06b6d4)
- [x] Financeiro: Amarelo/Dourado (#eab308)
- [x] Relatórios: Rosa (#ec4899)
- [x] Estoque: Indigo (#6366f1)
- [x] Agendamentos: Teal (#14b8a6)
- [x] Administração: Cinza (#6b7280)

### Componentes
- [x] Cards com fundo branco e bordas arredondadas
- [x] Sombras sutis para profundidade
- [x] Gradientes suaves em botões primários
- [x] Hover effects elegantes
- [x] Transições suaves (transition-all duration-200)

### Layout
- [x] Sidebar com fundo azul marinho
- [x] Área principal com fundo azul claro
- [x] Cards destacados em branco
- [x] Espaçamento adequado entre elementos
- [x] Contraste suficiente para legibilidade

### Ajustes Específicos
- [x] Header do Layout
- [x] Cards do Dashboard com gradientes coloridos
- [ ] Tabelas (manter legibilidade)
- [ ] Formulários
- [ ] Modais
- [ ] Badges e tags coloridos


## 🔧 CORREÇÃO DE CONTRASTE SIDEBAR

- [x] Aumentar contraste dos ícones não selecionados
- [x] Ajustar cor do texto dos itens não selecionados
- [x] Garantir que todos os ícones coloridos sejam visíveis no fundo escuro
- [x] Testar legibilidade em todos os itens do menu
- [x] Trocar fundo azul por cinza suave e discreto


## 🎨 ESQUEMA DE CORES PROFISSIONAL (APPLE/NOTION STYLE)

### Cores Base
- [x] Fundo geral: #F5F7FA
- [x] Sidebar background: #1E293B
- [x] Sidebar texto/ícones: #F5F7FA
- [x] Texto principal: #111827
- [x] Texto secundário: #6B7280
- [x] Bordas e divisores: #D1D9E6

### Botões
- [x] Botões primários (CTA): #3B82F6
- [x] Botões secundários: #D1D9E6 com texto #111827

### Cards
- [x] Fundo branco: #FFFFFF
- [x] Borda fina: #E4E9F1
- [x] Sombra difusa suave
- [x] Arredondamento: 12px

### Status
- [x] Positivo/A Receber: #10B981
- [x] Alerta suave/Pendências: #FCA5A5
- [x] Informação/Estoque Baixo: #60A5FA

### Aplicação
- [x] CSS global (index.css)
- [x] Sidebar (Layout.tsx)
- [x] Cards do Dashboard
- [ ] Botões em todas as páginas
- [ ] Badges de status
- [ ] Tabelas e formulários


## 📝 FORMULÁRIO DE NOVA CONTA A PAGAR

### Modal e Estrutura
- [x] Criar modal Dialog para Nova Conta a Pagar
- [x] Adicionar título e botão fechar
- [x] Estruturar formulário com campos organizados

### Campos do Formulário
- [x] Select de Fornecedor (carrega lista do backend)
- [x] Input de Descrição (obrigatório)
- [x] Input de Valor em R$ (obrigatório, formato moeda)
- [x] Input de Data de Vencimento (obrigatório)
- [x] Select de Categoria (Fornecedores, Impostos, Salários, Aluguel, Outros)
- [x] Select de Forma de Pagamento (Dinheiro, PIX, Cartão, Boleto, Transferência)
- [x] Textarea de Observações (opcional)

### Validações
- [x] Validar campos obrigatórios
- [x] Validar formato de valor (número positivo)
- [x] Validar data (não pode ser muito antiga)
- [x] Validar seleção de fornecedor

### Integração Backend
- [x] Conectar mutation de criar conta a pagar
- [x] Enviar dados formatados corretamente
- [x] Tratar erros de salvamento
- [x] Atualizar lista após criação
- [x] Fechar modal após sucesso

### UX
- [x] Mensagem de sucesso (toast)
- [x] Mensagem de erro (toast)
- [x] Loading state no botão salvar
- [x] Limpar formulário após salvar
- [ ] Focar primeiro campo ao abrir


## 📊 GRÁFICOS EM CONTAS A PAGAR

### Gráfico de Pizza
- [x] Calcular distribuição por status (Pendente/Vencido/Pago)
- [x] Criar gráfico de pizza com cores consistentes
- [x] Adicionar percentuais em cada fatia
- [x] Tornar fatias clicáveis para filtrar tabela
- [x] Posicionar ao lado dos cards de resumo

### Gráfico de Barras
- [x] Calcular top 10 fornecedores por valor total
- [x] Criar gráfico de barras horizontal
- [x] Formatar valores em R$
- [x] Adicionar tooltip com detalhes
- [x] Posicionar abaixo do gráfico de pizza

### Integração
- [x] Manter consistência visual com Contas a Receber
- [x] Usar mesmas cores e estilos
- [x] Responsivo para mobile
- [ ] Loading state enquanto carrega dados


## 💼 MÓDULO DE COLABORADORES E FOLHA DE PAGAMENTO

### Schema e Backend
- [x] Criar tabela `colaboradores` no schema
  - [x] Campos: nome, cargo, salário, tipo_pagamento (semanal/quinzenal/mensal)
  - [x] Dia de pagamento (ex: sábado = 6)
  - [x] Status (ativo/inativo)
  - [x] Data de admissão
- [x] Funções no db.ts (CRUD de colaboradores)
- [x] Router tRPC para colaboradores

### Página de Colaboradores
- [x] Criar página `/colaboradores`
- [x] Adicionar item no menu da sidebar
- [x] Tabela listando todos os colaboradores
- [x] Botão "Novo Colaborador"
- [x] Formulário de cadastro com validações
- [x] Editar e excluir colaboradores
- [x] Filtros (ativos/inativos, tipo de pagamento)

### Integração com Folha de Pagamento
- [ ] Calcular folha semanal automaticamente
- [ ] Calcular folha quinzenal automaticamente
- [ ] Calcular folha mensal automaticamente
- [ ] Gerar contas a pagar automaticamente para salários
- [ ] Vincular colaborador à conta a pagar gerada

### Alertas no Dashboard
- [x] Card "Folha desta Semana" no Dashboard
- [x] Mostrar quantidade de funcionários a pagar
- [x] Mostrar valor total da folha
- [x] Destacar dia de pagamento (ex: "Pagar em X dias")
- [x] Cor de alerta se próximo do dia (vermelho < 2 dias, laranja < 4 dias)

### Relatórios
- [ ] Histórico de pagamentos por colaborador
- [ ] Total de folha por mês
- [ ] Custo total com pessoal


## 🎯 FINALIZAÇÃO DO SISTEMA DE FOLHA DE PAGAMENTO

### Geração Automática de Contas a Pagar
- [ ] Criar função para gerar contas a pagar automaticamente
- [ ] Vincular conta a pagar ao colaborador (adicionar campo colaboradorId)
- [ ] Botão manual "Gerar Pagamento" na página de Colaboradores
- [ ] Marcar contas geradas para evitar duplicação

### Sistema de Adiantamentos
- [ ] Criar tabela de adiantamentos no schema
- [ ] Backend para registrar adiantamentos
- [ ] Interface para adicionar adiantamento na página do colaborador
- [ ] Calcular desconto automático no próximo pagamento
- [ ] Mostrar saldo de adiantamentos pendentes

### Histórico de Pagamentos
- [ ] Criar view/query de histórico por colaborador
- [ ] Página ou modal mostrando todos os pagamentos
- [ ] Filtros por período
- [ ] Exportação para Excel

### Integração Final
- [ ] Testar fluxo completo: cadastrar colaborador → gerar pagamento → registrar adiantamento
- [ ] Validar cálculos de desconto
- [ ] Garantir consistência de dados


## 📄 MÓDULO DE ORÇAMENTOS EXTERNOS (PDFS DE SEGURADORAS)

### Schema e Backend
- [ ] Criar tabela `orcamentosExternos` no schema
  - [ ] Campos: cliente, placa, modelo, pdfUrl, pdfKey, dataRecebimento, status
- [ ] Funções no db.ts (CRUD de orçamentos externos)
- [ ] Router tRPC para orçamentos externos
- [ ] Endpoint de upload de PDF para S3

### Página de Orçamentos Externos
- [ ] Criar página `/orcamentos-externos`
- [ ] Adicionar item no menu da sidebar
- [ ] Botão "Upload PDF"
- [ ] Modal de upload com campos:
  - [ ] Upload de arquivo PDF
  - [ ] Cliente (select ou input)
  - [ ] Placa do veículo
  - [ ] Modelo do veículo
  - [ ] Data de recebimento
  - [ ] Status inicial
- [ ] Tabela listando todos os PDFs
- [ ] Visualizador de PDF ao clicar
- [ ] Filtros (por cliente, status, data)
- [ ] Botão "Converter para Orçamento" (criar OS a partir do PDF)

### Funcionalidades
- [ ] Upload de PDF para S3
- [ ] Visualização de PDF inline
- [ ] Download de PDF
- [ ] Excluir PDF
- [ ] Histórico por cliente
- [ ] Status workflow (Pendente → Em análise → Aprovado/Rejeitado)


## NOVA FUNCIONALIDADE - Sistema de Permissões por Módulo
- [x] Atualizar schema do banco para suportar permissões por módulo
- [x] Criar backend de gestão de usuários e permissões
- [x] Implementar middleware de autorização por módulo
- [x] Criar interface de Gestão de Usuários (apenas admin)
- [x] Implementar menu lateral dinâmico baseado em permissões do usuário
- [x] Testar sistema completo de permissões

## BUG - Acesso Admin
- [ ] Garantir que admin veja todos os módulos no menu lateral (ainda mostrando apenas 6 de 12)
- [ ] Verificar se nivelAcesso está sendo setado corretamente para o dono do projeto
- [ ] Investigar por que logout/login não atualiza permissões

## BUG - Gestão de Usuários
- [x] Garantir que dono do projeto sempre tenha role=admin e nivelAcesso=admin ao fazer login
- [x] Corrigir erro "Acesso negado" ao tentar criar usuário

## CORREÇÕES PRÉ-PUBLICAÇÃO
- [ ] Corrigir erro TypeScript em Orcamentos.tsx (linha 64 - tipo any)
- [ ] Corrigir erro de import duplicado em Layout.tsx (useAuth)
- [ ] Verificar que todos os módulos funcionam corretamente
- [ ] Garantir zero erros de compilação

## SIMPLIFICAÇÃO - Remover Controle de Acesso
- [x] Remover verificações de permissões do Layout
- [x] Remover middleware de admin dos routers
- [x] Remover página de Gestão de Usuários do menu
- [x] Liberar todos os módulos para usuários autenticados

## BUGS CRÍTICOS - Sistema Publicado
- [ ] Erro ao cadastrar novos clientes
- [ ] Erro ao cadastrar colaboradores
- [ ] Erro com campos de data
- [ ] Verificar e corrigir todos os formulários de cadastro
